// Nur für UI-Tests: verbindet die ECHTE Oberfläche (im Chromium) mit dem ECHTEN Backend-Code (api.js/auth.js …),
// mit einer Fake-KI. Die App selbst nutzt KEINEN Server – dies ist ausschließlich Testwerkzeug.
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServices } from '../../src/services.js';
import { createApi } from '../../src/api.js';
import { fileCipher } from '../../src/vault.js';
import { totpAt } from '../../src/totp.js';
import { MODELS } from '../../src/models.js';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'zayriox-ui-'));
const queues = new Map();
const push = (sid, c, p) => { if (!queues.has(sid)) queues.set(sid, []); queues.get(sid).push({ c, p }); };

const engine = {
  status: { state: 'no-model', modelId: null, installed: [], downloading: false, progress: 0, message: '' },
  isInstalled() { return this.status.installed.length > 0; },
  async download(id) {
    this.status = { ...this.status, downloading: true, downloadingId: id, progress: 0.3, downloadedMB: 120, totalMB: 400 }; broadcast();
    await new Promise((r) => setTimeout(r, 400));
    this.status = { ...this.status, downloading: false, progress: 1, installed: [id] }; broadcast();
  },
  async load(id) { this.status = { ...this.status, state: 'ready', modelId: id, installed: [id] }; broadcast(); },
  async dispose() {},
  async complete(o) {
    const words = (o.system.includes('Vorüberlegung') || o.system.includes('Denkprozess') ? 'Schritt eins prüfen. Dann Antwort formulieren.' : 'Hallo! Das ist eine **Testantwort** von Zayriox.\n\n```python\nprint("hi")\n```').split(' ');
    let out = '';
    for (const w of words) { if (o.signal.aborted) break; await new Promise((r) => setTimeout(r, 25)); const t = (out ? ' ' : '') + w; out += t; o.onText(t); }
    return out;
  }
};
function broadcast() { for (const sid of queues.keys()) push(sid, 'engine:status', engine.status); }
const ml = { describeImage: async () => 'Ein Testbild.', transcribe: async () => 'Das ist ein diktierter Satz' };

let api;
const svc = createServices({ dir, cipher: fileCipher(dir), engine, ml, scryptN: 1024, onSessionEnd: (sid, reason) => { api.abortFor(sid); push(sid, 'session:ended', { reason }); } });
api = createApi(svc, { version: 'ui-test' });

const DDG = '<a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fde.wikipedia.org%2Fwiki%2FBerlin">Berlin – Wikipedia</a><a class="result__snippet" href="#">Hauptstadt von Deutschland.</a>';
let searchOk = true;
globalThis.fetch = async () => { if (!searchOk) throw new Error('offline'); return { ok: true, text: async () => DDG }; };

const revive = (v) => {
  if (v && v.__b64) { const b = Buffer.from(v.__b64, 'base64'); return v.t === 'f32' ? new Float32Array(b.buffer.slice(b.byteOffset, b.byteOffset + b.length)) : new Uint8Array(b).buffer; }
  if (Array.isArray(v)) return v.map(revive);
  if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, revive(x)]));
  return v;
};

const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*'); res.setHeader('Access-Control-Allow-Headers', '*');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  const url = new URL(req.url, 'http://x');
  const sid = Number(req.headers['x-sid'] || url.searchParams.get('sid') || 0);
  if (url.pathname === '/totp') { res.end(totpAt(url.searchParams.get('secret'), Date.now() + Number(url.searchParams.get('offset') || 0))); return; }
  if (url.pathname === '/search') { searchOk = url.searchParams.get('ok') === '1'; res.end('ok'); return; }
  if (url.pathname === '/events') { const q = queues.get(sid) || []; queues.set(sid, []); res.setHeader('Content-Type', 'application/json'); return res.end(JSON.stringify(q)); }
  if (url.pathname === '/invoke') {
    let body = ''; for await (const c of req) body += c;
    const { channel, payload } = JSON.parse(body);
    if (!queues.has(sid)) queues.set(sid, []);
    const ctx = { sid, notify: (c, p) => push(sid, c, p), openExternal: (u) => push(sid, 'opened', u), setTheme: () => {} };
    const r = await api.invoke(channel, ctx, revive(payload));
    res.setHeader('Content-Type', 'application/json'); return res.end(JSON.stringify(r));
  }
  res.writeHead(404); res.end();
});
server.listen(0, '127.0.0.1', () => console.log('PORT=' + server.address().port));
svc.auth; // Sitzungen enden lassen: Ende-Ereignisse gehen an die Seite
setInterval(() => svc.auth.sweep(), 1000).unref();
void MODELS; void fileURLToPath;
