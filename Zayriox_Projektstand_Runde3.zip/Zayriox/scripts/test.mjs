// Tests für die Logik, die ohne Electron/Modell prüfbar ist.
// Ausführen: npm test
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const rel = (p) => path.join(root, p);
// Unter Windows braucht import() eine file://-URL (ein Pfad wie C:\\… wird abgelehnt).
const url = (p) => pathToFileURL(rel(p)).href;
let passed = 0;
const failed = [];

async function test(name, fn) {
  try { await fn(); passed++; console.log('  ✓', name); }
  catch (e) { failed.push(name); console.log('  ✗', name, '\n    ', e.message); }
}

// ---------- Syntax aller Dateien ----------
console.log('Syntax');
for (const f of ['src/main.js', 'src/selftest.js', 'src/services.js', 'src/api.js', 'src/auth.js', 'src/admin.js', 'src/accounts.js', 'src/totp.js', 'src/vault.js', 'src/audit.js', 'src/policy.js', 'src/search.js', 'src/media.js', 'src/ml.js', 'src/config.js', 'src/engine.js', 'src/pipeline.js', 'src/store.js', 'src/files.js', 'src/modes.js', 'src/models.js', 'src/errors.js', 'src/preload.cjs']) {
  await test(f, () => {
    const r = spawnSync(process.execPath, ['--check', rel(f)], { encoding: 'utf8' });
    assert.equal(r.status, 0, r.stderr);
  });
}
for (const f of ['renderer/core.js', 'renderer/auth.js', 'renderer/app.js', 'renderer/owner.js', 'renderer/start.js', 'renderer/markdown.js', 'renderer/splash.js']) {
  await test(f, () => { new vm.Script(fs.readFileSync(rel(f), 'utf8'), { filename: f }); });
}

// ---------- Module ----------
const { resolveAuto, listModes, MODES } = await import(url('src/modes.js'));
const { runChat, trimHistory, buildUserPrompt, LIMITS } = await import(url('src/pipeline.js'));
const { sanitizeChats, sanitizeSettings, Store } = await import(url('src/store.js'));
const { extractText } = await import(url('src/files.js'));
const { friendly, ZxError } = await import(url('src/errors.js'));
const { Engine } = await import(url('src/engine.js'));
const { MODELS } = await import(url('src/models.js'));

console.log('Auto-Modus & Modi');
await test('kurze Frage -> schnell', () => assert.equal(resolveAuto('Hallo, wie geht es dir?'), 'schnell'));
await test('Erklär-Frage -> mittel', () => assert.equal(resolveAuto('Erkläre mir bitte, wie ein Motor funktioniert'), 'mittel'));
await test('schwierige Aufgabe -> promax', () => assert.equal(resolveAuto('Berechne Schritt für Schritt das Integral dieser Funktion und beweise, dass das Ergebnis stimmt, mit allen Zwischenschritten'), 'promax'));
await test('Datei -> mindestens mittel', () => assert.notEqual(resolveAuto('Was steht drin?', { hasFiles: true }), 'schnell'));
await test('Modus-Liste enthält Auto + 4 Stufen', () => assert.deepEqual(listModes().map((m) => m.id), ['auto', 'schnell', 'mittel', 'hoch', 'promax']));

console.log('Pipeline (mit Fake-Engine)');
function fakeEngine() {
  const calls = [];
  return {
    calls,
    async complete(o) {
      calls.push(o);
      const out = `antwort${calls.length}`;
      if (o.signal.aborted) return '';
      o.onText(out);
      return out;
    }
  };
}
async function run(mode, text = 'Hallo', extra = {}) {
  const eng = extra.engine || fakeEngine();
  const events = [];
  const ac = extra.ac || new AbortController();
  const res = await runChat({ engine: eng, mode, messages: [{ role: 'user', content: text }], custom: extra.custom || '', signal: ac.signal, emit: (e) => events.push(e) });
  return { eng, events, res };
}
await test('schnell: 1 Durchgang, kein Denken', async () => {
  const { eng, events } = await run('schnell');
  assert.equal(eng.calls.length, 1);
  assert.ok(!events.some((e) => e.type === 'think'));
  assert.deepEqual(events.find((e) => e.type === 'mode'), { type: 'mode', mode: 'schnell', auto: false });
  assert.equal(eng.calls[0].maxTokens, MODES.schnell.maxTokens);
});
await test('hoch: Denken + Antwort (2 Durchgänge)', async () => {
  const { eng, events } = await run('hoch');
  assert.equal(eng.calls.length, 2);
  assert.ok(events.some((e) => e.type === 'think'));
  assert.ok(events.some((e) => e.type === 'token' && e.text === 'antwort2'));
  assert.ok(eng.calls[1].system.includes('antwort1'), 'Denk-Notizen fließen in die Antwort ein');
});
await test('promax: Denken + Entwurf + Überarbeitung (3 Durchgänge)', async () => {
  const { eng, events } = await run('promax');
  assert.equal(eng.calls.length, 3);
  assert.ok(eng.calls[2].user.includes('antwort2'), 'Entwurf wird geprüft');
  assert.deepEqual(events.filter((e) => e.type === 'token').map((e) => e.text), ['antwort3']);
});
await test('auto wählt Modus und meldet ihn', async () => {
  const { events } = await run('auto', 'Hi');
  assert.deepEqual(events[0], { type: 'mode', mode: 'schnell', auto: true });
});
await test('eigene Anweisungen landen im System-Prompt', async () => {
  const { eng } = await run('mittel', 'Hi', { custom: 'Sprich wie ein Pirat' });
  assert.ok(eng.calls[0].system.includes('Sprich wie ein Pirat'));
});
await test('Abbruch mitten in Pro Max stoppt weitere Durchgänge', async () => {
  const ac = new AbortController();
  const eng = fakeEngine();
  const orig = eng.complete.bind(eng);
  eng.complete = async (o) => { const r = await orig(o); if (eng.calls.length === 1) ac.abort(); return r; };
  const { res } = await run('promax', 'Hi', { engine: eng, ac });
  assert.equal(res.stopped, true);
  assert.equal(eng.calls.length, 1);
});
await test('leere Antwort -> verständlicher Fehler', async () => {
  const eng = { async complete() { return '   '; } };
  await assert.rejects(run('mittel', 'Hi', { engine: eng }), (e) => e instanceof ZxError && e.code === 'EMPTY_ANSWER');
});
await test('Datei wird in die Frage eingebaut und gekürzt', () => {
  const p = buildUserPrompt('Was steht drin?', [{ name: 'a.txt', text: 'x'.repeat(LIMITS.attachChars + 500) }]);
  assert.ok(p.includes('Datei „a.txt“ (gekürzt)'));
  assert.ok(p.length < LIMITS.attachChars + 200);
  assert.ok(buildUserPrompt('', [{ name: 'b.txt', text: 'hi' }]).includes('Fasse den Inhalt'));
});
await test('Verlauf: wechselt Rollen ab, endet mit Antwort, wird gekürzt', () => {
  const h = trimHistory([
    { role: 'assistant', content: 'alt' },
    { role: 'user', content: 'a' }, { role: 'user', content: 'b' },
    { role: 'assistant', content: '' },
    { role: 'assistant', content: 'c' },
    { role: 'user', content: 'offen' }
  ]);
  assert.deepEqual(h, [{ role: 'user', content: 'a\n\nb' }, { role: 'assistant', content: 'c' }]);
  const many = Array.from({ length: 60 }, (_, i) => ({ role: i % 2 ? 'assistant' : 'user', content: 'm' + i }));
  assert.ok(trimHistory(many).length <= LIMITS.maxMessages);
});

console.log('Speicher');
await test('Chats/Einstellungen werden bereinigt', () => {
  const c = sanitizeChats([{ id: 'x', title: 't'.repeat(999), messages: [{ role: 'system', content: 'böse' }, { role: 'user', content: 'ok', ts: 1 }] }, { title: 'ohne id' }, 'müll']);
  assert.equal(c.length, 1);
  assert.equal(c[0].title.length, 200);
  assert.equal(c[0].messages.length, 1);
  assert.deepEqual(sanitizeSettings({ theme: 'pink', mode: 'god', name: 5 }), { theme: 'dark', name: '', custom: '', mode: 'auto', webSearch: false, autoRead: false });
});
await test('Speichern/Laden + defekte Datei überlebt', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'zayriox-'));
  const st = new Store(dir);
  st.saveChats([{ id: 'a', title: 'Hallo', messages: [{ role: 'user', content: 'x' }] }]);
  assert.equal(st.loadChats()[0].title, 'Hallo');
  fs.writeFileSync(path.join(dir, 'chats.json'), '{kaputt');
  assert.deepEqual(st.loadChats(), []);
  assert.ok(fs.readdirSync(dir).some((f) => f.startsWith('chats.json.defekt-')));
  assert.equal(st.loadSettings().theme, 'dark');
});

console.log('Dateien');
await test('Textdatei wird gelesen', async () => assert.equal((await extractText('notiz.txt', Buffer.from('Hallo Welt\r\n'))).text, 'Hallo Welt'));
await test('Code-Datei wird gelesen', async () => assert.ok((await extractText('a.py', Buffer.from('print(1)'))).text.includes('print')));
await test('Bild -> klare Meldung (Anhang-Weg läuft über die Bildanalyse)', async () => assert.rejects(extractText('foto.png', Buffer.from([1, 2])), (e) => e.code === 'IMAGE_UNSUPPORTED'));
await test('Binärdatei/unbekanntes Format -> Meldung', async () => {
  await assert.rejects(extractText('x.exe', Buffer.from('MZ')), (e) => e.code === 'FILE_UNSUPPORTED');
  await assert.rejects(extractText('x.txt', Buffer.from([65, 0, 66])), (e) => e.code === 'FILE_UNSUPPORTED');
});
await test('zu große / leere Datei', async () => {
  await assert.rejects(extractText('big.txt', Buffer.alloc(6 * 1024 * 1024, 65)), (e) => e.code === 'FILE_TOO_BIG');
  await assert.rejects(extractText('leer.txt', Buffer.from('  \n')), (e) => e.code === 'FILE_EMPTY');
});

console.log('Fehlertexte & Engine-Hülle');
await test('Fehler sind verständlich, ohne Technik-Kauderwelsch', () => {
  assert.ok(!/404|127\.0\.0\.1|ECONN/.test(friendly(new Error('connect ECONNREFUSED 127.0.0.1'))));
  assert.match(friendly(new Error('Failed to allocate memory')), /Arbeitsspeicher/);
});
await test('Engine ohne Modell: sauberer Fehler statt Absturz', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'zayriox-m-'));
  const eng = new Engine({ modelsDir: dir, onStatus: () => {} });
  assert.equal(eng.status.state, 'no-model');
  assert.deepEqual(eng.status.installed, []);
  await assert.rejects(eng.complete({ system: 's', user: 'u', signal: new AbortController().signal }), (e) => e.code === 'NO_MODEL');
  await assert.rejects(eng.load('mini'), (e) => e.code === 'NO_MODEL');
  fs.writeFileSync(path.join(dir, MODELS[0].file), 'x');
  eng.refreshInstalled();
  assert.deepEqual(eng.status.installed, ['mini']);
});
await test('Modell-Katalog: eindeutige IDs, https-URLs', () => {
  assert.equal(new Set(MODELS.map((m) => m.id)).size, MODELS.length);
  assert.ok(MODELS.every((m) => m.url.startsWith('https://') && m.file.endsWith('.gguf')));
});

console.log('Markdown (Sicherheit)');
const sb = { };
vm.runInNewContext(fs.readFileSync(rel('renderer/markdown.js'), 'utf8'), sb);
const md = sb.ZxMD.render;
await test('HTML/Skripte werden maskiert', () => {
  const h = md('<script>alert(1)</script> <img src=x onerror=alert(1)>');
  assert.ok(!h.includes('<script') && !h.includes('<img'));
});
await test('Codeblock, auch unfertig beim Streamen', () => {
  assert.ok(md('```js\nlet a = 1 < 2;\n```').includes('let a = 1 &lt; 2;'));
  assert.ok(md('Text\n```py\nprint(1)').includes('class="code"'));
});
await test('Listen, Fett, Überschrift, nur https-Links', () => {
  const h = md('# Titel\n\n1. eins\n\n2. zwei\n\n- **fett** und `code`\n\n[ok](https://a.de) [böse](javascript:alert(1))');
  assert.ok(h.includes('<h2>Titel</h2>'));
  assert.equal((h.match(/<ol>/g) || []).length, 1, 'nummerierte Liste bleibt zusammen');
  assert.ok(h.includes('<strong>fett</strong>') && h.includes('<code>code</code>'));
  assert.ok(h.includes('data-href="https://a.de"') && !h.includes('javascript:alert(1)"'));
});

// =====================================================================
// Sicherheit, Konten, Owner, 2FA, Audit
// =====================================================================
const { base32Encode, base32Decode, hotp, totpAt, verifyTotp, generateSecret } = await import(url('src/totp.js'));
const { createServices } = await import(url('src/services.js'));
const { createApi, validateSend } = await import(url('src/api.js'));
const { fileCipher } = await import(url('src/vault.js'));
const { parseDuckDuckGo, webSearch } = await import(url('src/search.js'));
const { sniffImage, validateAudio, toFloat32 } = await import(url('src/media.js'));
const { AuditLog } = await import(url('src/audit.js'));
const { hashPassword, verifyPassword, validatePassword } = await import(url('src/accounts.js'));

console.log('TOTP / 2FA');
await test('RFC-6238-Testvektoren stimmen', () => {
  const secret = base32Encode(Buffer.from('12345678901234567890'));
  assert.equal(hotp(secret, 1, 8), '94287082');     // T=59
  assert.equal(hotp(secret, 37037036, 8), '07081804'); // T=1111111109
  assert.equal(base32Decode(secret).toString(), '12345678901234567890');
});
await test('Code nur einmal verwendbar, Zeitfenster ±1', () => {
  const s = generateSecret(); const t = 1_700_000_000_000;
  const code = totpAt(s, t);
  const c = verifyTotp(s, code, { now: t });
  assert.ok(c !== null);
  assert.equal(verifyTotp(s, code, { now: t, lastCounter: c }), null, 'Wiederverwendung blockiert');
  assert.ok(verifyTotp(s, code, { now: t + 30000 }) !== null, 'Nachbarfenster ok');
  assert.equal(verifyTotp(s, code, { now: t + 120000 }), null, 'zu alt');
  assert.equal(verifyTotp(s, '12345', { now: t }), null);
});

console.log('Passwörter');
await test('scrypt-Hash, kein Klartext, falsches Passwort scheitert', async () => {
  const h = await hashPassword('Geheimes-Passwort-1', 1024);
  assert.ok(h.startsWith('scrypt$') && !h.includes('Geheimes'));
  assert.equal(await verifyPassword('Geheimes-Passwort-1', h), true);
  assert.equal(await verifyPassword('geheimes-passwort-1', h), false);
  assert.equal(await verifyPassword('x', 'kaputt'), false);
});
await test('Passwort-Regeln', () => {
  assert.ok(validatePassword('kurz1'));
  assert.ok(validatePassword('nurbuchstaben'));
  assert.ok(validatePassword('aaaaaaaaaaaa'));
  assert.ok(validatePassword('max12345678', 'max'));
  assert.equal(validatePassword('Ein-gutes-Passwort-9'), null);
});

// ---- Testumgebung mit Fake-KI und steuerbarer Uhr ----
function fakeLlm() {
  const e = { calls: [], status: { state: 'ready', installed: ['mini'], modelId: 'mini' },
    async complete(o) { e.calls.push(o); if (o.signal.aborted) return ''; o.onText('Antwort'); return 'Antwort'; },
    async download() {}, async load() {}, async dispose() {}, isInstalled: () => true };
  return e;
}
async function env(over = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'zayriox-t-'));
  const clock = { t: 1_800_000_000_000 };
  const ended = [];
  const svc = createServices({ dir, cipher: fileCipher(dir), engine: over.engine || fakeLlm(), ml: over.ml || null, scryptN: 1024, now: () => clock.t, onSessionEnd: (sid, r) => ended.push([sid, r]) });
  const api = createApi(svc, { version: 't' });
  const events = [];
  const ctx = (sid) => ({ sid, notify: (c, p) => events.push({ sid, c, p }), openExternal: () => {} });
  const call = (sid, ch, p) => api.invoke(ch, ctx(sid), p);
  const PW = 'Owner-Passwort-123';
  const ownerSetup = async (sid = 1) => {
    const s = await call(sid, 'auth:setup', { username: 'chef', email: 'chef@example.com', password: PW });
    const e = await call(sid, 'auth:enroll', { code: totpAt(s.secret, clock.t) });
    return { secret: s.secret, enroll: e, setup: s };
  };
  const ownerStepUp = async (sid, secret) => call(sid, 'admin:stepUp', { password: PW, code: totpAt(secret, clock.t + 30000) });
  const newUser = async (sid, name = 'anna') => call(sid, 'auth:register', { username: name, email: `${name}@example.com`, password: "Sicheres-Passwort-99" });
  const wait = async (fn) => { for (let i = 0; i < 100 && !fn(); i++) await new Promise((r) => setTimeout(r, 10)); };
  return { dir, clock, svc, api, call, events, ended, PW, ownerSetup, ownerStepUp, newUser, wait };
}

console.log('Owner-Einrichtung');
await test('Erststart: Setup-Phase, Owner braucht 2FA, Klartext-Passwort nirgends gespeichert', async () => {
  const t = await env();
  assert.equal((await t.call(1, 'auth:status')).phase, 'setup');
  const s = await t.call(1, 'auth:setup', { username: 'chef', email: 'chef@example.com', password: t.PW });
  assert.equal(s.step, 'enroll'); assert.ok(s.secret && s.uri.startsWith('otpauth://totp/Zayriox'));
  assert.equal((await t.call(1, 'auth:status')).phase, 'login', 'ohne 2FA-Bestätigung keine Sitzung');
  assert.equal((await t.call(1, 'app:load')).code, 'UNAUTH');
  const bad = await t.call(1, 'auth:enroll', { code: '000000' });
  assert.equal(bad.ok, false);
  const ok = await t.call(1, 'auth:enroll', { code: totpAt(s.secret, t.clock.t) });
  assert.ok(ok.ok && ok.recoveryCodes.length === 8 && ok.user.role === 'owner');
  const files = fs.readdirSync(t.dir).filter((f) => fs.statSync(path.join(t.dir, f)).isFile()).map((f) => fs.readFileSync(path.join(t.dir, f), 'utf8'));
  assert.ok(files.every((c) => !c.includes(t.PW) && !c.includes(s.secret)), 'weder Passwort noch 2FA-Geheimnis im Klartext');
  assert.ok(files.join('').includes('scrypt$'));
});
await test('Es kann kein zweiter Owner entstehen', async () => {
  const t = await env(); await t.ownerSetup();
  const r = await t.call(9, 'auth:setup', { username: 'hacker', email: 'h@example.com', password: 'Hacker-Passwort-1' });
  assert.equal(r.ok, false); assert.equal(r.code, 'FORBIDDEN');
  const u = await t.newUser(2);
  assert.equal(u.user.role, 'user');
  assert.equal(t.svc.accounts.all().filter((x) => x.role === 'owner').length, 1);
});

console.log('Anmeldung, Login-Schutz, Sitzungen');
await test('Login mit 2FA; falsches Passwort gibt keine Auskunft, ob Nutzer existiert', async () => {
  const t = await env(); const o = await t.ownerSetup(); await t.call(1, 'auth:logout');
  const a = await t.call(5, 'auth:login', { username: 'chef', password: 'falsch-falsch-1' });
  const b = await t.call(5, 'auth:login', { username: 'gibtsnicht', password: 'falsch-falsch-1' });
  assert.equal(a.error, b.error);
  const l = await t.call(5, 'auth:login', { username: 'CHEF', password: t.PW });
  assert.equal(l.step, '2fa'); assert.equal((await t.call(5, 'app:load')).code, 'UNAUTH', 'vor 2FA keine Sitzung');
  t.clock.t += 30000;
  const v = await t.call(5, 'auth:verify2fa', { code: totpAt(o.secret, t.clock.t) });
  assert.ok(v.ok && v.step === 'done');
  assert.ok((await t.call(5, 'app:load')).ok);
});
await test('Gleicher 2FA-Code kann nicht zweimal benutzt werden (Replay)', async () => {
  const t = await env(); const o = await t.ownerSetup(); await t.call(1, 'auth:logout');
  await t.call(2, 'auth:login', { username: 'chef', password: t.PW });
  const r = await t.call(2, 'auth:verify2fa', { code: totpAt(o.secret, t.clock.t) }); // Code vom Einrichten, gleicher Zähler
  assert.equal(r.ok, false);
});
await test('Brute-Force: nach 5 Fehlversuchen Sperre, auch mit richtigem Passwort', async () => {
  const t = await env(); await t.ownerSetup(); await t.call(1, 'auth:logout');
  for (let i = 0; i < 5; i++) await t.call(3, 'auth:login', { username: 'chef', password: 'falsch-falsch-1' });
  const r = await t.call(3, 'auth:login', { username: 'chef', password: t.PW });
  assert.equal(r.code, 'LOCKED');
  t.clock.t += 61000;
  assert.equal((await t.call(3, 'auth:login', { username: 'chef', password: t.PW })).step, '2fa');
});
await test('2FA-Codes raten wird gebremst (auch bei bekanntem Passwort)', async () => {
  const t = await env(); await t.ownerSetup(); await t.call(1, 'auth:logout');
  await t.call(4, 'auth:login', { username: 'chef', password: t.PW });
  for (let i = 0; i < 6; i++) await t.call(4, 'auth:verify2fa', { code: String(100000 + i) });
  const r = await t.call(4, 'auth:verify2fa', { code: '123456' });
  assert.equal(r.ok, false);
  assert.ok(['LOCKED', 'EXPIRED'].includes(r.code));
});
await test('Wiederherstellungscode funktioniert genau einmal', async () => {
  const t = await env(); const o = await t.ownerSetup(); await t.call(1, 'auth:logout');
  const code = o.enroll.recoveryCodes[0];
  await t.call(2, 'auth:login', { username: 'chef', password: t.PW });
  assert.ok((await t.call(2, 'auth:verify2fa', { code })).ok);
  await t.call(2, 'auth:logout');
  await t.call(3, 'auth:login', { username: 'chef', password: t.PW });
  assert.equal((await t.call(3, 'auth:verify2fa', { code })).ok, false);
});
await test('Sitzung läuft ab: Nutzer 30 min, Owner 10 min Leerlauf', async () => {
  const t = await env(); await t.ownerSetup(); await t.newUser(2);
  t.clock.t += 11 * 60000;
  assert.equal((await t.call(1, 'app:load')).code, 'UNAUTH', 'Owner nach 11 min weg');
  assert.ok((await t.call(2, 'app:load')).ok, 'Nutzer nach 11 min noch da');
  t.clock.t += 31 * 60000;
  assert.equal((await t.call(2, 'app:load')).code, 'UNAUTH');
  assert.ok(t.ended.some(([sid, r]) => sid === 1 && r === 'idle'));
});
await test('Passwortwechsel beendet alle anderen Sitzungen', async () => {
  const t = await env(); await t.ownerSetup(); await t.newUser(2, 'anna');
  await t.call(3, 'auth:login', { username: 'anna', password: 'Sicheres-Passwort-99' });
  assert.ok((await t.call(3, 'app:load')).ok);
  assert.equal((await t.call(2, 'account:changePassword', { current: 'Sicheres-Passwort-99', next: 'Neues-Passwort-555' })).ok, true);
  assert.equal((await t.call(3, 'app:load')).code, 'UNAUTH');
  assert.ok((await t.call(2, 'app:load')).ok);
});

console.log('Owner-Schutz: ein kompromittierter Nutzer darf nichts');
await test('Nutzer kann KEINE Owner-Funktion ausführen (serverseitig geprüft)', async () => {
  const t = await env(); await t.ownerSetup(); await t.newUser(2, 'anna');
  for (const [ch, p] of [['admin:users'], ['admin:policyGet'], ['admin:policySet', { features: { voice: false } }], ['admin:audit'],
    ['admin:setStatus', { id: 'x', status: 'blocked' }], ['admin:deleteUser', { id: 'x' }], ['admin:setSearchKey', { key: 'k' }],
    ['admin:modelUse', 'mini'], ['admin:modelDownload', 'mini'], ['admin:stepUp', { password: 'x', code: '1' }]]) {
    const r = await t.call(2, ch, p);
    assert.equal(r.ok, false, ch); assert.equal(r.code, 'FORBIDDEN', ch);
  }
  assert.ok(t.svc.audit.read().some((e) => e.action === 'authz.denied'), 'Versuche stehen im Audit-Log');
});
await test('Nutzer kann sich nicht selbst zum Owner machen (Rolle kommt nie aus der Oberfläche)', async () => {
  const t = await env(); await t.ownerSetup(); await t.newUser(2, 'anna');
  await t.call(2, 'settings:save', { role: 'owner', isOwner: true });
  await t.call(2, 'auth:register', { username: 'x1x1x1', email: 'x@example.com', password: 'Xxxx-Passwort-99', role: 'owner' });
  assert.equal(t.svc.accounts.byName('anna').role, 'user');
  assert.equal(t.svc.accounts.all().filter((u) => u.role === 'owner').length, 1);
  assert.equal((await t.call(2, 'app:load')).user.role, 'user');
});
await test('Manipulierte Kontodatei (Rolle auf owner gesetzt) wird erkannt: alle Logins gesperrt', async () => {
  const t = await env(); const o = await t.ownerSetup(); await t.newUser(2, 'anna');
  const f = path.join(t.dir, 'accounts.json');
  const data = JSON.parse(fs.readFileSync(f, 'utf8'));
  data.users.find((u) => u.username === 'anna').role = 'owner';
  fs.writeFileSync(f, JSON.stringify(data));
  const t2 = createServices({ dir: t.dir, cipher: fileCipher(t.dir), engine: fakeLlm(), scryptN: 1024, now: () => t.clock.t });
  assert.equal(t2.accounts.state, 'tampered');
  assert.equal(t2.auth.status(1).phase, 'tampered');
  assert.equal((await t2.auth.login(1, { username: 'anna', password: 'Sicheres-Passwort-99' })).code, 'TAMPERED');
  assert.equal((await t2.auth.setupOwner(1, { username: 'neu', email: 'n@example.com', password: 'Neu-Passwort-1234' })).code, 'TAMPERED');
});
await test('Owner-Aktionen brauchen Step-up (Passwort + frischer 2FA-Code), Nutzer sperren/entsperren', async () => {
  const t = await env(); const o = await t.ownerSetup(); const u = await t.newUser(2, 'anna');
  const id = u.user.id;
  assert.equal((await t.call(1, 'admin:setStatus', { id, status: 'blocked' })).code, 'STEPUP');
  assert.equal((await t.call(1, 'admin:stepUp', { password: 'falsch', code: totpAt(o.secret, t.clock.t + 30000) })).ok, false);
  assert.ok((await t.ownerStepUp(1, o.secret)).ok);
  assert.ok((await t.call(1, 'admin:setStatus', { id, status: 'blocked' })).ok);
  assert.equal((await t.call(2, 'app:load')).code, 'UNAUTH', 'gesperrter Nutzer fliegt sofort raus');
  const l = await t.call(8, 'auth:login', { username: 'anna', password: 'Sicheres-Passwort-99' });
  assert.equal(l.code, 'BLOCKED');
  assert.ok((await t.call(1, 'admin:setStatus', { id, status: 'active' })).ok);
  assert.ok((await t.call(8, 'auth:login', { username: 'anna', password: 'Sicheres-Passwort-99' })).ok);
  t.clock.t += 6 * 60000; t.clock.t -= 6 * 60000; // Step-up-Zeit läuft nach 5 min ab:
  t.clock.t += 4 * 60000;
  assert.ok((await t.call(1, 'admin:policyGet')).ok);
});
await test('Step-up verfällt nach 5 Minuten', async () => {
  const t = await env(); const o = await t.ownerSetup(); const u = await t.newUser(2, 'anna');
  await t.ownerStepUp(1, o.secret);
  t.clock.t += 6 * 60000;
  await t.call(1, 'auth:ping'); // Owner-Leerlauf 10 min noch nicht erreicht
  assert.equal((await t.call(1, 'admin:setStatus', { id: u.user.id, status: 'blocked' })).code, 'STEPUP');
});
await test('Owner-Konto ist geschützt (nicht sperr-/löschbar), 2FA nicht abschaltbar', async () => {
  const t = await env(); const o = await t.ownerSetup(); await t.ownerStepUp(1, o.secret);
  const oid = t.svc.accounts.byName('chef').id;
  assert.equal((await t.call(1, 'admin:setStatus', { id: oid, status: 'blocked' })).code, 'FORBIDDEN');
  assert.equal((await t.call(1, 'admin:deleteUser', { id: oid })).code, 'FORBIDDEN');
  assert.equal((await t.call(1, 'account:totpDisable', { password: t.PW, code: '123456' })).code, 'FORBIDDEN');
  assert.equal((await t.call(1, 'account:delete', { password: t.PW })).code, 'FORBIDDEN');
});
await test('Audit-Log: Hash-Kette erkennt nachträgliche Änderungen; keine Geheimnisse im Log', async () => {
  const t = await env(); const o = await t.ownerSetup(); await t.newUser(2);
  await t.call(3, 'auth:login', { username: 'chef', password: 'falsch-falsch-1' });
  const a = await t.call(1, 'admin:audit');
  assert.ok(a.integrity.ok && a.entries.length >= 4);
  const raw = fs.readFileSync(path.join(t.dir, 'audit.log'), 'utf8');
  assert.ok(!raw.includes(t.PW) && !raw.includes(o.secret) && !raw.includes('falsch-falsch'));
  fs.writeFileSync(path.join(t.dir, 'audit.log'), raw.replace('login.fail', 'login.ok_'));
  assert.equal(new AuditLog(path.join(t.dir, 'audit.log')).verify().ok, false);
});

console.log('Policy: Limits, Wartungsmodus, Funktionen, Geheimnisse');
const msg = (text, extra = {}) => ({ requestId: 'r' + Math.random(), mode: 'schnell', messages: [{ role: 'user', content: text }], ...extra });
await test('Chat end-to-end: Antwort, Nutzungszähler, Chats pro Nutzer getrennt', async () => {
  const t = await env(); await t.ownerSetup(); await t.newUser(2, 'anna'); await t.newUser(3, 'bob');
  const p = msg('Hallo'); assert.ok((await t.call(2, 'chat:send', p)).ok);
  await t.wait(() => t.events.some((e) => e.p.type === 'done'));
  assert.ok(t.events.some((e) => e.sid === 2 && e.p.type === 'token' && e.p.text === 'Antwort'));
  assert.equal(t.svc.policy.usageOf(t.svc.accounts.byName('anna').id).msgs, 1);
  await t.call(2, 'chats:save', [{ id: 'c1', title: 'Annas Chat', messages: [{ role: 'user', content: 'geheim' }] }]);
  assert.equal((await t.call(2, 'app:load')).chats.length, 1);
  assert.equal((await t.call(3, 'app:load')).chats.length, 0, 'Bob sieht Annas Chats nicht');
});
await test('Tageslimit wird serverseitig erzwungen (Owner unbegrenzt)', async () => {
  const t = await env(); const o = await t.ownerSetup(); await t.newUser(2, 'anna');
  await t.ownerStepUp(1, o.secret);
  await t.call(1, 'admin:policySet', { limits: { messagesPerDay: 2, heavyPerDay: 1 } });
  for (let i = 0; i < 2; i++) { t.events.length = 0; assert.ok((await t.call(2, 'chat:send', msg('Hi'))).ok); await t.wait(() => t.events.some((e) => e.p.type === 'done')); }
  const r = await t.call(2, 'chat:send', msg('Hi')); assert.equal(r.code, 'LIMIT');
  for (let i = 0; i < 3; i++) { assert.ok((await t.call(1, 'chat:send', msg('Hi'))).ok, 'Owner unbegrenzt'); await t.wait(() => !t.api.isBusy()); }
  t.clock.t += 86400000 + 1000; // nächster Tag
  assert.ok((await t.call(2, 'auth:login', { username: 'anna', password: 'Sicheres-Passwort-99' })).ok);
  assert.ok((await t.call(2, 'chat:send', msg('Hi'))).ok, 'Zähler wurde zurückgesetzt');
});
await test('Wartungsmodus sperrt Nutzer, Owner darf weiter', async () => {
  const t = await env(); const o = await t.ownerSetup(); await t.newUser(2, 'anna');
  await t.ownerStepUp(1, o.secret);
  await t.call(1, 'admin:policySet', { maintenance: { on: true, message: 'Wir bauen um.' } });
  const r = await t.call(2, 'chat:send', msg('Hi')); assert.equal(r.code, 'MAINTENANCE'); assert.equal(r.error, 'Wir bauen um.');
  assert.ok((await t.call(1, 'chat:send', msg('Hi'))).ok);
});
await test('Deaktivierte Funktionen/Stufen werden serverseitig abgelehnt; Auto weicht aus', async () => {
  const t = await env(); const o = await t.ownerSetup(); await t.newUser(2, 'anna');
  await t.ownerStepUp(1, o.secret);
  await t.call(1, 'admin:policySet', { features: { uploads: false, imageAnalysis: false, registration: false }, modes: { promax: false, hoch: false } });
  assert.equal((await t.call(2, 'chat:send', msg('x', { messages: [{ role: 'user', content: 'x', attach: [{ name: 'a.txt', text: 'hi' }] }] }))).code, 'FEATURE_OFF');
  assert.equal((await t.call(2, 'file:extract', { name: 'a.txt', data: Buffer.from('hi') })).code, 'FEATURE_OFF');
  assert.equal((await t.call(2, 'chat:send', msg('x', { mode: 'promax' }))).code, 'MODE_OFF');
  assert.equal((await t.call(9, 'auth:register', { username: 'neuling', email: 'n@example.com', password: 'Pass-Wort-12345' })).code, 'FEATURE_OFF');
  const load = await t.call(2, 'app:load'); assert.deepEqual(load.modes.map((m) => m.id), ['auto', 'schnell', 'mittel']);
  const hard = 'Berechne Schritt für Schritt das Integral und beweise das Ergebnis mit allen Zwischenschritten ausführlich. '.repeat(3);
  assert.ok((await t.call(2, 'chat:send', msg(hard, { mode: 'auto' }))).ok);
  await t.wait(() => t.events.some((e) => e.p.type === 'mode'));
  assert.equal(t.events.find((e) => e.p.type === 'mode').p.mode, 'mittel');
});
await test('Ungültige/zu große Anfragen werden abgelehnt', async () => {
  assert.throws(() => validateSend({ requestId: 'x', messages: [{ role: 'system', content: 'hack' }] }));
  assert.throws(() => validateSend({ requestId: 'x', messages: [{ role: 'user', content: 'a'.repeat(8001) }] }));
  assert.throws(() => validateSend({ requestId: 'x', messages: [{ role: 'user', content: 'x' }], images: [{ name: 'a.png', data: Buffer.from('kein bild, nur text hier!') }] }));
  assert.throws(() => validateSend(null));
});
await test('Suchschlüssel: verschlüsselt gespeichert, nie zurück an die Oberfläche', async () => {
  const t = await env(); const o = await t.ownerSetup(); await t.ownerStepUp(1, o.secret);
  const r = await t.call(1, 'admin:setSearchKey', { key: 'BSA-geheimer-schluessel-123' });
  assert.equal(r.policy.searchKeySet, true);
  assert.ok(!JSON.stringify(r).includes('BSA-geheimer') && !JSON.stringify(await t.call(1, 'admin:policyGet')).includes('BSA-geheimer'));
  assert.ok(!fs.readFileSync(path.join(t.dir, 'policy.json'), 'utf8').includes('BSA-geheimer'), 'nicht im Klartext auf der Platte');
  assert.ok(!JSON.stringify(await t.call(1, 'app:load')).includes('BSA-geheimer'));
  await t.call(1, 'admin:policySet', { secrets: { braveKey: 'einschleusen' } });
  assert.ok(!fs.readFileSync(path.join(t.dir, 'policy.json'), 'utf8').includes('einschleusen'));
});
await test('Unbekannte Kanäle und Prototype-Tricks werden abgewiesen', async () => {
  const t = await env();
  for (const ch of ['__proto__', 'constructor', 'toString', 'admin:__x', '']) assert.equal((await t.call(1, ch)).ok, false, ch);
});

console.log('Websuche, Bilder, Sprache');
const DDG = `<div class="result"><h2 class="result__title"><a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fde.wikipedia.org%2Fwiki%2FBerlin&amp;rut=abc">Berlin – <b>Wikipedia</b></a></h2>
<a class="result__snippet" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fde.wikipedia.org%2Fwiki%2FBerlin">Berlin ist die Hauptstadt &amp; größte Stadt Deutschlands.</a></div>
<div class="result"><a class="result__a" href="//duckduckgo.com/y.js?ad_provider=x">Werbung</a><a class="result__snippet" href="#">Kauf mich</a></div>
<div class="result"><a class="result__a" href="https://example.org/x">Beispiel</a></div>
<div class="result"><a class="result__a" href="javascript:alert(1)">Böse</a></div>`;
await test('DuckDuckGo-Ergebnisse werden geparst (Werbung/javascript: gefiltert)', () => {
  const r = parseDuckDuckGo(DDG);
  assert.deepEqual(r.map((x) => x.url), ['https://de.wikipedia.org/wiki/Berlin', 'https://example.org/x']);
  assert.equal(r[0].title, 'Berlin – Wikipedia'); assert.ok(r[0].snippet.includes('Hauptstadt & größte'));
});
await test('webSearch: Timeout/Fehler werfen, Brave-Schlüssel nur im Header', async () => {
  let seen;
  const ok = await webSearch('Berlin', { provider: 'brave', braveKey: 'K123', fetchImpl: async (url, o) => { seen = { url, o }; return { ok: true, json: async () => ({ web: { results: [{ title: 'T', url: 'https://a.de', description: 'D' }, { title: 'X', url: 'ftp://x', description: '' }] } }) }; } });
  assert.equal(ok.length, 1); assert.equal(seen.o.headers['X-Subscription-Token'], 'K123'); assert.ok(!seen.url.includes('K123'));
  await assert.rejects(webSearch('x', { fetchImpl: async () => ({ ok: false, status: 503 }) }));
});
await test('Chat mit Websuche: Quellen kommen mit; Suchfehler bricht den Chat nicht ab', async () => {
  const realFetch = globalThis.fetch;
  try {
    globalThis.fetch = async () => ({ ok: true, text: async () => DDG });
    const t = await env(); await t.ownerSetup();
    const llm = t.svc.engine;
    assert.ok((await t.call(1, 'chat:send', msg('Was ist Berlin?', { webSearch: true }))).ok);
    await t.wait(() => t.events.some((e) => e.p.type === 'done'));
    assert.equal(t.events.find((e) => e.p.type === 'sources').p.sources.length, 2);
    assert.ok(llm.calls[0].system.includes('[1] Berlin – Wikipedia') );
    globalThis.fetch = async () => { throw new Error('offline'); };
    t.events.length = 0;
    assert.ok((await t.call(1, 'chat:send', msg('Was ist Berlin?', { webSearch: true }))).ok);
    await t.wait(() => t.events.some((e) => e.p.type === 'done'));
    assert.ok(t.events.some((e) => e.p.type === 'notice') && t.events.some((e) => e.p.type === 'token'));
  } finally { globalThis.fetch = realFetch; }
});
await test('Bild-Anhang: Bildbeschreibung fließt in die Anfrage; Format wird an den Bytes erkannt', async () => {
  const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(20)]);
  assert.equal(sniffImage(png), 'image/png'); assert.equal(sniffImage(Buffer.from('MZ.exe.exe.exe.')), null);
  const t = await env({ ml: { describeImage: async () => 'Ein roter Apfel auf einem Tisch.' } }); await t.ownerSetup();
  const r = await t.call(1, 'chat:send', msg('Was siehst du?', { images: [{ name: 'apfel.png', data: png }] }));
  assert.ok(r.ok);
  await t.wait(() => t.events.some((e) => e.p.type === 'done'));
  assert.ok(t.events.some((e) => e.p.type === 'image-desc'));
  assert.ok(t.svc.engine.calls.at(-1).user.includes('roter Apfel'));
});
await test('Audio-Prüfung (Länge, Format, ungültige Werte)', async () => {
  assert.ok(validateAudio(new Float32Array(16000)));
  assert.equal(validateAudio(new Float32Array(100)), null);
  assert.equal(validateAudio(new Float32Array(16000 * 100)), null);
  assert.equal(validateAudio(new Uint8Array(3)), null);
  const nan = new Float32Array(16000); nan[0] = NaN; assert.equal(validateAudio(nan), null);
  assert.equal(toFloat32(new Float32Array([1, 2]).buffer).length, 2);
  const t = await env({ ml: { transcribe: async (f) => `Hallo (${f.length})` } }); await t.newUser(2).catch(() => {}); await t.ownerSetup();
  assert.equal((await t.call(1, 'voice:transcribe', new Float32Array(16000))).text, 'Hallo (16000)');
  assert.equal((await t.call(1, 'voice:transcribe', new Float32Array(5))).ok, false);
});


// =====================================================================
// Echte Testdateien, Ausweichsuche, Rechte-Fuzzing, Secrets, Fehlerfälle
// =====================================================================
const { makePdf, makePng, makeWav } = await import(url('src/fixtures.js'));
const { wikipediaSearch, webSearchWithFallback } = await import(url('src/search.js'));
const { wavToFloat32 } = await import(url('src/media.js'));
const { MESSAGES } = await import(url('src/errors.js'));

console.log('Echte Testdateien (PDF, PNG, WAV)');
await test('PDF: gültige Struktur, xref-Offsets stimmen', () => {
  const pdf = makePdf(['Zayriox PDF Test 12345', 'Zeile (mit) Klammern']).toString('latin1');
  assert.ok(pdf.startsWith('%PDF-1.4') && pdf.trimEnd().endsWith('%%EOF'));
  const start = Number(/startxref\n(\d+)/.exec(pdf)[1]);
  assert.equal(pdf.slice(start, start + 4), 'xref');
  const offs = [...pdf.slice(start).matchAll(/(\d{10}) 00000 n/g)].map((m) => Number(m[1]));
  assert.equal(offs.length, 5);
  offs.forEach((o, i) => assert.ok(pdf.slice(o).startsWith(`${i + 1} 0 obj`), `Objekt ${i + 1}`));
  assert.ok(pdf.includes('(Zayriox PDF Test 12345) Tj'));
});
await test('PNG: Signatur, IHDR und CRC aller Chunks korrekt, wird als Bild erkannt', async () => {
  const zlib = await import('node:zlib');
  const png = makePng(64);
  assert.equal(sniffImage(png), 'image/png');
  let pos = 8; const types = [];
  while (pos < png.length) {
    const len = png.readUInt32BE(pos), type = png.toString('latin1', pos + 4, pos + 8), body = png.subarray(pos + 4, pos + 8 + len), crc = png.readUInt32BE(pos + 8 + len);
    let c = 0xffffffff; for (const b of body) { c ^= b; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; }
    assert.equal((c ^ 0xffffffff) >>> 0, crc, `CRC ${type}`);
    types.push(type); pos += 12 + len;
  }
  assert.deepEqual(types, ['IHDR', 'IDAT', 'IEND']);
  assert.equal(png.readUInt32BE(16), 64);
  const raw = zlib.inflateSync(png.subarray(png.indexOf('IDAT') + 4, png.indexOf('IEND') - 8));
  assert.equal(raw.length, 64 * (1 + 64 * 3));
});
await test('WAV: 22,05 kHz -> 16 kHz, Stereo/8-Bit/Float, kaputte Dateien -> null', () => {
  assert.equal(wavToFloat32(makeWav(1, 22050)).length, 16000);
  assert.equal(wavToFloat32(makeWav(2, 16000)).length, 32000);
  assert.equal(wavToFloat32(Buffer.from('kein wav, nur text ....................................')), null);
  assert.equal(wavToFloat32(Buffer.alloc(10)), null);
  const f = wavToFloat32(makeWav(0.5, 16000, 440)); assert.ok(Math.max(...f) > 0.3 && Math.max(...f) <= 1);
  const st = makeWav(1, 16000); st.writeUInt16LE(2, 22); st.writeUInt32LE(16000 * 4, 28); st.writeUInt16LE(4, 32);
  assert.equal(wavToFloat32(st).length, 8000, 'Stereo: Frames = Bytes/4');
});
await test('Upload echter Dateien: TXT/Code/PDF-Weg (PDF-Parser läuft im Windows-Build)', async () => {
  const t = await env(); await t.ownerSetup();
  const txt = await t.call(1, 'file:extract', { name: 'notiz.txt', data: Buffer.from('Geheimzahl 4711\r\nZeile 2') });
  assert.ok(txt.ok && txt.text === 'Geheimzahl 4711\nZeile 2');
  const py = await t.call(1, 'file:extract', { name: 'a.py', data: Buffer.from('def f():\n    return 1\n') });
  assert.ok(py.ok && py.text.includes('def f'));
  const exe = await t.call(1, 'file:extract', { name: 'x.exe', data: Buffer.from('MZ\0\0') });
  assert.equal(exe.ok, false); assert.match(exe.error, /nicht unterstützt/);
  const big = await t.call(1, 'file:extract', { name: 'big.txt', data: Buffer.alloc(6 * 1024 * 1024, 65) });
  assert.equal(big.code, 'FILE_TOO_BIG');
});

console.log('Websuche mit Ausweichquelle');
const WIKI = { query: { search: [{ title: 'Berlin', snippet: 'Berlin ist die <span class="searchmatch">Hauptstadt</span> Deutschlands.' }, { title: 'Geschichte Berlins', snippet: 'x' }] } };
await test('Wikipedia-Suche liefert https-Artikel-Links', async () => {
  const r = await wikipediaSearch('Berlin', { fetchImpl: async () => ({ ok: true, json: async () => WIKI }) });
  assert.deepEqual(r.map((x) => x.url), ['https://de.wikipedia.org/wiki/Berlin', 'https://de.wikipedia.org/wiki/Geschichte_Berlins']);
  assert.ok(r[0].snippet.includes('Hauptstadt') && !r[0].snippet.includes('<'));
});
await test('Ausweichkette: DDG leer/Fehler -> Wikipedia; DDG ok -> keine 2. Anfrage; beide down -> Fehler', async () => {
  const real = globalThis.fetch; let calls = [];
  try {
    globalThis.fetch = async (u) => { calls.push(u); return u.includes('duckduckgo') ? { ok: true, text: async () => '<html>Bot-Prüfung</html>' } : { ok: true, json: async () => WIKI }; };
    assert.equal((await webSearchWithFallback('Berlin')).length, 2); assert.equal(calls.length, 2);
    calls = []; globalThis.fetch = async (u) => { calls.push(u); if (u.includes('duckduckgo')) throw new Error('403'); return { ok: true, json: async () => WIKI }; };
    assert.equal((await webSearchWithFallback('Berlin')).length, 2);
    calls = []; globalThis.fetch = async (u) => { calls.push(u); return { ok: true, text: async () => DDG }; };
    assert.equal((await webSearchWithFallback('Berlin')).length, 2); assert.equal(calls.length, 1, 'Wikipedia nicht nötig');
    globalThis.fetch = async () => { throw new Error('offline'); };
    await assert.rejects(webSearchWithFallback('Berlin'));
  } finally { globalThis.fetch = real; }
});

console.log('Rechte-Fuzzing: normale Nutzer werden nie Owner');
await test('Alle Owner-Kanäle × böse Payloads (inkl. __proto__) -> immer FORBIDDEN, Zustand unverändert', async () => {
  const t = await env(); const o = await t.ownerSetup(); await t.newUser(2, 'anna');
  const before = JSON.stringify({ users: t.svc.accounts.all(), policy: t.svc.policy.get() });
  const payloads = [undefined, null, 0, 'x', [], {}, { role: 'owner' }, JSON.parse('{"__proto__":{"role":"owner","isOwner":true}}'), JSON.parse('{"id":"x","status":"active","role":"owner","features":{"voice":false}}'), { key: 'k'.repeat(500) }, 'a'.repeat(100000)];
  const adminChannels = t.api.channels.filter((c) => c.startsWith('admin:'));
  assert.ok(adminChannels.length >= 10);
  for (const ch of adminChannels) for (const p of payloads) {
    const r = await t.call(2, ch, p);
    assert.equal(r.ok, false, `${ch}`); assert.equal(r.code, 'FORBIDDEN', `${ch} -> ${r.code}`);
  }
  for (const ch of ['auth:setup']) for (const p of payloads) assert.equal((await t.call(2, ch, p)).ok, false, ch);
  assert.equal(({}).role, undefined, 'kein Prototype-Pollution');
  assert.equal(JSON.stringify({ users: t.svc.accounts.all(), policy: t.svc.policy.get() }), before, 'Konten und Regeln unverändert');
  assert.equal(t.svc.accounts.byName('anna').role, 'user');
  assert.equal((await t.call(2, 'app:load')).user.role, 'user');
});
await test('Nicht angemeldet: jeder geschützte Kanal liefert UNAUTH (nie Daten)', async () => {
  const t = await env(); await t.ownerSetup();
  const open = new Set(['auth:status', 'auth:setup', 'auth:register', 'auth:login', 'auth:verify2fa', 'auth:enroll', 'auth:logout', 'auth:qr']);
  for (const ch of t.api.channels.filter((c) => !open.has(c))) { const r = await t.call(777, ch, { name: 'a.txt', data: Buffer.from('x') }); assert.equal(r.ok, false, ch); assert.equal(r.code, 'UNAUTH', ch); }
});
await test('Gesperrter Nutzer/Owner-Eskalation über andere Sitzung ID nicht möglich', async () => {
  const t = await env(); await t.ownerSetup(); await t.newUser(2, 'anna');
  assert.equal((await t.call(3, 'admin:users')).code, 'UNAUTH');   // fremde Sitzung-ID ohne Login
  assert.equal((await t.call(2, 'admin:users')).code, 'FORBIDDEN'); // eingeloggter Nutzer
});

console.log('QR-Code, Tarifkatalog');
await test('auth:qr nimmt nur otpauth://-Links (max. 2048 Zeichen); fehlt die Bibliothek, gibt es eine verständliche Ausweichmeldung', async () => {
  const t = await env();
  for (const bad of [undefined, null, 5, {}, 'https://evil.example', 'javascript:alert(1)', 'otpauth://' + 'a'.repeat(2100)]) assert.equal((await t.call(1, 'auth:qr', bad)).code, 'INVALID');
  const r = await t.call(1, 'auth:qr', 'otpauth://totp/Zayriox:x?secret=ABC');
  assert.ok(r.ok ? r.dataUrl.startsWith('data:image/png') : r.code === 'QR_UNAVAILABLE' && /manuell/.test(r.error));
});
await test('Tarifkatalog: nur Anzeige-Daten, kein Geheimnis, Owner-Tarif nicht zuweisbar', async () => {
  const { TARIFFS } = await import(url('src/tariffs.js'));
  assert.ok(TARIFFS.length >= 5 && TARIFFS.every((x) => x.id && x.name && typeof x.priceEUR === 'number'));
  const t = await env(); await t.ownerSetup(); await t.newUser(2, 'anna');
  const load = await t.call(2, 'app:load'); assert.ok(Array.isArray(load.tariffs));
  assert.equal((await t.call(2, 'settings:save', { tariff: 'owner', role: 'owner' })).ok, true);
  assert.equal((await t.call(2, 'app:load')).user.role, 'user', 'Tarif/Owner lässt sich nicht über Einstellungen setzen');
});

console.log('Keine Secrets im Frontend');
await test('Antworten an die Oberfläche enthalten nie Hashes, 2FA-Geheimnisse, Recovery-Hashes oder Schlüssel', async () => {
  const t = await env(); const o = await t.ownerSetup(); await t.newUser(2, 'anna'); await t.ownerStepUp(1, o.secret);
  await t.call(1, 'admin:setSearchKey', { key: 'BSA-supergeheim-98765' });
  const all = JSON.stringify([await t.call(1, 'app:load'), await t.call(1, 'admin:users'), await t.call(1, 'admin:policyGet'), await t.call(1, 'admin:audit'), await t.call(1, 'auth:status'), await t.call(2, 'app:load')]);
  for (const bad of ['scrypt$', o.secret, 'BSA-supergeheim', '"pw"', '"recovery"', 'vault', 'macKey', 'sealed']) assert.ok(!all.includes(bad), `Leck: ${bad}`);
  for (const h of t.svc.accounts.byName('chef').recovery) assert.ok(!all.includes(h));
});
await test('Quellcode: keine Schlüssel im Code, Oberfläche ohne Netzwerkaufrufe, kein localhost', () => {
  const walk = (d) => fs.readdirSync(rel(d)).filter((f) => /\.(js|cjs|html|json)$/.test(f)).map((f) => ({ f: `${d}/${f}`, t: fs.readFileSync(rel(`${d}/${f}`), 'utf8') }));
  const src = [...walk('src'), ...walk('renderer'), { f: 'package.json', t: fs.readFileSync(rel('package.json'), 'utf8') }].filter((x) => x.f !== 'src/selftest.js');
  const SECRET = /(sk-[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|(api[_-]?key|token|secret|password)\s*[:=]\s*['"][A-Za-z0-9_\-+/=]{16,}['"]|Bearer\s+[A-Za-z0-9._-]{20,})/i;
  assert.deepEqual(src.filter((x) => SECRET.test(x.t)).map((x) => x.f), []);
  const ui = walk('renderer').filter((x) => x.f.endsWith('.js'));
  assert.deepEqual(ui.filter((x) => /\bfetch\s*\(|XMLHttpRequest|WebSocket|EventSource/.test(x.t)).map((x) => x.f), []);
  assert.deepEqual(src.filter((x) => /(localhost|127\.0\.0\.1|0\.0\.0\.0)/.test(x.t)).map((x) => x.f), []);
  assert.ok(!src.some((x) => /http\.createServer|net\.createServer|\.listen\(/.test(x.t)), 'App startet keinen Server');
  const gi = fs.readFileSync(rel('.gitignore'), 'utf8'); assert.ok(gi.includes('.env') && gi.includes('*.gguf'));
});
await test('CSP: nur eigene Skripte, keine Inline-Skripte, keine externen Verbindungen', () => {
  for (const f of ['renderer/index.html', 'renderer/splash.html']) {
    const h = fs.readFileSync(rel(f), 'utf8');
    const csp = /Content-Security-Policy" content="([^"]+)"/.exec(h)[1];
    assert.ok(csp.includes("default-src 'self'") && csp.includes("script-src 'self'") && !csp.includes("script-src 'self' 'unsafe") && !/https?:/.test(csp), f);
    assert.ok(!/<script(?![^>]*\bsrc=)[^>]*>[^<]/.test(h), `Inline-Skript in ${f}`);
    assert.ok(!/(src|href)="https?:/.test(h), `externe Ressource in ${f}`);
  }
});

console.log('Fehlerfälle: verständliche Meldungen');
await test('Alle Fehlertexte sind deutsch, ohne Technik-Kauderwelsch', () => {
  for (const [k, v] of Object.entries(MESSAGES)) { assert.ok(v.length > 15 && !/(Error|ECONN|ENOENT|undefined|null|404|500|stack|at \w+\()/.test(v), `${k}: ${v}`); }
});
await test('Ohne Modell: Chat meldet verständlich statt abzustürzen; App bleibt bedienbar', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'zayriox-nm-'));
  const t = await env({ engine: new Engine({ modelsDir: dir, onStatus: () => {} }) }); await t.ownerSetup();
  assert.ok((await t.call(1, 'chat:send', msg('Hallo'))).ok);
  await t.wait(() => t.events.some((e) => e.p.type === 'error'));
  const e = t.events.find((x) => x.p.type === 'error').p;
  assert.equal(e.message, MESSAGES.NO_MODEL);
  assert.ok((await t.call(1, 'app:load')).ok, 'App lebt weiter');
  assert.ok(!t.api.isBusy(), 'nächste Anfrage möglich');
});
await test('Abbruch über Stopp beendet Anfrage sauber; Nutzer kann fremde Anfrage nicht stoppen', async () => {
  const slow = fakeLlm(); slow.complete = async (o) => { for (let i = 0; i < 200 && !o.signal.aborted; i++) { o.onText('x'); await new Promise((r) => setTimeout(r, 10)); } return 'x'; };
  const t = await env({ engine: slow }); await t.ownerSetup(); await t.newUser(2, 'anna');
  const p = msg('lang'); assert.ok((await t.call(1, 'chat:send', p)).ok);
  await t.wait(() => t.events.some((e) => e.p.type === 'token'));
  assert.equal((await t.call(2, 'chat:send', msg('gleichzeitig'))).code, 'BUSY');
  await t.call(2, 'chat:stop', p.requestId);
  await new Promise((r) => setTimeout(r, 60)); assert.ok(t.api.isBusy(), 'fremder Stopp wirkt nicht');
  await t.call(1, 'chat:stop', p.requestId);
  await t.wait(() => t.events.some((e) => e.p.type === 'done'));
  assert.equal(t.events.find((e) => e.p.type === 'done').p.stopped, true);
  assert.ok((await t.call(1, 'chat:send', msg('danach'))).ok, 'nach Stopp wieder nutzbar');
});
await test('Registrierung/Passwort: verständliche Validierungsfehler', async () => {
  const t = await env(); await t.ownerSetup();
  for (const [b, re] of [[{ username: 'a', email: 'x@y.de', password: 'Sicheres-Passwort-99' }, /Benutzername/], [{ username: 'gut_name', email: 'kaputt', password: 'Sicheres-Passwort-99' }, /E-Mail/], [{ username: 'gut_name', email: 'x@y.de', password: 'zu-kurz1' }, /10 Zeichen/]]) {
    const r = await t.call(5, 'auth:register', b); assert.equal(r.ok, false); assert.match(r.error, re);
  }
});

console.log(`\n${passed} bestanden, ${failed.length} fehlgeschlagen`);
if (failed.length) { console.log('Fehlgeschlagen:', failed.join(', ')); process.exit(1); }
