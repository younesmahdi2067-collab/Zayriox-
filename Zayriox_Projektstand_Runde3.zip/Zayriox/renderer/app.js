(function () {
  'use strict';
  var ZX = window.ZX, S = ZX.S, $ = ZX.$, esc = ZX.esc, api = ZX.api, icon = ZX.icon, toast = ZX.toast, uid = ZX.uid;

  // ---------- Hilfsfunktionen ----------
  function copyText(text) {
    return Promise.resolve().then(function () { return navigator.clipboard.writeText(text); }).catch(function () {
      var ta = document.createElement('textarea');
      ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      var ok = document.execCommand('copy');
      ta.remove();
      if (!ok) throw new Error('copy failed');
    });
  }
  var saveTimer = null;
  function persist() { clearTimeout(saveTimer); saveTimer = setTimeout(persistNow, 400); }
  function persistNow() { clearTimeout(saveTimer); api.saveChats(S.chats).then(function (r) { ZX.authLost(r); }); }
  function activeChat() { return S.chats.find(function (c) { return c.id === S.activeId; }) || null; }
  function modeLabel(id) { var m = S.modes.find(function (x) { return x.id === id; }); return m ? m.label : id; }
  function modelName(id) { var m = S.models.find(function (x) { return x.id === id; }); return m ? m.name : 'Modell'; }
  function titleFrom(t) { var l = String(t).split('\n')[0].trim(); return l.length > 42 ? l.slice(0, 42) + '…' : l || 'Neuer Chat'; }
  function applyTheme() { document.documentElement.dataset.theme = S.settings.theme; }
  function isOwner() { return !!S.user && S.user.role === 'owner'; }
  ZX.saveSettings = function (patch) {
    Object.assign(S.settings, patch);
    applyTheme();
    return api.saveSettings(patch).then(function (r) { ZX.authLost(r); return r; });
  };
  function notReadyText() {
    var e = S.engine;
    if (e.state === 'loading') return 'Das KI-Modell wird gerade geladen. Einen Moment noch.';
    if (e.state === 'error') return 'Das KI-Modell konnte nicht geladen werden. ' + (isOwner() ? 'Öffne den Owner-Bereich → KI-Modell.' : 'Bitte wende dich an den Owner.');
    return isOwner() ? 'Zayriox braucht zuerst sein KI-Modell (Startseite oder Owner-Bereich → KI-Modell).' : 'Der Owner muss zuerst das KI-Modell installieren.';
  }
  ZX.hooks.notReadyText = notReadyText;

  // ---------- Sidebar ----------
  function groupOf(ts) {
    var now = new Date(), s0 = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime(), day = 86400000;
    if (ts >= s0) return 'Heute';
    if (ts >= s0 - day) return 'Gestern';
    if (ts >= s0 - 7 * day) return 'Letzte 7 Tage';
    return 'Älter';
  }
  function renderSidebar() {
    var q = S.search.trim().toLowerCase();
    var list = S.chats.slice().sort(function (a, b) { return b.updatedAt - a.updatedAt; }).filter(function (c) {
      if (!q) return true;
      return c.title.toLowerCase().indexOf(q) !== -1 || c.messages.some(function (m) { return m.content.toLowerCase().indexOf(q) !== -1; });
    });
    var html = '', last = '';
    list.forEach(function (c) {
      var g = groupOf(c.updatedAt);
      if (g !== last) { html += '<div class="group-title">' + g + '</div>'; last = g; }
      html += '<div class="chat-item' + (c.id === S.activeId ? ' active' : '') + '" data-id="' + esc(c.id) + '"><span class="t">' + esc(c.title) + '</span><span class="acts">' +
        '<button class="icon-btn" data-act="rename" title="Umbenennen" aria-label="Umbenennen">' + icon('edit', 15) + '</button>' +
        '<button class="icon-btn" data-act="delete" title="Löschen" aria-label="Löschen">' + icon('trash', 15) + '</button></span></div>';
    });
    if (!list.length) html = '<div class="empty-list">' + (q ? 'Keine passenden Chats.' : 'Noch keine Chats. Schreibe Zayriox eine Nachricht!') + '</div>';
    $('#chatList').innerHTML = html;
    var u = S.user || {};
    $('#pname').textContent = S.settings.name || u.username || 'Konto';
    $('#prole').textContent = u.role === 'owner' ? 'Owner' : 'Läuft auf diesem Gerät';
    $('#avatar').textContent = (S.settings.name || u.username || 'Z').trim().charAt(0).toUpperCase();
    $('#btnOwner').hidden = !isOwner();
  }

  // ---------- Nachrichten ----------
  function tagFor(m) { return m.modeUsed ? '<span class="tag">' + (m.auto ? 'Auto → ' : '') + esc(modeLabel(m.modeUsed)) + '</span>' : ''; }
  function sourcesHTML(m) {
    if (!m.sources || !m.sources.length) return '';
    return '<div class="sources"><span>Quellen</span>' + m.sources.map(function (s, i) {
      return '<a href="#" data-href="' + esc(s.url) + '" title="' + esc(s.url) + '">' + (i + 1) + ' · ' + esc(s.title || s.url) + '</a>';
    }).join('') + '</div>';
  }
  function assistantInner(m, live, isLast) {
    var h = '';
    if (m.thinking) {
      var thinking = live && !m.content;
      h += '<details class="think' + (thinking ? ' live' : '') + '"' + (m._open ? ' open' : '') + '><summary><span>' + (thinking ? 'Zayriox denkt nach…' : 'Gedanken anzeigen') +
        '</span></summary><div class="tb">' + esc(m.thinking) + '</div></details>';
    }
    if (live && m.status && !m.content) h += '<div class="statusline"><div class="dots"><i></i><i></i><i></i></div>' + esc(m.status) + '</div>';
    if (m.notice) h += '<div class="notice">' + esc(m.notice) + '</div>';
    if (m.content) h += '<div class="md">' + window.ZxMD.render(m.content) + '</div>';
    else if (live && !m.thinking && !m.status) h += '<div class="dots"><i></i><i></i><i></i></div>';
    h += sourcesHTML(m);
    if (m.error) h += '<div class="err">' + icon('warn', 18) + '<div>' + esc(m.error) + '</div></div>';
    if (!live) {
      h += '<div class="meta">' +
        (m.content ? '<button class="icon-btn" data-act="copy" title="Kopieren" aria-label="Kopieren">' + icon('copy', 16) + '</button>' +
          '<button class="icon-btn" data-act="speak" title="Vorlesen" aria-label="Vorlesen">' + icon('speaker', 16) + '</button>' : '') +
        (isLast && !S.busy ? '<button class="icon-btn" data-act="regen" title="Neu generieren" aria-label="Neu generieren">' + icon('redo', 16) + '</button>' : '') +
        tagFor(m) + (m.stopped ? '<span class="stopped-note">Gestoppt</span>' : '') + '</div>';
    }
    return h;
  }
  function messageHTML(m, isLast) {
    if (m.role === 'user') {
      var files = (m.files || []).map(function (f) { return '<span class="file-tag">' + icon('file', 14) + esc(f) + '</span>'; }).join('');
      return '<div class="msg user" data-id="' + esc(m.id) + '"><div class="wrap">' + (files ? '<div class="files">' + files + '</div>' : '') +
        (m.content ? '<div class="bubble">' + esc(m.content) + '</div>' : '') + '</div></div>';
    }
    return '<div class="msg assistant" data-id="' + esc(m.id) + '"><div class="av"></div><div class="content">' + assistantInner(m, S.streamMsg === m, isLast) + '</div></div>';
  }
  var SUGGESTIONS = ['Erkläre mir Photosynthese einfach', 'Schreibe eine freundliche E-Mail an meinen Lehrer', 'Gib mir 5 Ideen für ein Schulprojekt', 'Was ist der Unterschied zwischen Python und JavaScript?'];
  function helloHTML() {
    var n = S.settings.name || (S.user && S.user.username) || '';
    var e = S.engine;
    var h = '<div class="hello"><div class="orb-big"></div><h1>' + (n ? 'Wie kann ich helfen, ' + esc(n) + '?' : 'Wie kann ich helfen?') + '</h1>';
    if (S.maintenance.on && !isOwner()) return h + '<div class="banner">' + esc(S.maintenance.message || 'Zayriox befindet sich gerade im Wartungsmodus.') + '</div></div>';
    var mini = S.models[0];
    var none = !e.installed.length;
    if (e.downloading) {
      var pct = Math.round((e.progress || 0) * 100);
      h += '<p>Zayriox lädt sein KI-Modell herunter. Das passiert nur einmal.</p><div class="onboard"><h3>Modell wird heruntergeladen…</h3><div class="progress"><i style="width:' + pct +
        '%"></i></div><div class="small">' + pct + ' % · ' + (e.downloadedMB || 0) + ' von ' + (e.totalMB || '?') + ' MB</div></div>';
    } else if (e.state === 'loading') {
      h += '<p>Das KI-Modell wird geladen…</p><div class="onboard"><div class="progress indet"><i></i></div></div>';
    } else if (e.state === 'error') {
      h += '<div class="onboard"><h3>Das KI-Modell konnte nicht gestartet werden</h3><p>' + esc(e.message || '') + '</p>' +
        (isOwner() ? '<button class="btn" data-act="retry-load">Erneut versuchen</button> <button class="btn ghost" data-act="open-owner">Owner-Bereich</button>' : '<p class="small">Bitte wende dich an den Owner.</p>') + '</div>';
    } else if (none) {
      h += '<p>Zayriox läuft komplett auf deinem Gerät.</p><div class="onboard"><h3>Willkommen bei Zayriox</h3>' +
        (isOwner()
          ? '<p>Lade das kleine Sprachmodell „' + esc(mini ? mini.name : 'Zayriox Mini') + '“ herunter (ca. ' + (mini ? mini.sizeMB : 400) + ' MB, einmalig). Danach funktioniert Zayriox auch offline.</p>' +
            (e.message ? '<p style="color:var(--danger)">' + esc(e.message) + '</p>' : '') +
            '<button class="btn" data-act="download" data-id="' + (mini ? mini.id : 'mini') + '">Modell herunterladen</button> <button class="btn ghost" data-act="open-owner">Anderes Modell wählen</button>'
          : '<p>Der Owner muss zuerst das KI-Modell installieren. Sobald es bereit ist, kannst du loslegen.</p>') + '</div>';
    } else {
      h += '<p>Stelle eine Frage, lade eine Datei oder ein Bild hoch, oder wähle oben eine Denkstufe.</p><div class="suggest">' +
        SUGGESTIONS.map(function (s) { return '<button data-suggest="' + esc(s) + '">' + esc(s) + '</button>'; }).join('') + '</div>';
    }
    return h + '</div>';
  }
  function nearBottom() { var s = $('#scroll'); return s.scrollHeight - s.scrollTop - s.clientHeight < 150; }
  function scrollBottom() { var s = $('#scroll'); s.scrollTop = s.scrollHeight; }
  function renderThread(forceBottom) {
    var chat = activeChat(), stick = forceBottom || nearBottom();
    if (!chat || !chat.messages.length) $('#thread').innerHTML = helloHTML();
    else {
      var n = chat.messages.length;
      $('#thread').innerHTML = chat.messages.map(function (m, i) { return messageHTML(m, i === n - 1 && m.role === 'assistant'); }).join('');
    }
    if (stick) scrollBottom();
  }
  ZX.hooks.renderThread = renderThread;
  var rafPending = false;
  function updateStream() {
    if (rafPending) return;
    rafPending = true;
    requestAnimationFrame(function () {
      rafPending = false;
      var m = S.streamMsg; if (!m) return;
      var el = $('.msg[data-id="' + m.id + '"] .content'); if (!el) return;
      var stick = nearBottom();
      el.innerHTML = assistantInner(m, true, true);
      if (stick) scrollBottom();
    });
  }

  // ---------- Status & Eingabe ----------
  function renderStatus() {
    var e = S.engine, text, cls = '';
    if (S.busy) { text = 'Zayriox antwortet…'; cls = 'busy'; }
    else if (S.mlMsg) { text = S.mlMsg; cls = 'busy'; }
    else if (e.downloading) { text = 'Lädt Modell… ' + Math.round((e.progress || 0) * 100) + ' %'; cls = 'busy'; }
    else if (e.state === 'ready') { text = 'Bereit · ' + modelName(e.modelId); cls = 'ready'; }
    else if (e.state === 'loading') { text = 'KI wird geladen…'; cls = 'busy'; }
    else if (e.state === 'error') { text = 'Modell-Fehler'; cls = 'error'; }
    else text = 'Kein Modell';
    var p = $('#statusPill'); p.textContent = text; p.className = 'status-pill nodrag ' + cls;
  }
  function renderComposer() {
    var b = $('#btnSend');
    if (S.busy) { b.innerHTML = icon('stop', 18); b.disabled = false; b.title = 'Stopp'; b.setAttribute('aria-label', 'Antwort stoppen'); }
    else { b.innerHTML = icon('up', 18); b.disabled = !$('#input').value.trim() && !S.attachments.length; b.title = 'Senden'; b.setAttribute('aria-label', 'Senden'); }
    $('#modeLabel').textContent = 'Zayriox ' + modeLabel(S.settings.mode);
    var f = S.features, web = $('#btnWeb');
    web.disabled = !f.webSearch;
    web.setAttribute('aria-pressed', f.webSearch && S.settings.webSearch ? 'true' : 'false');
    web.title = f.webSearch ? 'Websuche ' + (S.settings.webSearch ? 'ein' : 'aus') : 'Websuche vom Owner deaktiviert';
    $('#btnMic').disabled = !f.voice;
    $('#btnMic').title = f.voice ? (S.recording ? 'Aufnahme beenden' : 'Spracheingabe') : 'Voice vom Owner deaktiviert';
    $('#btnAttach').disabled = !f.uploads && !f.imageAnalysis;
    renderStatus();
  }
  function renderChips() {
    $('#chips').innerHTML = S.attachments.map(function (a, i) {
      return '<span class="chip">' + (a.thumb ? '<img alt="" src="' + a.thumb + '">' : icon('file', 15)) + '<span title="' + esc(a.name) + '">' + esc(a.name) + (a.cut ? ' (gekürzt)' : '') +
        '</span><button data-rm="' + i + '" aria-label="Entfernen">' + icon('x', 13) + '</button></span>';
    }).join('');
  }
  function autosize() { var t = $('#input'); t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 200) + 'px'; }
  function renderModeMenu() {
    $('#modeMenu').innerHTML = S.modes.map(function (m) {
      return '<button role="option" data-mode="' + m.id + '" class="' + (m.id === S.settings.mode ? 'on' : '') + '"><span class="mi"><b>' + esc(m.label) + '</b><span>' + esc(m.desc) +
        '</span></span><span class="ck">' + icon('check', 16) + '</span></button>';
    }).join('');
  }
  function renderAll() { renderSidebar(); renderThread(true); renderComposer(); renderModeMenu(); }
  ZX.hooks.renderAll = renderAll;
  ZX.hooks.renderSidebar = renderSidebar;
  ZX.hooks.renderComposer = renderComposer;

  // ---------- Chats ----------
  function newChat() {
    if (S.activeId === null && !S.busy) { $('#input').focus(); return; }
    S.activeId = null; renderSidebar(); renderThread(true); $('#input').focus();
  }
  function selectChat(id) { S.activeId = id; renderSidebar(); renderThread(true); }
  function startRename(item) {
    var chat = S.chats.find(function (c) { return c.id === item.dataset.id; }); if (!chat) return;
    var t = item.querySelector('.t'), input = document.createElement('input');
    input.className = 't-edit'; input.value = chat.title; input.maxLength = 80;
    t.replaceWith(input); input.focus(); input.select();
    var done = false;
    function commit(save) { if (done) return; done = true; if (save && input.value.trim()) { chat.title = input.value.trim(); persistNow(); } renderSidebar(); }
    input.addEventListener('keydown', function (e) { if (e.key === 'Enter') commit(true); if (e.key === 'Escape') commit(false); });
    input.addEventListener('blur', function () { commit(true); });
    input.addEventListener('click', function (e) { e.stopPropagation(); });
  }
  async function deleteChat(id) {
    var chat = S.chats.find(function (c) { return c.id === id; }); if (!chat) return;
    if (!(await ZX.confirmDialog('Chat löschen?', '„' + chat.title + '“ wird dauerhaft von diesem Gerät gelöscht.', 'Löschen'))) return;
    if (S.streamChat === chat) api.stop(S.requestId);
    S.chats = S.chats.filter(function (c) { return c.id !== id; });
    if (S.activeId === id) S.activeId = null;
    persistNow(); renderSidebar(); renderThread(true);
  }
  ZX.hooks.wipeChats = function () { if (S.busy) stop(); S.chats = []; S.activeId = null; persistNow(); renderSidebar(); renderThread(true); };

  // ---------- Senden / Streaming ----------
  async function submit() {
    if (S.busy) { toast('Zayriox beantwortet gerade noch eine andere Anfrage.', true); return; }
    var input = $('#input'), text = input.value.trim();
    if (!text && !S.attachments.length) return;
    if (S.engine.state !== 'ready') { toast(notReadyText(), true); return; }
    var chat = activeChat();
    if (!chat) { chat = { id: uid(), title: 'Neuer Chat', createdAt: Date.now(), updatedAt: Date.now(), messages: [] }; S.chats.push(chat); S.activeId = chat.id; }
    var um = { id: uid(), role: 'user', content: text, ts: Date.now() };
    var texts = S.attachments.filter(function (a) { return a.kind === 'text'; });
    var imgs = S.attachments.filter(function (a) { return a.kind === 'image'; });
    if (S.attachments.length) um.files = S.attachments.map(function (a) { return a.name; });
    if (texts.length) um.attach = texts.map(function (a) { return { name: a.name, text: a.text }; });
    chat.messages.push(um);
    if (chat.messages.length === 1) chat.title = titleFrom(text || um.files[0]);
    chat.updatedAt = Date.now();
    input.value = ''; autosize();
    imgs.forEach(function (i) { if (i.thumb) URL.revokeObjectURL(i.thumb); });
    S.attachments = []; renderChips();
    await runAssistant(chat, imgs.map(function (i) { return { name: i.name, data: i.data }; }));
  }
  async function runAssistant(chat, images) {
    var am = { id: uid(), role: 'assistant', content: '', thinking: '', ts: Date.now() };
    chat.messages.push(am);
    S.busy = true; S.requestId = uid(); S.streamMsg = am; S.streamChat = chat;
    renderSidebar(); renderThread(true); renderComposer();
    var msgs = chat.messages.slice(0, -1);
    var payload = {
      requestId: S.requestId, mode: S.settings.mode, webSearch: !!(S.settings.webSearch && S.features.webSearch), images: images || [],
      messages: msgs.map(function (m, i) { return { role: m.role, content: m.content, attach: i === msgs.length - 1 ? m.attach : undefined }; })
    };
    var r;
    try { r = await api.send(payload); } catch (e) { r = { ok: false, error: 'Zayriox konnte den Hauptprozess nicht erreichen. Starte die App neu.' }; }
    if (!r.ok) { if (ZX.authLost(r)) return; finishStream({ error: r.error }); }
  }
  function finishStream(opts) {
    opts = opts || {};
    var m = S.streamMsg, chat = S.streamChat; if (!m) return;
    if (opts.error) m.error = opts.error;
    if (opts.stopped) m.stopped = true;
    if (chat && opts.stopped && !m.content && !m.thinking && !m.error) chat.messages = chat.messages.filter(function (x) { return x !== m; });
    delete m._open; delete m.status;
    S.busy = false; S.streamMsg = null; S.streamChat = null; S.requestId = null; S.mlMsg = '';
    if (chat) chat.updatedAt = Date.now();
    persistNow(); renderSidebar(); renderThread(); renderComposer();
    if (!opts.error && !opts.stopped && S.settings.autoRead && m.content) speak(m.content);
  }
  function onChatEvent(ev) {
    if (ev.requestId !== S.requestId || !S.streamMsg) return;
    var m = S.streamMsg;
    switch (ev.type) {
      case 'mode': m.modeUsed = ev.mode; m.auto = !!ev.auto; delete m.status; break;
      case 'status': m.status = ev.text; break;
      case 'notice': m.notice = ev.text; break;
      case 'sources': m.sources = ev.sources; break;
      case 'image-desc': {
        var chat = S.streamChat, um = chat && chat.messages[chat.messages.length - 2];
        if (um && um.role === 'user') { um.attach = (um.attach || []).concat([{ name: ev.name, text: ev.text }]); }
        break;
      }
      case 'think-start': m._open = true; delete m.status; break;
      case 'think': m.thinking += ev.text; break;
      case 'token': if (!m.content) m._open = false; delete m.status; m.content += ev.text; break;
      case 'error': finishStream({ error: ev.message }); return;
      case 'done': finishStream({ stopped: ev.stopped }); return;
      default: break;
    }
    updateStream();
  }
  function stop() { if (S.requestId) api.stop(S.requestId); }
  function regenerate() {
    var chat = activeChat(); if (!chat || S.busy) return;
    if (S.engine.state !== 'ready') { toast(notReadyText(), true); return; }
    var last = chat.messages[chat.messages.length - 1];
    if (last && last.role === 'assistant') chat.messages.pop();
    if (chat.messages.length) runAssistant(chat, []);
  }

  // ---------- Dateien & Bilder ----------
  var MAX_BYTES = 5 * 1024 * 1024;
  var IMG_TYPES = { 'image/png': 1, 'image/jpeg': 1, 'image/webp': 1, 'image/gif': 1 };
  async function addFiles(files) {
    for (var i = 0; i < files.length; i++) {
      var f = files[i];
      if (S.attachments.length >= 5) { toast('Maximal 5 Anhänge pro Nachricht.', true); break; }
      if (f.size > MAX_BYTES) { toast('„' + f.name + '“ ist zu groß (maximal 5 MB).', true); continue; }
      var isImg = IMG_TYPES[f.type] || /\.(png|jpe?g|webp|gif)$/i.test(f.name);
      if (isImg) {
        if (!S.features.imageAnalysis) { toast('Bildanalyse wurde vom Owner deaktiviert.', true); continue; }
        if (S.attachments.filter(function (a) { return a.kind === 'image'; }).length >= 3) { toast('Maximal 3 Bilder pro Nachricht.', true); continue; }
        S.attachments.push({ kind: 'image', name: f.name, data: await f.arrayBuffer(), thumb: URL.createObjectURL(f) });
        continue;
      }
      if (!S.features.uploads) { toast('Datei-Upload wurde vom Owner deaktiviert.', true); continue; }
      var r;
      try { r = await api.extractFile({ name: f.name, data: await f.arrayBuffer() }); } catch (e) { r = { ok: false, error: 'Die Datei konnte nicht gelesen werden.' }; }
      if (ZX.authLost(r)) return;
      if (r.ok) S.attachments.push({ kind: 'text', name: f.name, text: r.text, cut: r.chars > 7000 });
      else toast('„' + f.name + '“: ' + r.error, true);
    }
    renderChips(); renderComposer();
  }

  // ---------- Voice: Aufnahme -> lokale Spracherkennung; Vorlesen über Windows-Stimmen ----------
  function resample(f32, from, to) {
    if (from === to) return f32;
    var ratio = from / to, n = Math.floor(f32.length / ratio), out = new Float32Array(n);
    for (var i = 0; i < n; i++) { var p = i * ratio, i0 = Math.floor(p), i1 = Math.min(i0 + 1, f32.length - 1); out[i] = f32[i0] + (f32[i1] - f32[i0]) * (p - i0); }
    return out;
  }
  async function toggleMic() {
    if (S.recording) return stopRecording(false);
    if (!S.features.voice) { toast('Voice wurde vom Owner deaktiviert.', true); return; }
    var stream;
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); }
    catch (e) { toast('Kein Zugriff auf das Mikrofon. Prüfe Windows → Einstellungen → Datenschutz → Mikrofon.', true); return; }
    var ctx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 16000 });
    var src = ctx.createMediaStreamSource(stream), proc = ctx.createScriptProcessor(4096, 1, 1), chunks = [], total = 0;
    proc.onaudioprocess = function (e) {
      var d = new Float32Array(e.inputBuffer.getChannelData(0)); chunks.push(d); total += d.length;
      if (total >= ctx.sampleRate * 60) stopRecording(false);
    };
    src.connect(proc); proc.connect(ctx.destination);
    S.recording = { stream: stream, ctx: ctx, src: src, proc: proc, chunks: chunks };
    $('#btnMic').classList.add('rec'); renderComposer();
  }
  async function stopRecording(discard) {
    var r = S.recording; if (!r) return;
    S.recording = null;
    try { r.proc.disconnect(); r.src.disconnect(); r.stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) { /* egal */ }
    var rate = r.ctx.sampleRate; try { r.ctx.close(); } catch (e) { /* egal */ }
    var mic = $('#btnMic'); mic.classList.remove('rec');
    if (discard) { renderComposer(); return; }
    var len = r.chunks.reduce(function (n, c) { return n + c.length; }, 0), all = new Float32Array(len), o = 0;
    r.chunks.forEach(function (c) { all.set(c, o); o += c.length; });
    var pcm = resample(all, rate, 16000);
    if (pcm.length < 16000 * 0.4) { toast('Aufnahme zu kurz.', true); renderComposer(); return; }
    mic.classList.add('work'); S.mlMsg = 'Sprache wird erkannt…'; renderStatus();
    var res;
    try { res = await api.transcribe(pcm); } catch (e) { res = { ok: false, error: 'Die Spracherkennung ist fehlgeschlagen.' }; }
    mic.classList.remove('work'); S.mlMsg = ''; renderComposer();
    if (ZX.authLost(res)) return;
    if (!res.ok) { toast(res.error, true); return; }
    if (!res.text) { toast('Es wurde keine Sprache erkannt.', true); return; }
    var input = $('#input'); input.value = (input.value ? input.value + ' ' : '') + res.text; autosize(); renderComposer(); input.focus();
  }
  ZX.hooks.stopRecording = stopRecording;
  function speak(text) {
    if (!('speechSynthesis' in window)) { toast('Vorlesen wird auf diesem Gerät nicht unterstützt.', true); return; }
    if (window.speechSynthesis.speaking) { window.speechSynthesis.cancel(); return; }
    var clean = String(text).replace(/```[\s\S]*?```/g, ' Codeblock. ').replace(/`/g, '').replace(/[*_#>]/g, '').replace(/\[\d+\]/g, '');
    var u = new window.SpeechSynthesisUtterance(clean); u.lang = 'de-DE'; window.speechSynthesis.speak(u);
  }

  // ---------- Anmeldung -> App ----------
  ZX.hooks.enterApp = async function () {
    var d = await api.load();
    if (!d.ok) { ZX.hooks.showAuth('login', { message: d.error || 'Bitte melde dich an.' }); return; }
    Object.assign(S, { user: d.user, chats: d.chats, settings: d.settings, modes: d.modes, models: d.models, engine: d.engine, features: d.features, maintenance: d.maintenance, usage: d.usage, version: d.version });
    S.activeId = null; S.attachments = []; S.busy = false; S.search = '';
    $('#search').value = '';
    applyTheme();
    $('#auth').hidden = true; $('#auth').innerHTML = '';
    $('#app').hidden = false;
    if (window.innerWidth < 900) $('#app').classList.add('collapsed');
    renderAll();
    $('#input').focus();
  };
  async function logout() {
    if (S.busy) stop();
    persistNow();
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    await api.authLogout();
    var st = await api.authStatus();
    ZX.hooks.showAuth('login', { registration: st.registration });
  }
  ZX.hooks.logout = logout;

  // ---------- Events ----------
  var lastPing = 0;
  function activity() {
    if (!S.user || Date.now() - lastPing < 60000) return;
    lastPing = Date.now();
    api.authPing().then(function (r) { ZX.authLost(r); });
  }

  function bind() {
    $('#btnNew').addEventListener('click', newChat);
    $('#btnSettings').addEventListener('click', function () { ZX.hooks.openSettings(); });
    $('#btnOwner').addEventListener('click', function () { ZX.hooks.openOwner(); });
    $('#btnLogout').addEventListener('click', logout);
    $('#btnCollapse').addEventListener('click', function () { $('#app').classList.add('collapsed'); });
    $('#btnOpenSide').addEventListener('click', function () { $('#app').classList.remove('collapsed'); });
    $('#search').addEventListener('input', function (e) { S.search = e.target.value; renderSidebar(); });
    $('#btnAttach').addEventListener('click', function () { $('#file').click(); });
    $('#file').addEventListener('change', function (e) { addFiles(Array.from(e.target.files)); e.target.value = ''; });
    $('#btnSend').addEventListener('click', function () { if (S.busy) stop(); else submit(); });
    $('#btnMic').addEventListener('click', toggleMic);
    $('#btnWeb').addEventListener('click', function () { ZX.saveSettings({ webSearch: !S.settings.webSearch }); renderComposer(); });
    var input = $('#input');
    input.addEventListener('input', function () { autosize(); renderComposer(); });
    input.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); submit(); } });
    input.addEventListener('paste', function (e) {
      var files = Array.from((e.clipboardData && e.clipboardData.files) || []);
      if (files.length) { e.preventDefault(); addFiles(files); }
    });
    $('#chips').addEventListener('click', function (e) {
      var b = e.target.closest('[data-rm]');
      if (b) { var a = S.attachments.splice(Number(b.dataset.rm), 1)[0]; if (a && a.thumb) URL.revokeObjectURL(a.thumb); renderChips(); renderComposer(); }
    });
    $('#chatList').addEventListener('click', function (e) {
      var item = e.target.closest('.chat-item'); if (!item) return;
      var act = e.target.closest('[data-act]');
      if (act && act.dataset.act === 'rename') return startRename(item);
      if (act && act.dataset.act === 'delete') return deleteChat(item.dataset.id);
      if (e.target.closest('.t-edit')) return;
      selectChat(item.dataset.id);
      if (window.innerWidth < 900) $('#app').classList.add('collapsed');
    });
    $('#modeBtn').addEventListener('click', function (e) { e.stopPropagation(); var m = $('#modeMenu'); m.hidden = !m.hidden; });
    $('#modeMenu').addEventListener('click', function (e) {
      var b = e.target.closest('[data-mode]'); if (!b) return;
      ZX.saveSettings({ mode: b.dataset.mode }); renderModeMenu(); renderComposer(); $('#modeMenu').hidden = true;
    });
    document.addEventListener('click', function (e) { if (!e.target.closest('.mode-wrap')) $('#modeMenu').hidden = true; });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        $('#modeMenu').hidden = true;
        if (!$('#modal2').hidden) ZX.closeModal('#modal2'); else if (!$('#modal').hidden) ZX.closeModal();
      }
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'o' && S.user) { e.preventDefault(); newChat(); }
    });
    ['keydown', 'click', 'mousemove'].forEach(function (t) { document.addEventListener(t, activity, { passive: true }); });

    $('#thread').addEventListener('click', function (e) {
      var t = e.target, cc = t.closest('.copy-code');
      if (cc) {
        copyText(cc.closest('.code').querySelector('code').innerText).then(function () { cc.textContent = 'Kopiert ✓'; setTimeout(function () { cc.textContent = 'Kopieren'; }, 1400); }, function () { toast('Kopieren nicht möglich.', true); });
        return;
      }
      var a = t.closest('a[data-href]');
      if (a) { e.preventDefault(); api.openExternal(a.getAttribute('data-href')); return; }
      var sg = t.closest('[data-suggest]');
      if (sg) { input.value = sg.dataset.suggest; autosize(); renderComposer(); input.focus(); return; }
      var act = t.closest('[data-act]'); if (!act) return;
      var kind = act.dataset.act;
      if (kind === 'copy' || kind === 'speak') {
        var msg = act.closest('.msg'), chat = activeChat(), m = chat && chat.messages.find(function (x) { return x.id === msg.dataset.id; });
        if (!m) return;
        if (kind === 'speak') speak(m.content);
        else copyText(m.content).then(function () { toast('Kopiert.'); }, function () { toast('Kopieren nicht möglich.', true); });
      } else if (kind === 'regen') regenerate();
      else if (kind === 'download') ZX.hooks.downloadModel(act.dataset.id);
      else if (kind === 'open-owner') ZX.hooks.openOwner('model');
      else if (kind === 'retry-load') ZX.hooks.useModel(S.engine.modelId || (S.models[0] && S.models[0].id));
    });
    $('#thread').addEventListener('toggle', function (e) {
      var d = e.target; if (!d.classList || !d.classList.contains('think')) return;
      var msg = d.closest('.msg'), chat = activeChat(), m = chat && chat.messages.find(function (x) { return x.id === msg.dataset.id; });
      if (m) m._open = d.open;
    }, true);

    var depth = 0;
    window.addEventListener('dragenter', function (e) { if (S.user && e.dataTransfer && Array.from(e.dataTransfer.types).indexOf('Files') !== -1) { depth++; $('#drop').hidden = false; } });
    window.addEventListener('dragleave', function () { depth = Math.max(0, depth - 1); if (!depth) $('#drop').hidden = true; });
    window.addEventListener('dragover', function (e) { e.preventDefault(); });
    window.addEventListener('drop', function (e) {
      e.preventDefault(); depth = 0; $('#drop').hidden = true;
      if (S.user && e.dataTransfer && e.dataTransfer.files.length) addFiles(Array.from(e.dataTransfer.files));
    });

    api.onChatEvent(onChatEvent);
    api.onEngine(function (st) {
      S.engine = st; renderStatus();
      var c = activeChat(); if (S.user && (!c || !c.messages.length)) renderThread();
      if (ZX.hooks.engineChanged) ZX.hooks.engineChanged();
    });
    api.onMl(function (st) { S.mlMsg = st && st.message ? st.message : ''; renderStatus(); });
    api.onSessionEnded(function (info) {
      var reason = info && info.reason;
      var text = reason === 'idle' ? 'Du wurdest wegen Inaktivität abgemeldet.' : reason === 'blocked' ? 'Dein Konto wurde gesperrt.' : reason === 'password-changed' ? 'Dein Passwort wurde geändert. Bitte melde dich neu an.' : reason === 'logout' ? '' : 'Deine Sitzung wurde beendet. Bitte melde dich erneut an.';
      if (S.user) ZX.hooks.showAuth('login', { message: text });
    });
  }

  ZX.hooks.downloadModel = async function (id) {
    var r = await ZX.owner(function () { return api.adminModelDownload(id); });
    if (r.code === 'CANCEL') return;
    if (!r.ok) toast(r.error, true); else toast(modelName(id) + ' ist bereit.');
  };
  ZX.hooks.useModel = async function (id) {
    var r = await ZX.owner(function () { return api.adminModelUse(id); });
    if (r.code === 'CANCEL') return;
    if (!r.ok) toast(r.error, true); else toast(modelName(id) + ' ist jetzt aktiv.');
  };

  ZX.hooks.init = function () {
    ZX.hydrateIcons();
    bind();
    ZX.hooks.boot();
  };
})();
