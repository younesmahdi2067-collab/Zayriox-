(function () {
  'use strict';
  var ZX = window.ZX, $ = ZX.$, esc = ZX.esc, api = ZX.api;

  function field(name, label, type, ac, extra) {
    return '<label>' + esc(label) + '<input class="field" name="' + name + '" type="' + (type || 'text') + '" autocomplete="' + (ac || 'off') + '" ' + (extra || '') + ' required></label>';
  }
  function groups(secret) { return String(secret).replace(/(.{4})/g, '$1 ').trim(); }

  var VIEWS = {
    tampered: function (o) {
      return '<h2>Konten gesperrt</h2><p class="lead">' + esc(o.error || 'Die Kontodaten wurden verändert oder sind beschädigt.') + '</p>' +
        '<div class="hintbox">Aus Sicherheitsgründen sind Anmeldungen gesperrt. Wenn du die Änderung nicht selbst gemacht hast, ist dein Gerät möglicherweise kompromittiert.</div>';
    },
    setup: function () {
      return '<h2>Willkommen bei Zayriox</h2><p class="lead">Lege dein <b>Owner-Konto</b> an. Der Owner verwaltet Zayriox (Benutzer, Funktionen, Modelle). Zwei-Faktor-Schutz ist für den Owner Pflicht.</p>' +
        '<form id="authForm">' + field('username', 'Benutzername', 'text', 'username', 'maxlength="24"') + field('email', 'E-Mail', 'email', 'email', 'maxlength="120"') +
        field('password', 'Passwort', 'password', 'new-password', 'maxlength="128"') +
        '<div class="hintbox">Mindestens 10 Zeichen, mit Buchstaben und Zahlen. Wähle ein Passwort, das du nirgendwo sonst nutzt.</div>' +
        '<div class="auth-msg" role="alert"></div><button class="btn" type="submit">Weiter zur 2FA-Einrichtung</button></form>';
    },
    login: function (o) {
      return '<h2>Anmelden</h2><p class="lead">Melde dich bei Zayriox an.</p><form id="authForm">' + field('username', 'Benutzername', 'text', 'username') +
        field('password', 'Passwort', 'password', 'current-password') + '<div class="auth-msg" role="alert">' + esc(o.message || '') + '</div><button class="btn" type="submit">Anmelden</button></form>' +
        (o.registration !== false ? '<div class="auth-links"><button class="linkbtn" data-go="register">Neues Konto erstellen</button></div>' : '');
    },
    register: function () {
      return '<h2>Konto erstellen</h2><p class="lead">Dein Konto und deine Chats liegen nur auf diesem Gerät.</p><form id="authForm">' +
        field('username', 'Benutzername', 'text', 'username', 'maxlength="24"') + field('email', 'E-Mail', 'email', 'email', 'maxlength="120"') +
        field('password', 'Passwort (mind. 10 Zeichen, Buchstaben + Zahlen)', 'password', 'new-password', 'maxlength="128"') +
        '<div class="auth-msg" role="alert"></div><button class="btn" type="submit">Konto erstellen</button></form>' +
        '<div class="auth-links"><button class="linkbtn" data-go="login">Ich habe schon ein Konto</button></div>';
    },
    '2fa': function () {
      return '<h2>Zwei-Faktor-Code</h2><p class="lead">Gib den 6-stelligen Code aus deiner Authenticator-App ein – oder einen Wiederherstellungscode.</p><form id="authForm">' +
        field('code', 'Code', 'text', 'one-time-code', 'inputmode="numeric" maxlength="16"') +
        '<div class="auth-msg" role="alert"></div><button class="btn" type="submit">Bestätigen</button></form>' +
        '<div class="auth-links"><button class="linkbtn" data-go="login">Zurück</button></div>';
    },
    enroll: function (o) {
      return '<h2>Zwei-Faktor-Schutz einrichten</h2><p class="lead">1. Scanne den QR-Code mit deiner Authenticator-App. Wenn das nicht geht, kannst du den Schlüssel darunter manuell eingeben.</p>' +
        (o.qr ? '<div style="display:flex;justify-content:center;margin:10px 0 14px"><img src="' + esc(o.qr) + '" alt="QR-Code für Zayriox 2FA" width=220 height=220 style="background:#fff;padding:10px;border-radius:12px"></div>' : '') +
        '<div class="secret" id="secretBox">' + esc(groups(o.secret)) + '</div><p class="small" style="margin:8px 0 14px">Konto: ' + esc(o.account || 'Zayriox') + ' · Bewahre den Schlüssel nicht im Klartext auf.</p>' +
        '<form id="authForm">' + field('code', 'Aktueller 6-stelliger Code aus der App', 'text', 'one-time-code', 'inputmode="numeric" maxlength="8"') +
        '<div class="auth-msg" role="alert"></div><button class="btn" type="submit">Bestätigen und weiter</button></form>';
    },
    recovery: function (o) {
      return '<h2>Wiederherstellungscodes</h2><p class="lead">Falls du dein Handy verlierst, kommst du mit einem dieser Codes hinein. <b>Jeder Code funktioniert nur einmal.</b> Speichere sie jetzt an einem sicheren Ort – sie werden nie wieder angezeigt.</p>' +
        '<div class="codes">' + o.codes.map(function (c) { return '<code>' + esc(c) + '</code>'; }).join('') + '</div>' +
        '<div class="row-gap"><button class="btn ghost sm" id="copyCodes" type="button">Codes kopieren</button></div>' +
        '<label class="check" style="margin:14px 0"><input type="checkbox" id="savedCodes"> Ich habe die Codes sicher gespeichert.</label>' +
        '<button class="btn" id="goApp" disabled>Zayriox öffnen</button>';
    }
  };

  function showAuth(view, opts) {
    opts = opts || {};
    var S = ZX.S;
    S.user = null; S.busy = false;
    if (S.recording) { try { ZX.hooks.stopRecording(true); } catch (e) { /* egal */ } }
    $('#app').hidden = true;
    ZX.closeModal('#modal'); ZX.closeModal('#modal2');
    document.documentElement.dataset.theme = 'dark';
    var a = $('#auth');
    a.hidden = false;
    a.innerHTML = '<div class="auth-drag drag"></div><div class="auth-card"><div class="auth-brand"><div class="orb-big"></div><h1>Zayriox</h1></div>' + VIEWS[view](opts) + '</div>';
    bind(view, opts, a);
    if (view === 'enroll' && opts.uri && !opts.qr) { api.authQr(opts.uri).then(function (q) { if (q && q.ok && a.isConnected && !a.hidden) { opts.qr = q.dataUrl; showAuth('enroll', opts); } }).catch(function () {}); }
    var f = a.querySelector('input'); if (f) f.focus();
  }

  function msg(el, text, ok) { var m = el.querySelector('.auth-msg'); if (m) { m.textContent = text || ''; m.className = 'auth-msg' + (ok ? ' ok' : ''); } }

  var HANDLERS = {
    setup: async function (f) {
      var r = await api.authSetup({ username: f.username, email: f.email, password: f.password });
      if (!r.ok) return r.error;
      showAuth('enroll', { secret: r.secret, uri: r.uri, account: f.username });
    },
    login: async function (f) {
      var r = await api.authLogin({ username: f.username, password: f.password });
      if (!r.ok) return r.error;
      if (r.step === '2fa') return showAuth('2fa');
      if (r.step === 'enroll') return showAuth('enroll', { secret: r.secret, uri: r.uri, account: f.username });
      await ZX.hooks.enterApp();
    },
    register: async function (f) {
      var r = await api.authRegister({ username: f.username, email: f.email, password: f.password });
      if (!r.ok) return r.error;
      await ZX.hooks.enterApp();
    },
    '2fa': async function (f) {
      var r = await api.authVerify2fa({ code: f.code });
      if (!r.ok) { if (r.code === 'EXPIRED' || r.code === 'LOCKED') showAuth('login', { message: r.error }); return r.error; }
      await ZX.hooks.enterApp();
    },
    enroll: async function (f) {
      var r = await api.authEnroll({ code: f.code });
      if (!r.ok) { if (r.code === 'EXPIRED') showAuth('login', { message: r.error }); return r.error; }
      showAuth('recovery', { codes: r.recoveryCodes });
    }
  };

  function bind(view, opts, root) {
    root.querySelectorAll('[data-go]').forEach(function (b) { b.addEventListener('click', function () { showAuth(b.dataset.go, { registration: opts.registration }); }); });
    var form = root.querySelector('#authForm');
    if (form && HANDLERS[view]) {
      form.addEventListener('submit', async function (e) {
        e.preventDefault();
        var v = {};
        form.querySelectorAll('input').forEach(function (i) { v[i.name] = i.value; });
        var btn = form.querySelector('button[type=submit]');
        btn.disabled = true; msg(root, '');
        var err;
        try { err = await HANDLERS[view](v); } catch (x) { err = 'Zayriox konnte den Hauptprozess nicht erreichen. Starte die App neu.'; }
        if (err && root.contains(form)) { msg(root, err); btn.disabled = false; }
      });
    }
    if (view === 'recovery') {
      var chk = root.querySelector('#savedCodes'), go = root.querySelector('#goApp');
      chk.addEventListener('change', function () { go.disabled = !chk.checked; });
      go.addEventListener('click', function () { ZX.hooks.enterApp(); });
      root.querySelector('#copyCodes').addEventListener('click', function () {
        Promise.resolve().then(function () { return navigator.clipboard.writeText(opts.codes.join('\n')); }).then(function () { ZX.toast('Codes kopiert.'); }, function () { ZX.toast('Kopieren nicht möglich – bitte abschreiben.', true); });
      });
    }
  }

  ZX.hooks.showAuth = showAuth;

  /** Startpunkt: fragt den Hauptprozess, in welcher Phase sich die App befindet. */
  ZX.hooks.boot = async function () {
    var st;
    try { st = await api.authStatus(); } catch (e) { st = { phase: 'tampered', error: 'Zayriox konnte den Hauptprozess nicht erreichen. Starte die App neu.' }; }
    ZX.S.maintenance = st.maintenance || ZX.S.maintenance;
    if (st.phase === 'app') return ZX.hooks.enterApp();
    showAuth(st.phase, { registration: st.registration, error: st.error });
  };
})();
