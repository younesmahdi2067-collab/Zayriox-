(function () {
  'use strict';
  var ZX = window.ZX, S = ZX.S, $ = ZX.$, esc = ZX.esc, api = ZX.api, icon = ZX.icon, toast = ZX.toast;

  function isOwner() { return !!S.user && S.user.role === 'owner'; }
  function modelName(id) { var m = S.models.find(function (x) { return x.id === id; }); return m ? m.name : 'Kein Modell'; }
  function fmtDate(iso) { try { return new Date(iso).toLocaleString('de-DE', { dateStyle: 'short', timeStyle: 'short' }); } catch (e) { return iso || '–'; } }
  function pw(name, label) { return { name: name, label: label, type: 'password', autocomplete: name === 'password' || name === 'current' ? 'current-password' : 'new-password' }; }

  function recoveryDialog(codes) {
    return new Promise(function (resolve) {
      var m = $('#modal2');
      m.innerHTML = '<div class="card small" role="dialog" aria-modal="true"><h2>Wiederherstellungscodes</h2><p class="small">Speichere diese Codes sicher. Jeder funktioniert nur einmal und wird nie wieder angezeigt.</p>' +
        '<div class="codes">' + codes.map(function (c) { return '<code>' + esc(c) + '</code>'; }).join('') + '</div><div class="actions"><button class="btn ghost" id="rcCopy">Kopieren</button><button class="btn" id="rcOk">Ich habe sie gespeichert</button></div></div>';
      m.hidden = false; m.onclick = null;
      $('#rcCopy').addEventListener('click', function () {
        Promise.resolve().then(function () { return navigator.clipboard.writeText(codes.join('\n')); }).then(function () { toast('Codes kopiert.'); }, function () { toast('Kopieren nicht möglich – bitte abschreiben.', true); });
      });
      $('#rcOk').addEventListener('click', function () { ZX.closeModal('#modal2'); resolve(); });
    });
  }

  // =====================================================================
  // Einstellungen & Konto
  // =====================================================================
  function settingsHTML() {
    var s = S.settings, u = S.user, u2 = S.usage;
    var usage = u2 ? (u.role === 'owner' ? 'Unbegrenzt (Owner)' : u2.msgs + ' von ' + (u2.limits.messagesPerDay || '∞') + ' Nachrichten heute · „Hoch/Pro Max“: ' + u2.heavy + ' von ' + (u2.limits.heavyPerDay || '∞')) : '–';
    return '<div class="card" role="dialog" aria-modal="true" aria-label="Einstellungen"><header><h2>Einstellungen &amp; Konto</h2><button class="icon-btn" data-close aria-label="Schließen">' + icon('x') + '</button></header><div class="body">' +
      '<div class="sec"><h3>Anzeigename</h3><input class="field" id="setName" maxlength="40" placeholder="Wie soll Zayriox dich nennen?" value="' + esc(s.name) + '"></div>' +
      '<div class="sec"><h3>Design</h3><div class="seg" id="setTheme"><button data-theme="dark" class="' + (s.theme === 'dark' ? 'on' : '') + '">Dunkel</button><button data-theme="light" class="' + (s.theme === 'light' ? 'on' : '') + '">Hell</button></div></div>' +
      '<div class="sec"><h3>Voice</h3><label class="toggle"><span>Antworten automatisch vorlesen</span><input type="checkbox" id="setAutoRead"' + (s.autoRead ? ' checked' : '') + '></label></div>' +
      '<div class="sec"><h3>Eigene Anweisungen</h3><p class="hint">Gilt für jeden Chat, z. B. „Antworte immer locker und mit Beispielen“.</p><textarea class="field" id="setCustom" maxlength="1500">' + esc(s.custom) + '</textarea></div>' +
      '<div class="sec"><h3>KI-Modell</h3><p class="small">Aktiv: <b>' + esc(modelName(S.engine.modelId)) + '</b>. ' + (isOwner() ? 'Wechseln im Owner-Bereich.' : 'Das Modell wird vom Owner verwaltet.') + '</p></div>' +
      '<div class="sec"><h3>Nutzung</h3><p class="small">' + esc(usage) + '</p></div>' +
      '<div class="sec"><h3>Konto</h3><p class="small">Benutzername: <b>' + esc(u.username) + '</b> · E-Mail: ' + esc(u.email) + ' · Rolle: ' + (u.role === 'owner' ? 'Owner' : 'Benutzer') + '<br>Zwei-Faktor-Schutz: ' +
        (u.totpEnabled ? '<span class="pill ok">aktiv</span>' : '<span class="pill">aus</span>') + '</p><div class="row-gap" style="margin-top:10px">' +
        '<button class="btn ghost sm" data-act="pw">Passwort ändern</button>' +
        (u.totpEnabled ? (u.role === 'owner' ? '' : '<button class="btn ghost sm" data-act="2fa-off">2FA deaktivieren</button>') : '<button class="btn ghost sm" data-act="2fa-on">2FA aktivieren</button>') +
        '<button class="btn ghost sm" data-act="logout">Abmelden</button>' + (u.role === 'owner' ? '' : '<button class="btn danger sm" data-act="delacc">Konto löschen</button>') + '</div></div>' +
      '<div class="sec"><h3>Daten</h3><p class="hint">Chats und Einstellungen liegen nur auf diesem Gerät, getrennt pro Konto.</p><button class="btn danger sm" data-act="wipe">Alle meine Chats löschen</button></div>' +
      '<div class="sec"><h3>Über Zayriox</h3><p class="small">Version ' + esc(S.version) + ' · Modelle: Qwen2.5 (Apache-2.0) · Laufzeit: llama.cpp · Alles läuft lokal auf diesem Gerät.</p></div>' +
      '</div></div>';
  }

  function openSettings() {
    var m = $('#modal');
    S.modalKind = 'settings';
    m.innerHTML = settingsHTML(); m.hidden = false;
    var t;
    function debounced(fn) { clearTimeout(t); t = setTimeout(fn, 350); }
    $('#setName').addEventListener('input', function (e) { debounced(function () { ZX.saveSettings({ name: e.target.value.trim() }); ZX.hooks.renderSidebar(); ZX.hooks.renderThread(); }); });
    $('#setCustom').addEventListener('input', function (e) { debounced(function () { ZX.saveSettings({ custom: e.target.value }); }); });
    $('#setAutoRead').addEventListener('change', function (e) { ZX.saveSettings({ autoRead: e.target.checked }); });
    m.onclick = async function (e) {
      if (e.target === m || e.target.closest('[data-close]')) return ZX.closeModal();
      var th = e.target.closest('button[data-theme]');
      if (th) { ZX.saveSettings({ theme: th.dataset.theme }); $('#setTheme').querySelectorAll('button').forEach(function (b) { b.classList.toggle('on', b === th); }); return; }
      var b = e.target.closest('[data-act]'); if (!b) return;
      var a = b.dataset.act;
      if (a === 'logout') { ZX.closeModal(); return ZX.hooks.logout(); }
      if (a === 'wipe') { if (await ZX.confirmDialog('Alle Chats löschen?', 'Das kann nicht rückgängig gemacht werden.', 'Alles löschen')) { ZX.hooks.wipeChats(); toast('Alle Chats wurden gelöscht.'); } return; }
      if (a === 'pw') return changePassword();
      if (a === '2fa-on') return enable2fa();
      if (a === '2fa-off') return disable2fa();
      if (a === 'delacc') return deleteAccount();
    };
  }
  ZX.hooks.openSettings = openSettings;

  async function reloadUser() {
    var d = await api.load();
    if (d.ok) { S.user = d.user; S.usage = d.usage; }
    if (S.modalKind === 'settings') openSettings();
  }

  function changePassword() {
    return ZX.formDialog('Passwort ändern', 'Mindestens 10 Zeichen, mit Buchstaben und Zahlen. Andere angemeldete Sitzungen werden beendet.',
      [pw('current', 'Aktuelles Passwort'), pw('next', 'Neues Passwort')], 'Ändern', async function (v) {
        var r = await api.changePassword({ current: v.current, next: v.next });
        if (ZX.authLost(r)) return 'Sitzung abgelaufen.';
        if (!r.ok) return r.error;
        toast('Passwort geändert.'); return null;
      });
  }

  async function enable2fa() {
    var secret = null;
    var okPw = await ZX.formDialog('2FA aktivieren', 'Bestätige zuerst dein Passwort.', [pw('password', 'Passwort')], 'Weiter', async function (v) {
      var r = await api.totpBegin({ password: v.password });
      if (ZX.authLost(r)) return 'Sitzung abgelaufen.';
      if (!r.ok) return r.error;
      secret = r.secret; return null;
    });
    if (!okPw || !secret) return;
    var codes = null;
    var spaced = secret.replace(/(.{4})/g, '$1 ').trim();
    var ok = await ZX.formDialog('Authenticator einrichten', 'Öffne deine Authenticator-App → „Schlüssel manuell eingeben“ → Schlüssel: ' + spaced + ' (zeitbasiert). Gib dann den 6-stelligen Code ein.',
      [{ name: 'code', label: 'Code', inputmode: 'numeric', autocomplete: 'one-time-code' }], 'Aktivieren', async function (v) {
        var r = await api.totpConfirm({ code: v.code });
        if (ZX.authLost(r)) return 'Sitzung abgelaufen.';
        if (!r.ok) return r.error;
        codes = r.recoveryCodes; return null;
      });
    if (ok && codes) { await recoveryDialog(codes); await reloadUser(); toast('2FA ist aktiv.'); }
  }

  async function disable2fa() {
    var ok = await ZX.formDialog('2FA deaktivieren', 'Bestätige mit Passwort und aktuellem Code.', [pw('password', 'Passwort'), { name: 'code', label: 'Aktueller 2FA-Code', inputmode: 'numeric' }], 'Deaktivieren', async function (v) {
      var r = await api.totpDisable({ password: v.password, code: v.code });
      if (ZX.authLost(r)) return 'Sitzung abgelaufen.';
      return r.ok ? null : r.error;
    });
    if (ok) { await reloadUser(); toast('2FA wurde deaktiviert.'); }
  }

  async function deleteAccount() {
    var ok = await ZX.formDialog('Konto löschen', 'Dein Konto und alle deine Chats werden unwiderruflich gelöscht. Bestätige mit deinem Passwort.', [pw('password', 'Passwort')], 'Endgültig löschen', async function (v) {
      var r = await api.deleteAccount({ password: v.password });
      if (ZX.authLost(r)) return 'Sitzung abgelaufen.';
      return r.ok ? null : r.error;
    });
    if (ok) { var st = await api.authStatus(); ZX.hooks.showAuth('login', { registration: st.registration, message: 'Dein Konto wurde gelöscht.' }); }
  }

  // =====================================================================
  // Owner-Bereich (alles wird im Hauptprozess erneut auf Owner-Rechte geprüft)
  // =====================================================================
  var OW = { tab: 'users', users: [], policy: null, audit: null };
  var FEATURE_LABELS = { webSearch: 'Websuche', voice: 'Voice (Sprache → Text)', imageAnalysis: 'Bildanalyse', uploads: 'Datei-Upload', registration: 'Neue Registrierungen' };
  var MODE_LABELS = { schnell: 'Schnell', mittel: 'Mittel', hoch: 'Hoch', promax: 'Pro Max' };

  function tabs() {
    var t = [['users', 'Benutzer'], ['features', 'Funktionen & Limits'], ['model', 'KI-Modell'], ['audit', 'Sicherheitsprotokoll']];
    return '<div class="tabs">' + t.map(function (x) { return '<button data-tab="' + x[0] + '" class="' + (OW.tab === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div>';
  }

  function usersHTML() {
    var rows = OW.users.map(function (u) {
      var protectedAcc = u.role === 'owner';
      return '<tr><td><b>' + esc(u.username) + '</b><div class="small">' + esc(u.email) + '</div></td><td>' + (protectedAcc ? '<span class="pill">Owner</span>' : '<span class="pill">Benutzer</span>') +
        '</td><td>' + (u.status === 'blocked' ? '<span class="pill bad">gesperrt</span>' : u.status === 'setup' ? '<span class="pill">Einrichtung</span>' : '<span class="pill ok">aktiv</span>') +
        '</td><td>' + (u.totpEnabled ? '<span class="pill ok">2FA</span>' : '<span class="pill">–</span>') + '</td><td class="small">' + u.usage.msgs + ' heute · ' + u.usage.total + ' gesamt</td><td class="small">' + fmtDate(u.lastLogin) +
        '</td><td class="r">' + (protectedAcc ? '<span class="small">geschützt</span>' :
          '<button class="btn ghost sm" data-uact="' + (u.status === 'blocked' ? 'unblock' : 'block') + '" data-id="' + esc(u.id) + '">' + (u.status === 'blocked' ? 'Entsperren' : 'Sperren') + '</button> ' +
          '<button class="btn danger sm" data-uact="delete" data-id="' + esc(u.id) + '" data-name="' + esc(u.username) + '">Löschen</button>') + '</td></tr>';
    }).join('');
    return '<div class="scrollx"><table class="tbl"><thead><tr><th>Konto</th><th>Rolle</th><th>Status</th><th>2FA</th><th>Nutzung</th><th>Letzter Login</th><th></th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
      '<p class="small" style="margin-top:12px">Es gibt genau einen Owner. Das Owner-Konto kann nicht gesperrt, gelöscht oder herabgestuft werden, und kein anderes Konto kann Owner werden.</p>';
  }

  function featuresHTML() {
    var p = OW.policy;
    return '<div class="sec"><h3>Funktionen</h3><div class="grid2">' + Object.keys(FEATURE_LABELS).map(function (k) {
      return '<label class="toggle"><span>' + FEATURE_LABELS[k] + '</span><input type="checkbox" data-feat="' + k + '"' + (p.features[k] ? ' checked' : '') + '></label>';
    }).join('') + '</div></div>' +
      '<div class="sec"><h3>Denkstufen für Benutzer</h3><div class="grid2">' + Object.keys(MODE_LABELS).map(function (k) {
        return '<label class="toggle"><span>' + MODE_LABELS[k] + '</span><input type="checkbox" data-mode="' + k + '"' + (p.modes[k] ? ' checked' : '') + '></label>';
      }).join('') + '</div></div>' +
      '<div class="sec"><h3>Limits pro Benutzer und Tag (0 = unbegrenzt)</h3><div class="grid2"><label class="small">Nachrichten<input class="field" type="number" min="0" max="100000" id="limMsg" value="' + p.limits.messagesPerDay + '"></label>' +
      '<label class="small">„Hoch“ + „Pro Max“<input class="field" type="number" min="0" max="100000" id="limHeavy" value="' + p.limits.heavyPerDay + '"></label></div></div>' +
      '<div class="sec"><h3>Wartungsmodus</h3><label class="toggle"><span>Wartungsmodus aktiv (nur der Owner kann noch chatten)</span><input type="checkbox" id="mainOn"' + (p.maintenance.on ? ' checked' : '') + '></label>' +
      '<input class="field" id="mainMsg" style="margin-top:8px" maxlength="200" placeholder="Nachricht an die Benutzer" value="' + esc(p.maintenance.message) + '"></div>' +
      '<div class="sec"><h3>Websuche-Anbieter</h3><div class="row-gap"><select class="field" id="searchProv" style="width:auto"><option value="duckduckgo"' + (p.searchProvider === 'duckduckgo' ? ' selected' : '') + '>DuckDuckGo (ohne Schlüssel)</option>' +
      '<option value="brave"' + (p.searchProvider === 'brave' ? ' selected' : '') + '>Brave Search API (mit Schlüssel)</option></select>' +
      '<input class="field" id="searchKey" type="password" autocomplete="off" style="flex:1;min-width:200px" placeholder="' + (p.searchKeySet ? 'Schlüssel gespeichert – neu eingeben zum Ändern' : 'API-Schlüssel (wird verschlüsselt gespeichert)') + '">' +
      '<button class="btn ghost sm" data-oact="savekey">Schlüssel speichern</button>' + (p.searchKeySet ? '<button class="btn danger sm" data-oact="delkey">Entfernen</button>' : '') + '</div>' +
      '<p class="hint" style="margin-top:6px">Der Schlüssel wird nur im Hauptprozess verschlüsselt (Windows-Kontoschutz) gespeichert und nie an die Oberfläche zurückgegeben.</p></div>' +
      '<button class="btn" data-oact="savepolicy">Änderungen speichern</button>';
  }

  function modelHTML() {
    var e = S.engine;
    return '<p class="small" style="margin-bottom:10px">Das Modell gilt für alle Benutzer dieses Geräts. Modelle laufen komplett lokal.</p>' + S.models.map(function (m) {
      var installed = e.installed.indexOf(m.id) !== -1, active = e.state === 'ready' && e.modelId === m.id, dl = e.downloading && e.downloadingId === m.id, pct = Math.round((e.progress || 0) * 100);
      var action = dl ? '<span class="small">' + pct + ' %</span>' : active ? '<span class="badge">Aktiv</span>' :
        installed ? '<button class="btn ghost sm" data-oact="use" data-id="' + m.id + '"' + (e.state === 'loading' ? ' disabled' : '') + '>Verwenden</button>' :
          '<button class="btn sm" data-oact="download" data-id="' + m.id + '"' + (e.downloading ? ' disabled' : '') + '>Herunterladen</button>';
      return '<div class="model' + (active ? ' on' : '') + '"><div class="row"><b>' + esc(m.name) + '</b>' + action + '</div><div class="small">' + esc(m.base) + '</div><div class="small">' + m.sizeMB + ' MB · ' + esc(m.ram) +
        '</div><div class="small">' + esc(m.note) + '</div>' + (dl ? '<div class="progress"><i style="width:' + pct + '%"></i></div>' : '') + '</div>';
    }).join('') + (e.message ? '<p class="small" style="color:var(--danger)">' + esc(e.message) + '</p>' : '');
  }

  function auditHTML() {
    var a = OW.audit;
    if (!a) return '<p class="small">Wird geladen…</p>';
    return '<p class="small" style="margin-bottom:8px">Integrität der Hash-Kette: ' + (a.integrity.ok ? '<span class="pill ok">in Ordnung (' + a.integrity.count + ' Einträge)</span>' : '<span class="pill bad">VERÄNDERT – Eintrag ' + a.integrity.brokenAt + '</span>') +
      ' · Es werden nie Passwörter, Codes oder Chat-Inhalte protokolliert.</p><div style="max-height:380px;overflow:auto;border:1px solid var(--line);border-radius:12px">' +
      a.entries.map(function (x) { return '<div class="logline' + (x.ok ? '' : ' fail') + '"><span>' + esc(fmtDate(x.ts)) + '</span><span>' + esc(x.action) + ' · ' + esc(x.actor) + (x.target ? ' → ' + esc(x.target) : '') + (x.detail ? ' · ' + esc(x.detail) : '') + '</span></div>'; }).join('') + '</div>';
  }

  async function loadTab() {
    var body = $('#owBody'); if (!body) return;
    if (OW.tab === 'users') { var r = await api.adminUsers(); if (ZX.authLost(r)) return; OW.users = r.users || []; body.innerHTML = r.ok ? usersHTML() : '<p class="small">' + esc(r.error) + '</p>'; }
    else if (OW.tab === 'features') { var p = await api.adminPolicyGet(); if (ZX.authLost(p)) return; OW.policy = p.policy; body.innerHTML = p.ok ? featuresHTML() : '<p class="small">' + esc(p.error) + '</p>'; }
    else if (OW.tab === 'model') body.innerHTML = modelHTML();
    else if (OW.tab === 'audit') { body.innerHTML = auditHTML(); var a = await api.adminAudit(); if (ZX.authLost(a)) return; OW.audit = a.ok ? a : null; body.innerHTML = a.ok ? auditHTML() : '<p class="small">' + esc(a.error) + '</p>'; }
    $('#modal .tabs').querySelectorAll('button').forEach(function (b) { b.classList.toggle('on', b.dataset.tab === OW.tab); });
  }

  function collectPolicy() {
    var feats = {}, modes = {};
    document.querySelectorAll('[data-feat]').forEach(function (i) { feats[i.dataset.feat] = i.checked; });
    document.querySelectorAll('#owBody [data-mode]').forEach(function (i) { modes[i.dataset.mode] = i.checked; });
    return { features: feats, modes: modes, limits: { messagesPerDay: Number($('#limMsg').value) || 0, heavyPerDay: Number($('#limHeavy').value) || 0 },
      maintenance: { on: $('#mainOn').checked, message: $('#mainMsg').value }, searchProvider: $('#searchProv').value };
  }

  async function ownerAction(fn, okText) {
    var r = await ZX.owner(fn);
    if (r.code === 'CANCEL' || r.code === 'UNAUTH') return r;
    if (!r.ok) toast(r.error, true); else if (okText) toast(okText);
    return r;
  }

  function openOwner(tab) {
    if (!isOwner()) return;
    OW.tab = tab || 'users';
    var m = $('#modal');
    S.modalKind = 'owner';
    m.innerHTML = '<div class="card wide" role="dialog" aria-modal="true" aria-label="Owner-Bereich"><header><h2>Owner-Bereich</h2><button class="icon-btn" data-close aria-label="Schließen">' + icon('x') + '</button></header>' +
      tabs() + '<div class="body" id="owBody"></div></div>';
    m.hidden = false;
    m.onclick = async function (e) {
      if (e.target === m || e.target.closest('[data-close]')) return ZX.closeModal();
      var tb = e.target.closest('[data-tab]');
      if (tb) { OW.tab = tb.dataset.tab; return loadTab(); }
      var u = e.target.closest('[data-uact]');
      if (u) {
        var id = u.dataset.id, act = u.dataset.uact;
        if (act === 'delete') {
          if (!(await ZX.confirmDialog('Konto löschen?', '„' + u.dataset.name + '“ und alle Chats dieses Kontos werden unwiderruflich gelöscht.', 'Löschen'))) return;
          await ownerAction(function () { return api.adminDeleteUser({ id: id }); }, 'Konto gelöscht.');
        } else {
          if (act === 'block' && !(await ZX.confirmDialog('Konto sperren?', 'Der Benutzer wird sofort abgemeldet und kann sich nicht mehr anmelden.', 'Sperren'))) return;
          await ownerAction(function () { return api.adminSetStatus({ id: id, status: act === 'block' ? 'blocked' : 'active' }); }, act === 'block' ? 'Konto gesperrt.' : 'Konto entsperrt.');
        }
        return loadTab();
      }
      var o = e.target.closest('[data-oact]'); if (!o) return;
      var a = o.dataset.oact;
      if (a === 'savepolicy') {
        var r = await ownerAction(function () { return api.adminPolicySet(collectPolicy()); }, 'Gespeichert.');
        if (r.ok) { OW.policy = r.policy; S.features = r.policy.features; ZX.hooks.renderComposer(); ZX.hooks.renderThread(); }
      } else if (a === 'savekey') {
        var key = $('#searchKey').value.trim(); if (!key) { toast('Bitte einen Schlüssel eingeben.', true); return; }
        var k = await ownerAction(function () { return api.adminSetSearchKey({ key: key }); }, 'Schlüssel verschlüsselt gespeichert.');
        if (k.ok) loadTab();
      } else if (a === 'delkey') {
        var d = await ownerAction(function () { return api.adminSetSearchKey({ key: '' }); }, 'Schlüssel entfernt.');
        if (d.ok) loadTab();
      } else if (a === 'download') ZX.hooks.downloadModel(o.dataset.id);
      else if (a === 'use') ZX.hooks.useModel(o.dataset.id);
    };
    loadTab();
  }
  ZX.hooks.openOwner = openOwner;

  ZX.hooks.engineChanged = function () { if (S.modalKind === 'owner' && OW.tab === 'model' && $('#owBody')) $('#owBody').innerHTML = modelHTML(); };
})();
