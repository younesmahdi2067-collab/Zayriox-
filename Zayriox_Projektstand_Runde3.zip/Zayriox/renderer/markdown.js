// Minimaler Markdown-Renderer. HTML aus der KI wird immer maskiert (kein XSS).
(function (root) {
  function esc(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function inline(escaped) {
    var codes = [];
    var s = escaped.replace(/`([^`\n]+)`/g, function (_, c) {
      codes.push(c);
      return '\u0000' + (codes.length - 1) + '\u0000';
    });
    s = s
      .replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>')
      .replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, '$1<em>$2</em>')
      .replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="#" data-href="$2">$1</a>');
    return s.replace(/\u0000(\d+)\u0000/g, function (_, i) {
      return '<code>' + codes[Number(i)] + '</code>';
    });
  }

  function renderText(text) {
    var lines = text.split('\n');
    var html = '';
    var list = null;
    var para = [];
    function flushPara() {
      if (para.length) {
        html += '<p>' + inline(esc(para.join('\n')).replace(/\n/g, '<br>')) + '</p>';
        para = [];
      }
    }
    function closeList() {
      if (list) { html += '</' + list + '>'; list = null; }
    }
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i];
      var m;
      if (!line.trim()) { flushPara(); continue; }
      if ((m = line.match(/^(#{1,4})\s+(.*)$/))) {
        flushPara(); closeList();
        var n = Math.min(m[1].length + 1, 5);
        html += '<h' + n + '>' + inline(esc(m[2])) + '</h' + n + '>';
        continue;
      }
      if ((m = line.match(/^\s*[-*•]\s+(.*)$/))) {
        flushPara();
        if (list !== 'ul') { closeList(); html += '<ul>'; list = 'ul'; }
        html += '<li>' + inline(esc(m[1])) + '</li>';
        continue;
      }
      if ((m = line.match(/^\s*\d+[.)]\s+(.*)$/))) {
        flushPara();
        if (list !== 'ol') { closeList(); html += '<ol>'; list = 'ol'; }
        html += '<li>' + inline(esc(m[1])) + '</li>';
        continue;
      }
      if ((m = line.match(/^>\s?(.*)$/))) {
        flushPara(); closeList();
        html += '<blockquote>' + inline(esc(m[1])) + '</blockquote>';
        continue;
      }
      if (/^(-{3,}|\*{3,})$/.test(line.trim())) { flushPara(); closeList(); html += '<hr>'; continue; }
      closeList();
      para.push(line);
    }
    flushPara();
    closeList();
    return html;
  }

  function render(src) {
    var parts = String(src || '').split(/(```[\s\S]*?(?:```|$))/);
    var html = '';
    for (var i = 0; i < parts.length; i++) {
      var part = parts[i];
      if (i % 2 === 1) {
        var body = part.replace(/^```/, '').replace(/```$/, '');
        var nl = body.indexOf('\n');
        var lang = nl === -1 ? body : body.slice(0, nl);
        var code = nl === -1 ? '' : body.slice(nl + 1);
        lang = lang.trim().replace(/[^\w+#.-]/g, '').slice(0, 20);
        html +=
          '<div class="code"><div class="code-head"><span>' + (esc(lang) || 'code') +
          '</span><button type="button" class="copy-code">Kopieren</button></div><pre><code>' +
          esc(code.replace(/\n$/, '')) + '</code></pre></div>';
      } else if (part.trim()) {
        html += renderText(part);
      }
    }
    return html;
  }

  root.ZxMD = { render: render, esc: esc };
})(typeof window !== 'undefined' ? window : globalThis);
