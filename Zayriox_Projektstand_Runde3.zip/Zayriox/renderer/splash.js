window.zayriox.onSplash(function (s) {
  if (s && s.text) document.getElementById('status').textContent = s.text;
});
