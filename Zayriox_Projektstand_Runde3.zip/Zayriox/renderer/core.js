// Gemeinsame Grundlagen der Oberfläche. Die Oberfläche speichert keine Schlüssel und keine Tokens:
// Alles Sicherheitsrelevante entscheidet der Hauptprozess.
(function () {
  'use strict';
  var ZX = (window.ZX = { api: window.zayriox, esc: window.ZxMD.esc, hooks: {} });
  var esc = ZX.esc;

  ZX.$ = function (s, r) { return (r || document).querySelector(s); };
  ZX.uid = function () { return Math.random().toString(36).slice(2, 10) + Date.now().toString(36); };

  ZX.S = {
    user: null, chats: [], settings: { theme: 'dark', name: '', custom: '', mode: 'auto', webSearch: false, autoRead: false },
    modes: [], models: [], engine: { state: 'no-model', installed: [] }, version: '',
    features: { webSearch: true, voice: true, imageAnalysis: true, uploads: true, registration: true },
    maintenance: { on: false, message: '' }, usage: null,
    activeId: null, busy: false, requestId: null, streamMsg: null, streamChat: null,
    attachments: [], search: '', mlMsg: '', recording: null
  };

  // ---------- Icons ----------
  var P = {
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/>',
    sidebar: '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M9 4v16"/>',
    clip: '<path d="M21 11.5l-8.6 8.6a5 5 0 01-7.1-7.1l8.6-8.6a3.3 3.3 0 014.7 4.7l-8.6 8.6a1.7 1.7 0 01-2.4-2.4l7.9-7.9"/>',
    up: '<path d="M12 19V5"/><path d="M5 12l7-7 7 7"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="2.5" fill="currentColor" stroke="none"/>',
    chev: '<path d="M6 9l6 6 6-6"/>',
    copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 012-2h9"/>',
    redo: '<path d="M3 12a9 9 0 0115.5-6.2L21 8"/><path d="M21 3v5h-5"/>',
    trash: '<path d="M3 6h18"/><path d="M8 6V4a1 1 0 011-1h6a1 1 0 011 1v2"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>',
    x: '<path d="M18 6L6 18M6 6l12 12"/>',
    check: '<path d="M20 6L9 17l-5-5"/>',
    file: '<path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z"/><path d="M14 3v5h5"/>',
    warn: '<path d="M12 9v4"/><path d="M12 17h.01"/><path d="M10.3 3.9L1.8 18a2 2 0 001.7 3h17a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0z"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a14 14 0 010 18M12 3a14 14 0 000 18"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0014 0"/><path d="M12 18v3"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
    logout: '<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
    speaker: '<path d="M11 5L6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 010 7M18.5 5.5a9 9 0 010 13"/>'
  };
  ZX.icon = function (name, size) {
    size = size || 18;
    return '<svg width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + P[name] + '</svg>';
  };
  ZX.hydrateIcons = function (root) {
    (root || document).querySelectorAll('[data-icon]').forEach(function (el) { el.innerHTML = ZX.icon(el.dataset.icon); });
  };

  // ---------- Toasts ----------
  ZX.toast = function (msg, isErr) {
    var el = document.createElement('div');
    el.className = 'toast' + (isErr ? ' err' : '');
    el.textContent = msg;
    ZX.$('#toasts').appendChild(el);
    setTimeout(function () { el.remove(); }, 4500);
  };

  // ---------- Dialoge ----------
  ZX.closeModal = function (id) { var m = ZX.$(id || '#modal'); m.hidden = true; m.innerHTML = ''; m.onclick = null; if (!id || id === '#modal') ZX.S.modalKind = null; };

  ZX.confirmDialog = function (title, text, okLabel, danger) {
    return new Promise(function (resolve) {
      var m = ZX.$('#modal2');
      m.innerHTML = '<div class="card small" role="dialog" aria-modal="true"><h2>' + esc(title) + '</h2><p class="small">' + esc(text) +
        '</p><div class="actions"><button class="btn ghost" data-r="0">Abbrechen</button><button class="btn ' + (danger === false ? '' : 'danger') + '" data-r="1">' + esc(okLabel) + '</button></div></div>';
      m.hidden = false;
      m.onclick = function (e) {
        var b = e.target.closest('[data-r]');
        if (b || e.target === m) { ZX.closeModal('#modal2'); resolve(!!b && b.dataset.r === '1'); }
      };
    });
  };

  /** Eingabe-Dialog. onSubmit(werte) liefert null bei Erfolg (Dialog schließt) oder eine Fehlermeldung (Dialog bleibt offen). */
  ZX.formDialog = function (title, text, fields, okLabel, onSubmit) {
    return new Promise(function (resolve) {
      var m = ZX.$('#modal2');
      m.innerHTML = '<div class="card small" role="dialog" aria-modal="true"><h2>' + esc(title) + '</h2>' + (text ? '<p class="small">' + esc(text) + '</p>' : '') +
        '<form style="display:grid;gap:12px">' + fields.map(function (f) {
          return '<label class="small" style="display:grid;gap:5px">' + esc(f.label) + '<input class="field" name="' + f.name + '" type="' + (f.type || 'text') +
            '" autocomplete="' + (f.autocomplete || 'off') + '"' + (f.inputmode ? ' inputmode="' + f.inputmode + '"' : '') + '></label>';
        }).join('') + '<div class="auth-msg" role="alert"></div><div class="actions"><button type="button" class="btn ghost" data-r="0">Abbrechen</button><button class="btn" type="submit">' + esc(okLabel) + '</button></div></form></div>';
      m.hidden = false;
      var first = m.querySelector('input'); if (first) first.focus();
      m.onclick = function (e) { if (e.target === m || e.target.closest('[data-r]')) { ZX.closeModal('#modal2'); resolve(false); } };
      m.querySelector('form').addEventListener('submit', async function (e) {
        e.preventDefault();
        var v = {};
        fields.forEach(function (f) { v[f.name] = m.querySelector('[name="' + f.name + '"]').value; });
        var btn = m.querySelector('button[type=submit]'), msg = m.querySelector('.auth-msg');
        btn.disabled = true; msg.textContent = '';
        var err = await onSubmit(v);
        if (err) { msg.textContent = err; btn.disabled = false; }
        else { ZX.closeModal('#modal2'); resolve(true); }
      });
    });
  };

  // ---------- Sitzung / Step-up ----------
  ZX.authLost = function (r) {
    if (r && r.code === 'UNAUTH') {
      ZX.hooks.showAuth('login', { message: 'Deine Sitzung ist abgelaufen. Bitte melde dich erneut an.' });
      return true;
    }
    return false;
  };

  /** Owner-Aufruf: Bei "STEPUP" wird Passwort + frischer 2FA-Code abgefragt, dann wird der Aufruf wiederholt. */
  ZX.owner = async function (call) {
    var r = await call();
    if (ZX.authLost(r)) return { ok: false, error: 'Sitzung abgelaufen.', code: 'UNAUTH' };
    if (r && r.code === 'STEPUP') {
      var ok = await ZX.formDialog('Bestätigung erforderlich',
        'Für diese Owner-Aktion brauchst du dein Passwort und einen frischen Code aus deiner Authenticator-App. Jeder Code gilt nur einmal – warte ggf. auf den nächsten.',
        [{ name: 'password', label: 'Passwort', type: 'password', autocomplete: 'current-password' }, { name: 'code', label: '2FA-Code (6 Stellen)', inputmode: 'numeric' }],
        'Bestätigen',
        async function (v) {
          var s = await ZX.api.adminStepUp({ password: v.password, code: v.code });
          if (ZX.authLost(s)) return 'Sitzung abgelaufen.';
          return s.ok ? null : s.error;
        });
      if (!ok) return { ok: false, error: 'Abgebrochen.', code: 'CANCEL' };
      r = await call();
    }
    return r;
  };
})();
