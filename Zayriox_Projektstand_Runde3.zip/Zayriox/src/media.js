// Prüfungen für Bilder und Audio (alles, was aus der Oberfläche kommt, gilt als nicht vertrauenswürdig).
export const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
export const MAX_AUDIO_SECONDS = 90;
export const SAMPLE_RATE = 16000;

/** Erkennt das echte Format an den ersten Bytes – nicht am Dateinamen. */
export function sniffImage(buf) {
  const b = Buffer.from(buf);
  if (b.length < 12) return null;
  if (b[0] === 0x89 && b.toString('latin1', 1, 4) === 'PNG') return 'image/png';
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'image/jpeg';
  if (b.toString('latin1', 0, 3) === 'GIF') return 'image/gif';
  if (b.toString('latin1', 0, 4) === 'RIFF' && b.toString('latin1', 8, 12) === 'WEBP') return 'image/webp';
  return null;
}

export function toFloat32(data) {
  if (data instanceof Float32Array) return data;
  const u8 = data instanceof ArrayBuffer ? new Uint8Array(data) : ArrayBuffer.isView(data) ? new Uint8Array(data.buffer, data.byteOffset, data.byteLength) : null;
  if (!u8 || u8.byteLength % 4) return null;
  return new Float32Array(u8.slice().buffer);
}

export function validateAudio(data) {
  const f = toFloat32(data);
  if (!f) return null;
  if (f.length < SAMPLE_RATE * 0.3 || f.length > SAMPLE_RATE * MAX_AUDIO_SECONDS) return null;
  for (let i = 0; i < f.length; i += 97) if (!Number.isFinite(f[i])) return null;
  return f;
}

/** Liest eine WAV-Datei (PCM 8/16/24/32 Bit oder Float32) und liefert 16-kHz-Mono-Float32 für die Spracherkennung. */
export function wavToFloat32(input, targetRate = SAMPLE_RATE) {
  const b = Buffer.from(input);
  if (b.length < 44 || b.toString('latin1', 0, 4) !== 'RIFF' || b.toString('latin1', 8, 12) !== 'WAVE') return null;
  let pos = 12, fmt = null, data = null;
  while (pos + 8 <= b.length) {
    const id = b.toString('latin1', pos, pos + 4), size = b.readUInt32LE(pos + 4), start = pos + 8;
    if (id === 'fmt ') fmt = { tag: b.readUInt16LE(start), ch: b.readUInt16LE(start + 2), rate: b.readUInt32LE(start + 4), bits: b.readUInt16LE(start + 14) };
    if (id === 'data') { data = b.subarray(start, Math.min(start + size, b.length)); break; }
    pos = start + size + (size % 2);
  }
  if (!fmt || !data || !fmt.ch) return null;
  const bytes = fmt.bits / 8, frames = Math.floor(data.length / (bytes * fmt.ch)), mono = new Float32Array(frames);
  for (let i = 0; i < frames; i++) {
    let sum = 0;
    for (let c = 0; c < fmt.ch; c++) {
      const o = (i * fmt.ch + c) * bytes;
      sum += fmt.tag === 3 ? data.readFloatLE(o) : fmt.bits === 16 ? data.readInt16LE(o) / 32768 : fmt.bits === 8 ? (data[o] - 128) / 128 : fmt.bits === 24 ? data.readIntLE(o, 3) / 8388608 : data.readInt32LE(o) / 2147483648;
    }
    mono[i] = sum / fmt.ch;
  }
  if (fmt.rate === targetRate) return mono;
  const ratio = fmt.rate / targetRate, n = Math.floor(mono.length / ratio), out = new Float32Array(n);
  for (let i = 0; i < n; i++) { const p = i * ratio, i0 = Math.floor(p), i1 = Math.min(i0 + 1, mono.length - 1); out[i] = mono[i0] + (mono[i1] - mono[i0]) * (p - i0); }
  return out;
}
