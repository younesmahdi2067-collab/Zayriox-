// Alle Funktionen, die die Oberfläche aufrufen darf. Die Oberfläche gilt als NICHT vertrauenswürdig:
// Rechte, Rollen und Limits werden hier im Hauptprozess bei jedem Aufruf neu geprüft.
import { listModes, MODES, resolveAuto } from './modes.js';
import { MODELS } from './models.js';
import { runChat } from './pipeline.js';
import { extractText, MAX_FILE_BYTES } from './files.js';
import { webSearchWithFallback } from './search.js';
import { sniffImage, validateAudio, MAX_IMAGE_BYTES } from './media.js';
import { publicUser } from './accounts.js';
import { ZxError, MESSAGES, friendly } from './errors.js';
import { TARIFFS } from './tariffs.js';

const ORDER = ['schnell', 'mittel', 'hoch', 'promax'];
const bad = () => { throw new ZxError('INVALID'); };
const err = (code, msg) => ({ ok: false, code, error: msg || MESSAGES[code] });

export function validateSend(p) {
  if (!p || typeof p !== 'object') bad();
  if (typeof p.requestId !== 'string' || p.requestId.length > 64) bad();
  if (!Array.isArray(p.messages) || p.messages.length < 1 || p.messages.length > 400) bad();
  const messages = p.messages.map((m) => {
    if (!m || (m.role !== 'user' && m.role !== 'assistant') || typeof m.content !== 'string' || m.content.length > 30000) bad();
    const attach = Array.isArray(m.attach)
      ? m.attach.slice(0, 8).map((a) => {
          if (!a || typeof a.name !== 'string' || typeof a.text !== 'string') bad();
          return { name: a.name.slice(0, 200), text: a.text.slice(0, 30000) };
        })
      : undefined;
    return { role: m.role, content: m.content, attach };
  });
  const last = messages[messages.length - 1];
  if (last.role !== 'user' || last.content.length > 8000) bad();
  const images = Array.isArray(p.images) ? p.images.slice(0, 3).map((i) => {
    if (!i || typeof i.name !== 'string' || !i.data) bad();
    const buf = Buffer.from(i.data instanceof ArrayBuffer ? new Uint8Array(i.data) : i.data);
    if (buf.length > MAX_IMAGE_BYTES) throw new ZxError('FILE_TOO_BIG');
    if (!sniffImage(buf)) throw new ZxError('IMAGE_UNSUPPORTED');
    return { name: i.name.slice(0, 200), data: buf };
  }) : [];
  return { requestId: p.requestId, mode: typeof p.mode === 'string' ? p.mode : 'auto', messages, images, webSearch: p.webSearch === true };
}

function enabledFallback(used, enabled) {
  const i = ORDER.indexOf(used);
  for (let k = i; k >= 0; k--) if (enabled[ORDER[k]]) return ORDER[k];
  for (let k = i + 1; k < ORDER.length; k++) if (enabled[ORDER[k]]) return ORDER[k];
  return null;
}

export function createApi(svc, { version = '0.0.0', selfPath = null } = {}) {
  const { auth, admin, policy, engine, ml, accounts, audit, vault } = svc;
  let active = null;
  let transcribing = false;
  const recent = new Map();

  const burst = (userId) => {
    const now = Date.now();
    const list = (recent.get(userId) || []).filter((t) => now - t < 60000);
    if (list.length >= 40) { recent.set(userId, list); return true; }
    list.push(now); recent.set(userId, list);
    return false;
  };

  const H = {
    // ----- Anmeldung (ohne Sitzung erlaubt) -----
    'auth:status': (c) => ({ ok: true, ...auth.status(c.sid) }),
    'auth:setup': (c, p) => auth.setupOwner(c.sid, p || {}),
    'auth:register': (c, p) => auth.register(c.sid, p || {}),
    'auth:login': (c, p) => auth.login(c.sid, p || {}),
    'auth:verify2fa': (c, p) => auth.verify2fa(c.sid, p || {}),
    'auth:enroll': (c, p) => auth.confirmEnroll(c.sid, p || {}),
    'auth:qr': async (c, uri) => {
      if (typeof uri !== 'string' || !uri.startsWith('otpauth://')) throw new ZxError('INVALID');
      if (uri.length > 2048) throw new ZxError('INVALID');
      let QRCode;
      try { QRCode = (await import('qrcode')).default; } catch { return { ok: false, code: 'QR_UNAVAILABLE', error: 'QR-Code nicht verfügbar – bitte den Schlüssel manuell eingeben.' }; }
      return { ok: true, dataUrl: await QRCode.toDataURL(uri, { errorCorrectionLevel: 'M', margin: 2, width: 220 }) };
    },
    'auth:ping': (c) => { auth.requireUser(c.sid); return { ok: true }; },
    'auth:logout': (c) => { api.abortFor(c.sid); if (c.setTheme) c.setTheme('dark'); return auth.logout(c.sid); },

    // ----- Angemeldete Nutzer -----
    'app:load': (c) => {
      const { user } = auth.requireUser(c.sid);
      const pol = policy.get();
      const st = svc.userStore(user.id);
      const settings = st.loadSettings();
      const modes = listModes().filter((m) => m.id === 'auto' || pol.modes[m.id]);
      if (!modes.some((m) => m.id === settings.mode)) settings.mode = 'auto';
      if (c.setTheme) c.setTheme(settings.theme);
      return {
        ok: true, version, user: publicUser(user), chats: st.loadChats(), settings, modes,
        models: MODELS.map(({ url, file, ...m }) => m), engine: engine.status,
        features: pol.features, maintenance: pol.maintenance, tariffs: TARIFFS, usage: { ...policy.usageOf(user.id), limits: pol.limits }
      };
    },
    'chats:save': (c, chats) => { const { user } = auth.requireUser(c.sid); svc.userStore(user.id).saveChats(chats); return { ok: true }; },
    'settings:save': (c, s) => {
      const { user } = auth.requireUser(c.sid);
      const st = svc.userStore(user.id);
      const next = st.saveSettings({ ...st.loadSettings(), ...(s || {}) });
      if (c.setTheme) c.setTheme(next.theme);
      return { ok: true, settings: next };
    },

    'chat:send': (c, payload) => {
      const { user } = auth.requireUser(c.sid);
      const pol = policy.get();
      if (pol.maintenance.on && user.role !== 'owner') return err('MAINTENANCE', pol.maintenance.message || MESSAGES.MAINTENANCE);
      let v;
      try { v = validateSend(payload); } catch (e) { return err(e.code || 'INVALID', e.message); }
      const last = v.messages[v.messages.length - 1];
      if (v.images.length && !pol.features.imageAnalysis) return err('FEATURE_OFF');
      if (last.attach && last.attach.length && !pol.features.uploads) return err('FEATURE_OFF');
      const useSearch = v.webSearch && pol.features.webSearch;

      const wasAuto = v.mode === 'auto';
      let used = wasAuto ? resolveAuto(last.content, { hasFiles: !!(last.attach && last.attach.length) || v.images.length > 0 }) : MODES[v.mode] ? v.mode : 'mittel';
      if (!pol.modes[used]) {
        if (!wasAuto) return err('MODE_OFF');
        used = enabledFallback(used, pol.modes);
        if (!used) return err('MODE_OFF');
      }
      const lim = policy.check(user, used);
      if (!lim.ok) return err('LIMIT', lim.reason);
      if (active) return err('BUSY');
      if (burst(user.id)) return err('RATE_LIMIT');

      policy.record(user.id, used);
      const controller = new AbortController();
      active = { sid: c.sid, id: v.requestId, controller };
      const emit = (ev) => c.notify('chat:event', { requestId: v.requestId, ...ev });
      const custom = svc.userStore(user.id).loadSettings().custom;
      const braveSealed = policy.getSecret('braveKey');
      const search = useSearch ? (q) => webSearchWithFallback(q, { provider: pol.searchProvider, braveKey: braveSealed ? vault.open(braveSealed) : null, signal: controller.signal }) : null;

      (async () => {
        try {
          const r = await runChat({
            engine, mode: used, wasAuto, messages: v.messages, custom, signal: controller.signal, emit,
            search, images: v.images, describeImage: ml ? (buf) => ml.describeImage(buf) : null
          });
          emit({ type: 'done', stopped: !!r.stopped });
        } catch (e) {
          svc.log('Chat-Fehler', e);
          emit({ type: 'error', message: friendly(e) });
        } finally { active = null; }
      })();
      return { ok: true };
    },
    'chat:stop': (c, id) => { auth.requireUser(c.sid, false); if (active && active.sid === c.sid && active.id === id) active.controller.abort(); return { ok: true }; },

    'file:extract': async (c, p) => {
      auth.requireUser(c.sid);
      if (!policy.get().features.uploads) return err('FEATURE_OFF');
      if (!p || typeof p.name !== 'string' || !p.data) bad();
      if (p.data.byteLength > MAX_FILE_BYTES) throw new ZxError('FILE_TOO_BIG');
      return { ok: true, ...(await extractText(p.name, p.data)) };
    },

    'voice:transcribe': async (c, data) => {
      auth.requireUser(c.sid);
      if (!policy.get().features.voice) return err('FEATURE_OFF');
      const audio = validateAudio(data);
      if (!audio) bad();
      if (transcribing) return err('BUSY');
      if (!ml) return err('VOICE_FAILED');
      transcribing = true;
      try { return { ok: true, text: await ml.transcribe(audio) }; } finally { transcribing = false; }
    },

    'account:changePassword': (c, p) => auth.changePassword(c.sid, p || {}),
    'account:totpBegin': (c, p) => auth.totpBegin(c.sid, p || {}),
    'account:totpConfirm': (c, p) => auth.totpConfirm(c.sid, p || {}),
    'account:totpDisable': (c, p) => auth.totpDisable(c.sid, p || {}),
    'account:delete': async (c, p) => { api.abortFor(c.sid); return auth.deleteOwnAccount(c.sid, p || {}); },

    'shell:open': (c, url) => {
      auth.requireUser(c.sid);
      try { const u = new URL(String(url)); if (u.protocol === 'https:' || u.protocol === 'http:') c.openExternal(u.toString()); } catch { /* ignorieren */ }
      return { ok: true };
    },

    // ----- Owner (jeder Aufruf prüft die Rolle serverseitig) -----
    'admin:stepUp': (c, p) => admin.stepUp(c.sid, p || {}),
    'admin:users': (c) => admin.listUsers(c.sid),
    'admin:setStatus': (c, p) => admin.setStatus(c.sid, p || {}),
    'admin:deleteUser': (c, p) => admin.deleteUser(c.sid, p || {}),
    'admin:policyGet': (c) => admin.getPolicy(c.sid),
    'admin:policySet': (c, p) => admin.setPolicy(c.sid, p),
    'admin:setSearchKey': (c, p) => admin.setSearchKey(c.sid, p || {}),
    'admin:audit': (c) => admin.audit_(c.sid),
    'admin:modelDownload': async (c, id) => {
      auth.requireOwner(c.sid);
      await engine.download(String(id));
      await engine.load(String(id));
      policy.set({ modelId: String(id) });
      audit.append({ actor: auth.requireOwner(c.sid).user.id, action: 'admin.model.download', detail: String(id) });
      return { ok: true };
    },
    'admin:modelUse': async (c, id) => {
      const { user } = auth.requireOwner(c.sid, { stepUp: true });
      await engine.load(String(id));
      policy.set({ modelId: String(id) });
      audit.append({ actor: user.id, action: 'admin.model.use', detail: String(id) });
      return { ok: true };
    }
  };

  const api = {
    channels: Object.keys(H),
    abortFor(sid) { if (active && active.sid === sid) active.controller.abort(); },
    isBusy: () => !!active,
    async invoke(channel, ctx, payload) {
      const h = Object.prototype.hasOwnProperty.call(H, channel) ? H[channel] : null;
      if (!h) return err('INVALID');
      try {
        if ((channel === 'admin:modelDownload' || channel === 'admin:modelUse') && active) throw new ZxError('BUSY');
        const r = await h(ctx, payload);
        return r === undefined ? { ok: true } : r;
      } catch (e) {
        if (e instanceof ZxError) return err(e.code, e.message);
        svc.log(`Fehler in ${channel}`, e);
        return err('ERR', friendly(e));
      }
    }
  };
  return api;
}
