// TOTP (RFC 6238) ohne externe Bibliothek: kompatibel mit Google/Microsoft Authenticator, Authy, 1Password …
import crypto from 'node:crypto';

const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

export function base32Encode(buf) {
  let bits = 0, value = 0, out = '';
  for (const byte of buf) {
    value = (value << 8) | byte; bits += 8;
    while (bits >= 5) { out += B32[(value >>> (bits - 5)) & 31]; bits -= 5; }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}

export function base32Decode(str) {
  const clean = String(str).toUpperCase().replace(/[^A-Z2-7]/g, '');
  let bits = 0, value = 0;
  const out = [];
  for (const ch of clean) {
    value = (value << 5) | B32.indexOf(ch); bits += 5;
    if (bits >= 8) { out.push((value >>> (bits - 8)) & 255); bits -= 8; }
  }
  return Buffer.from(out);
}

export const generateSecret = () => base32Encode(crypto.randomBytes(20));

export function hotp(secretB32, counter, digits = 6) {
  const msg = Buffer.alloc(8);
  msg.writeBigUInt64BE(BigInt(counter));
  const h = crypto.createHmac('sha1', base32Decode(secretB32)).update(msg).digest();
  const o = h[h.length - 1] & 0xf;
  const bin = ((h[o] & 0x7f) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3];
  return String(bin % 10 ** digits).padStart(digits, '0');
}

export const totpAt = (secret, timeMs, step = 30) => hotp(secret, Math.floor(timeMs / 1000 / step));

/** Liefert den verwendeten Zähler bei Erfolg, sonst null. Codes dürfen nicht wiederverwendet werden (lastCounter). */
export function verifyTotp(secret, code, { now = Date.now(), window = 1, lastCounter = -1 } = {}) {
  const c = String(code || '').replace(/\s/g, '');
  if (!/^\d{6}$/.test(c)) return null;
  const base = Math.floor(now / 30000);
  let found = null;
  for (let i = -window; i <= window; i++) {
    const counter = base + i;
    const expected = hotp(secret, counter);
    // konstante Laufzeit: alle Fenster prüfen
    if (crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(c)) && counter > lastCounter && found === null) found = counter;
  }
  return found;
}

export const otpauthUri = ({ secret, account, issuer = 'Zayriox' }) =>
  `otpauth://totp/${encodeURIComponent(issuer)}:${encodeURIComponent(account)}?secret=${secret}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`;
