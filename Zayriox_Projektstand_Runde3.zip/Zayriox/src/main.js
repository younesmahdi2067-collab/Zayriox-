import { app, BrowserWindow, ipcMain, shell, Menu, session, safeStorage, webContents } from 'electron';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { Engine } from './engine.js';
import { MlService } from './ml.js';
import { createServices } from './services.js';
import { createApi } from './api.js';
import { osCipher, fileCipher } from './vault.js';
import { getModel } from './models.js';
import { APP_NAME } from './config.js';
import { runSelfTest } from './selftest.js';
import electronUpdater from 'electron-updater';
const { autoUpdater } = electronUpdater;

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, '..');
const PRELOAD = path.join(__dirname, 'preload.cjs');
const ICON = path.join(ROOT, 'assets', 'icon.png');
const TRUSTED_PREFIX = pathToFileURL(path.join(ROOT, 'renderer')).href;
const MIN_SPLASH_MS = 2200;
const argVal = (n) => { const a = process.argv.find((x) => x.startsWith(`${n}=`)); return a ? a.slice(n.length + 1) : null; };
const SELFTEST = process.argv.includes('--selftest');
if (SELFTEST && argVal('--selftest-dir')) app.setPath('userData', argVal('--selftest-dir'));

let splash = null;
let win = null;
let svc = null;
let api = null;
let updaterReady = false;

function log(...args) {
  try {
    const dir = path.join(app.getPath('userData'), 'logs');
    fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(path.join(dir, 'zayriox.log'), `${new Date().toISOString()} ${args.map((a) => (a && a.stack) || String(a)).join(' ')}\n`);
  } catch { /* Logging darf nie crashen */ }
}
process.on('uncaughtException', (e) => log('uncaughtException', e));
process.on('unhandledRejection', (e) => log('unhandledRejection', e));

const webPreferences = { preload: PRELOAD, contextIsolation: true, nodeIntegration: false, sandbox: true, webSecurity: true, webviewTag: false, spellcheck: false };
const send = (target, channel, payload) => { if (target && !target.isDestroyed()) target.webContents.send(channel, payload); };
const overlay = (theme) => (theme === 'light' ? { color: '#ffffff', symbolColor: '#1a1a1f', height: 52 } : { color: '#0f0f12', symbolColor: '#e9e9ee', height: 52 });

function createSplash() {
  splash = new BrowserWindow({ width: 460, height: 340, frame: false, resizable: false, maximizable: false, center: true, show: false, backgroundColor: '#0c0c0f', icon: ICON, title: APP_NAME, webPreferences });
  splash.loadFile(path.join(ROOT, 'renderer', 'splash.html'));
  splash.once('ready-to-show', () => splash && splash.show());
}

export function createMain({ show = false, url = null, noThrottle = false } = {}) {
  const w = new BrowserWindow({
    width: 1280, height: 820, minWidth: 880, minHeight: 560, show,
    backgroundColor: '#0f0f12', title: APP_NAME, icon: ICON,
    titleBarStyle: 'hidden', titleBarOverlay: overlay('dark'),
    webPreferences: noThrottle ? { ...webPreferences, backgroundThrottling: false } : webPreferences
  });
  if (url) w.loadURL(url); else w.loadFile(path.join(ROOT, 'renderer', 'index.html'));
  w.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  w.webContents.on('will-navigate', (e) => e.preventDefault());
  w.webContents.on('will-attach-webview', (e) => e.preventDefault());
  return w;
}

export function setupAutoUpdate() {
  if (!app.isPackaged || SELFTEST) return;
  try {
    autoUpdater.autoDownload = true;
    autoUpdater.autoInstallOnAppQuit = true;
    autoUpdater.on('update-available', () => send(win, 'update:status', { state: 'available' }));
    autoUpdater.on('download-progress', (p) => send(win, 'update:status', { state: 'downloading', percent: Math.round(p.percent || 0) }));
    autoUpdater.on('update-downloaded', () => send(win, 'update:status', { state: 'ready' }));
    autoUpdater.on('error', (e) => log('Updater-Fehler', e));
    updaterReady = true;
    setTimeout(() => autoUpdater.checkForUpdates().catch((e) => log('Update-Prüfung fehlgeschlagen', e)), 5000);
  } catch (e) { log('Updater-Initialisierung fehlgeschlagen', e); }
}

function hardenSession() {
  const allowMic = (wc, permission, details) => permission === 'media' && win && wc === win.webContents &&
    String(details && (details.requestingUrl || '')).startsWith(TRUSTED_PREFIX) && (!details.mediaTypes || details.mediaTypes.every((t) => t === 'audio'));
  session.defaultSession.setPermissionRequestHandler((wc, permission, cb, details) => cb(!!allowMic(wc, permission, details)));
  session.defaultSession.setPermissionCheckHandler((wc, permission, _origin, details) => !!allowMic(wc, permission, { ...details, requestingUrl: details.requestingUrl || details.embeddingOrigin || '' }));
}

export function buildServices({ dir, scryptN }) {
  const engine = new Engine({ modelsDir: path.join(dir, 'models'), onStatus: (s) => send(win, 'engine:status', s), log });
  const ml = new MlService({ cacheDir: path.join(dir, 'ml-cache'), onStatus: (s) => send(win, 'ml:status', s), log });
  const cipher = safeStorage.isEncryptionAvailable() ? osCipher(safeStorage) : fileCipher(dir);
  const s = createServices({
    dir, cipher, engine, ml, log, scryptN,
    onSessionEnd: (sid, reason) => { if (api) api.abortFor(sid); const wc = webContents.fromId(sid); if (wc && !wc.isDestroyed()) wc.send('session:ended', { reason }); }
  });
  s.cipherName = cipher.name;
  return s;
}

export function registerIpc(theApi = api) {
  for (const channel of theApi.channels) {
    ipcMain.handle(channel, (e, payload) => {
      // Nur Aufrufe aus unserer eigenen Oberfläche (lokale Dateien der App) werden akzeptiert.
      const url = e.senderFrame ? e.senderFrame.url : '';
      if (!url.startsWith(TRUSTED_PREFIX)) return { ok: false, code: 'FORBIDDEN', error: 'Nicht erlaubter Absender.' };
      const ctx = { sid: e.sender.id, notify: (c, p) => { if (!e.sender.isDestroyed()) e.sender.send(c, p); }, openExternal: (u) => shell.openExternal(u),
        setTheme: (t) => { if (win && !win.isDestroyed()) { try { win.setTitleBarOverlay(overlay(t)); } catch { /* nicht überall verfügbar */ } } } };
      return theApi.invoke(channel, ctx, payload);
    });
  }
}

async function start() {
  Menu.setApplicationMenu(null);
  hardenSession();
  svc = buildServices({ dir: app.getPath('userData') });
  api = createApi(svc, { version: app.getVersion() });
  registerIpc();
  setInterval(() => svc.auth.sweep(), 30000).unref();

  createSplash();
  win = createMain();
  win.on('closed', () => { win = null; });
  const started = Date.now();
  send(splash, 'splash:status', { text: `${APP_NAME} wird gestartet…` });
  await new Promise((resolve) => win.once('ready-to-show', resolve));

  const wanted = getModel(svc.policy.get().modelId) && svc.engine.isInstalled(svc.policy.get().modelId) ? svc.policy.get().modelId : svc.engine.status.installed[0];
  if (wanted) {
    send(splash, 'splash:status', { text: 'KI wird geladen…' });
    try { await svc.engine.load(wanted); } catch (e) { log('Start: Modell laden fehlgeschlagen', e); }
  }
  const wait = MIN_SPLASH_MS - (Date.now() - started);
  if (wait > 0) await new Promise((r) => setTimeout(r, wait));
  if (win) win.show();
  if (splash) { splash.close(); splash = null; }
  setupAutoUpdate();
}

if (!app.requestSingleInstanceLock() && !SELFTEST) {
  app.quit();
} else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.whenReady().then(async () => {
    if (SELFTEST) {
      await runSelfTest({ app, argVal, createMain, buildServices, createApi, registerIpc, hardenSession, setWin: (w) => { win = w; }, root: ROOT, log });
      return;
    }
    try { await start(); } catch (e) { log('Startfehler', e); if (splash) splash.close(); if (win) win.show(); }
  });
  app.on('window-all-closed', () => app.quit());
  app.on('before-quit', () => { if (svc) svc.engine.dispose().catch(() => {}); });
}
