import crypto from 'node:crypto';
import { hashPassword, verifyPassword, validatePassword, validateUsername, validateEmail, publicUser } from './accounts.js';
import { generateSecret, verifyTotp, otpauthUri } from './totp.js';
import { ZxError } from './errors.js';

const MIN = 60 * 1000;
export const TIMES = { idleUser: 30 * MIN, idleOwner: 10 * MIN, absolute: 12 * 60 * MIN, stepUp: 5 * MIN, challenge: 5 * MIN };
const GENERIC = 'Benutzername oder Passwort falsch.';
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const normCode = (c) => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
const fail = (error, code = 'AUTH') => ({ ok: false, code, error });
const wait = (ms) => { const m = Math.ceil(ms / 60000); return m <= 1 ? 'einer Minute' : `${m} Minuten`; };

export class AuthService {
  constructor({ accounts, audit, vault, policy, now = Date.now, scryptN = 32768, onSessionEnd = () => {}, onUserRemoved = () => {} }) {
    Object.assign(this, { accounts, audit, vault, policy, now, scryptN, onSessionEnd, onUserRemoved });
    this.sessions = new Map();   // Sender-ID -> Session (bleibt im Hauptprozess; die Oberfläche kennt keinen Token)
    this.challenges = new Map(); // Sender-ID -> offene 2FA-/Einrichtungs-Abfrage
    this.fails = new Map();      // Benutzername -> Fehlversuche
    this.globalFails = [];
    this.regs = [];
    this.dummy = null;
  }

  // ---------- Sessions ----------
  _end(sid, reason) {
    const s = this.sessions.get(sid);
    if (!s) return;
    this.sessions.delete(sid);
    this.audit.append({ actor: s.userId, action: 'session.end', detail: reason });
    this.onSessionEnd(sid, reason);
  }

  _session(sid, touch = true) {
    const s = this.sessions.get(sid);
    if (!s) return null;
    const t = this.now();
    const idle = s.role === 'owner' ? TIMES.idleOwner : TIMES.idleUser;
    if (t - s.lastActive > idle) { this._end(sid, 'idle'); return null; }
    if (t - s.createdAt > TIMES.absolute) { this._end(sid, 'max-age'); return null; }
    const u = this.accounts.byId(s.userId);
    if (!u || u.status === 'blocked') { this._end(sid, 'account-invalid'); return null; }
    if (touch) s.lastActive = t;
    return s;
  }

  /** Prüft Sitzung serverseitig bei JEDEM Aufruf. Die Rolle kommt aus der signierten Kontodatei, nie aus der Oberfläche. */
  requireUser(sid, touch = true) {
    const session = this._session(sid, touch);
    if (!session) throw new ZxError('UNAUTH');
    return { user: this.accounts.byId(session.userId), session };
  }

  requireOwner(sid, { stepUp = false } = {}) {
    const r = this.requireUser(sid);
    if (r.user.role !== 'owner') {
      this.audit.append({ actor: r.user.id, action: 'authz.denied', ok: false, detail: 'owner-only' });
      throw new ZxError('FORBIDDEN');
    }
    if (stepUp && this.now() - (r.session.stepUpAt || 0) > TIMES.stepUp) throw new ZxError('STEPUP');
    return r;
  }

  endSessionsOf(userId, exceptSid = null, reason = 'revoked') {
    for (const [sid, s] of [...this.sessions]) if (s.userId === userId && sid !== exceptSid) this._end(sid, reason);
  }

  /** Beendet abgelaufene Sitzungen aktiv (die Oberfläche wird benachrichtigt). */
  sweep() { for (const sid of [...this.sessions.keys()]) this._session(sid, false); }

  logout(sid) { this._end(sid, 'logout'); this.challenges.delete(sid); return { ok: true }; }

  status(sid) {
    if (this.accounts.state === 'tampered') return { phase: 'tampered', error: new ZxError('TAMPERED').message };
    const s = this._session(sid, false);
    const pol = this.policy.get();
    const base = { registration: pol.features.registration, maintenance: pol.maintenance };
    if (s) return { phase: 'app', user: publicUser(this.accounts.byId(s.userId)), ...base };
    return { phase: this.accounts.hasOwner() ? 'login' : 'setup', ...base };
  }

  // ---------- Login-Schutz ----------
  _locked(key) {
    const t = this.fails.get(key);
    const g = this.globalFails.filter((x) => this.now() - x < 10 * MIN);
    this.globalFails = g;
    if (g.length >= 25) return 10 * MIN;
    return t && t.until > this.now() ? t.until - this.now() : 0;
  }
  _fail(key) {
    const t = this.fails.get(key) || { count: 0, until: 0 };
    t.count++;
    if (t.count >= 5) t.until = this.now() + Math.min(30 * MIN, MIN * 2 ** (t.count - 5));
    this.fails.set(key, t);
    this.globalFails.push(this.now());
  }
  async _verify(user, password) {
    if (!this.dummy) this.dummy = await hashPassword('dummy-Passwort-1', this.scryptN);
    const ok = await verifyPassword(password, user ? user.pw : this.dummy); // immer rechnen: gleiche Laufzeit
    return !!user && ok;
  }

  // ---------- Sitzung starten ----------
  _start(sid, user) {
    this.challenges.delete(sid);
    this.sessions.set(sid, { userId: user.id, role: user.role, createdAt: this.now(), lastActive: this.now(), stepUpAt: 0 });
    this.accounts.patch(user.id, (u) => { u.lastLogin = new Date(this.now()).toISOString(); });
    this.audit.append({ actor: user.id, action: 'login.ok', detail: user.role });
    return { ok: true, step: 'done', user: publicUser(this.accounts.byId(user.id)) };
  }

  _beginEnroll(sid, user) {
    const secret = user.totp.pending ? this.vault.open(user.totp.pending) : generateSecret();
    if (!user.totp.pending) this.accounts.patch(user.id, (u) => { u.totp.pending = this.vault.seal(secret); });
    this.challenges.set(sid, { userId: user.id, kind: 'enroll', expires: this.now() + TIMES.challenge, tries: 0 });
    return { ok: true, step: 'enroll', secret, uri: otpauthUri({ secret, account: user.username }) };
  }

  _newRecoveryCodes(userId) {
    const codes = Array.from({ length: 8 }, () => {
      const c = crypto.randomBytes(8).toString('hex').toUpperCase().slice(0, 10);
      return `${c.slice(0, 5)}-${c.slice(5)}`;
    });
    this.accounts.patch(userId, (u) => { u.recovery = codes.map((c) => sha(normCode(c))); });
    return codes;
  }

  _finishEnroll(user, code) {
    if (!user.totp.pending) return null;
    const secret = this.vault.open(user.totp.pending);
    const counter = verifyTotp(secret, code, { now: this.now(), lastCounter: -1 });
    if (counter === null) return null;
    this.accounts.patch(user.id, (u) => { u.totp = { enabled: true, secret: this.vault.seal(secret), pending: null, lastCounter: counter }; u.status = 'active'; });
    return this._newRecoveryCodes(user.id);
  }

  // ---------- Einrichtung, Registrierung, Anmeldung ----------
  async setupOwner(sid, { username, email, password }) {
    if (this.accounts.state === 'tampered') return fail(new ZxError('TAMPERED').message, 'TAMPERED');
    if (this.accounts.hasOwner()) return fail('Zayriox ist bereits eingerichtet.', 'FORBIDDEN');
    const err = validateUsername(username) || validateEmail(email) || validatePassword(password, username);
    if (err) return fail(err, 'INVALID');
    const pw = await hashPassword(password, this.scryptN);
    if (this.accounts.hasOwner()) return fail('Zayriox ist bereits eingerichtet.', 'FORBIDDEN'); // Rennen ausschließen
    const user = this.accounts.add({
      id: crypto.randomBytes(12).toString('hex'), username: String(username).trim(), usernameLower: String(username).trim().toLowerCase(),
      email: String(email).trim(), role: 'owner', status: 'setup', pw, createdAt: new Date(this.now()).toISOString(),
      totp: { enabled: false, secret: null, pending: null, lastCounter: -1 }, recovery: []
    });
    this.audit.append({ actor: user.id, action: 'owner.created' });
    return this._beginEnroll(sid, user);
  }

  async register(sid, { username, email, password }) {
    if (this.accounts.state === 'tampered') return fail(new ZxError('TAMPERED').message, 'TAMPERED');
    if (!this.accounts.hasOwner()) return fail('Zayriox ist noch nicht eingerichtet.', 'FORBIDDEN');
    if (!this.policy.get().features.registration) return fail('Die Registrierung ist deaktiviert.', 'FEATURE_OFF');
    this.regs = this.regs.filter((t) => this.now() - t < 10 * MIN);
    if (this.regs.length >= 5) return fail('Zu viele Registrierungen in kurzer Zeit. Bitte warte einen Moment.', 'LOCKED');
    const err = validateUsername(username) || validateEmail(email) || validatePassword(password, username);
    if (err) return fail(err, 'INVALID');
    this.regs.push(this.now());
    const pw = await hashPassword(password, this.scryptN);
    if (this.accounts.byName(username) || this.accounts.emailTaken(email)) return fail('Benutzername oder E-Mail ist bereits vergeben.', 'TAKEN');
    const user = this.accounts.add({
      id: crypto.randomBytes(12).toString('hex'), username: String(username).trim(), usernameLower: String(username).trim().toLowerCase(),
      email: String(email).trim(), role: 'user', status: 'active', pw, createdAt: new Date(this.now()).toISOString(),
      totp: { enabled: false, secret: null, pending: null, lastCounter: -1 }, recovery: []
    });
    this.audit.append({ actor: user.id, action: 'user.registered' });
    return this._start(sid, user);
  }

  async login(sid, { username, password }) {
    if (this.accounts.state === 'tampered') return fail(new ZxError('TAMPERED').message, 'TAMPERED');
    const name = String(username || '').trim().slice(0, 40);
    const key = name.toLowerCase();
    const locked = this._locked(key);
    if (locked) {
      this.audit.append({ actor: name || '?', action: 'login.locked', ok: false });
      return fail(`Zu viele Fehlversuche. Bitte warte ${wait(locked)}.`, 'LOCKED');
    }
    const pw = String(password || '');
    const user = pw.length <= 256 ? this.accounts.byName(name) : null;
    const good = await this._verify(user, pw.slice(0, 256));
    if (!user || !good) {
      this._fail(key);
      this.audit.append({ actor: user ? user.id : name || '?', action: 'login.fail', ok: false });
      return fail(GENERIC);
    }
    if (user.status === 'blocked') {
      this.audit.append({ actor: user.id, action: 'login.blocked', ok: false });
      return fail('Dein Konto wurde gesperrt. Wende dich an den Owner.', 'BLOCKED');
    }
    if (user.totp.enabled) {
      this.challenges.set(sid, { userId: user.id, kind: '2fa', expires: this.now() + TIMES.challenge, tries: 0 });
      return { ok: true, step: '2fa' };
    }
    if (user.role === 'owner') return this._beginEnroll(sid, user); // Owner braucht zwingend 2FA
    this._ok(key);
    return this._start(sid, user);
  }

  _ok(key) { this.fails.delete(key); }

  _challenge(sid, kind) {
    const ch = this.challenges.get(sid);
    if (!ch || ch.kind !== kind || ch.expires < this.now()) { this.challenges.delete(sid); return null; }
    return ch;
  }

  async verify2fa(sid, { code }) {
    const ch = this._challenge(sid, '2fa');
    if (!ch) return fail('Die Anmeldung ist abgelaufen. Bitte melde dich erneut an.', 'EXPIRED');
    const user = this.accounts.byId(ch.userId);
    if (!user || user.status === 'blocked') { this.challenges.delete(sid); return fail('Die Anmeldung ist abgelaufen. Bitte melde dich erneut an.', 'EXPIRED'); }
    const key = user.usernameLower;
    const locked = this._locked(key);
    if (locked) return fail(`Zu viele Fehlversuche. Bitte warte ${wait(locked)}.`, 'LOCKED');
    if (++ch.tries > 5) { this.challenges.delete(sid); return fail('Zu viele falsche Codes. Bitte melde dich erneut an.', 'EXPIRED'); }

    const counter = verifyTotp(this.vault.open(user.totp.secret), code, { now: this.now(), lastCounter: user.totp.lastCounter });
    let ok = false;
    if (counter !== null) {
      this.accounts.patch(user.id, (u) => { u.totp.lastCounter = counter; });
      ok = true;
    } else {
      const h = sha(normCode(code));
      if (user.recovery.includes(h)) {
        this.accounts.patch(user.id, (u) => { u.recovery = u.recovery.filter((x) => x !== h); });
        this.audit.append({ actor: user.id, action: 'recovery.used', detail: `${user.recovery.length - 1} übrig` });
        ok = true;
      }
    }
    if (!ok) {
      this._fail(key);
      this.audit.append({ actor: user.id, action: 'login.2fa.fail', ok: false });
      return fail('Der Code ist falsch.', 'BAD_CODE');
    }
    this._ok(key);
    return this._start(sid, this.accounts.byId(user.id));
  }

  async confirmEnroll(sid, { code }) {
    const ch = this._challenge(sid, 'enroll');
    if (!ch) return fail('Die Einrichtung ist abgelaufen. Bitte melde dich erneut an.', 'EXPIRED');
    if (++ch.tries > 8) { this.challenges.delete(sid); return fail('Zu viele falsche Codes. Bitte melde dich erneut an.', 'EXPIRED'); }
    const user = this.accounts.byId(ch.userId);
    if (!user) return fail('Die Einrichtung ist abgelaufen. Bitte melde dich erneut an.', 'EXPIRED');
    const codes = this._finishEnroll(user, code);
    if (!codes) return fail('Der Code ist falsch. Prüfe die Uhrzeit deines Geräts und versuche es erneut.', 'BAD_CODE');
    this.audit.append({ actor: user.id, action: '2fa.enabled' });
    const started = this._start(sid, this.accounts.byId(user.id));
    return { ...started, recoveryCodes: codes };
  }

  // ---------- Konto ----------
  async changePassword(sid, { current, next }) {
    const { user } = this.requireUser(sid);
    if (!(await this._verify(user, String(current || '').slice(0, 256)))) {
      this.audit.append({ actor: user.id, action: 'password.change', ok: false, detail: 'falsches Passwort' });
      return fail('Das aktuelle Passwort ist falsch.', 'AUTH');
    }
    const err = validatePassword(next, user.username);
    if (err) return fail(err, 'INVALID');
    if (next === current) return fail('Das neue Passwort muss anders sein.', 'INVALID');
    const pw = await hashPassword(next, this.scryptN);
    this.accounts.patch(user.id, (u) => { u.pw = pw; });
    this.endSessionsOf(user.id, sid, 'password-changed');
    this.audit.append({ actor: user.id, action: 'password.changed' });
    return { ok: true };
  }

  async totpBegin(sid, { password }) {
    const { user } = this.requireUser(sid);
    if (user.totp.enabled) return fail('2FA ist bereits aktiv.', 'INVALID');
    if (!(await this._verify(user, String(password || '').slice(0, 256)))) return fail('Das Passwort ist falsch.', 'AUTH');
    const secret = generateSecret();
    this.accounts.patch(user.id, (u) => { u.totp.pending = this.vault.seal(secret); });
    return { ok: true, secret, uri: otpauthUri({ secret, account: user.username }) };
  }

  totpConfirm(sid, { code }) {
    const { user } = this.requireUser(sid);
    const codes = this._finishEnroll(user, code);
    if (!codes) return fail('Der Code ist falsch.', 'BAD_CODE');
    this.audit.append({ actor: user.id, action: '2fa.enabled' });
    return { ok: true, recoveryCodes: codes };
  }

  async totpDisable(sid, { password, code }) {
    const { user } = this.requireUser(sid);
    if (user.role === 'owner') return fail('Für den Owner ist 2FA Pflicht und kann nicht deaktiviert werden.', 'FORBIDDEN');
    if (!(await this._verify(user, String(password || '').slice(0, 256)))) return fail('Das Passwort ist falsch.', 'AUTH');
    const counter = user.totp.enabled ? verifyTotp(this.vault.open(user.totp.secret), code, { now: this.now(), lastCounter: user.totp.lastCounter }) : null;
    if (counter === null) return fail('Der Code ist falsch.', 'BAD_CODE');
    this.accounts.patch(user.id, (u) => { u.totp = { enabled: false, secret: null, pending: null, lastCounter: -1 }; u.recovery = []; });
    this.audit.append({ actor: user.id, action: '2fa.disabled' });
    return { ok: true };
  }

  async deleteOwnAccount(sid, { password }) {
    const { user } = this.requireUser(sid);
    if (user.role === 'owner') return fail('Das Owner-Konto kann nicht gelöscht werden.', 'FORBIDDEN');
    if (!(await this._verify(user, String(password || '').slice(0, 256)))) return fail('Das Passwort ist falsch.', 'AUTH');
    this.endSessionsOf(user.id, null, 'account-deleted');
    this.accounts.remove(user.id);
    this.onUserRemoved(user.id);
    this.audit.append({ actor: user.id, action: 'account.deleted' });
    return { ok: true };
  }

  // ---------- Owner: erneute Bestätigung für kritische Aktionen ----------
  async stepUp(sid, { password, code }) {
    const { user, session } = this.requireOwner(sid);
    const key = user.usernameLower;
    const locked = this._locked(key);
    if (locked) return fail(`Zu viele Fehlversuche. Bitte warte ${wait(locked)}.`, 'LOCKED');
    const okPw = await this._verify(user, String(password || '').slice(0, 256));
    const counter = okPw ? verifyTotp(this.vault.open(user.totp.secret), code, { now: this.now(), lastCounter: user.totp.lastCounter }) : null;
    if (!okPw || counter === null) {
      this._fail(key);
      this.audit.append({ actor: user.id, action: 'stepup.fail', ok: false });
      return fail('Passwort oder Code falsch. Jeder 2FA-Code gilt nur einmal – warte ggf. auf den nächsten.', 'AUTH');
    }
    this.accounts.patch(user.id, (u) => { u.totp.lastCounter = counter; });
    session.stepUpAt = this.now();
    this._ok(key);
    this.audit.append({ actor: user.id, action: 'stepup.ok' });
    return { ok: true, validMinutes: TIMES.stepUp / MIN };
  }
}
