// Owner-Funktionen. JEDE Methode prüft die Rolle serverseitig (Hauptprozess) neu.
// Verändernde Aktionen verlangen zusätzlich eine frische Bestätigung (Passwort + 2FA-Code, "Step-up").
import { publicUser } from './accounts.js';
import { ZxError } from './errors.js';

export class AdminService {
  constructor({ auth, accounts, audit, policy, vault, engine, onUserRemoved = () => {} }) {
    Object.assign(this, { auth, accounts, audit, policy, vault, engine, onUserRemoved });
  }

  stepUp(sid, body) { return this.auth.stepUp(sid, body); }

  listUsers(sid) {
    this.auth.requireOwner(sid);
    return { ok: true, users: this.accounts.all().map((u) => ({ ...publicUser(u), usage: this.policy.usageOf(u.id) })) };
  }

  _target(sid, id) {
    const { user } = this.auth.requireOwner(sid, { stepUp: true });
    const t = this.accounts.byId(String(id));
    if (!t) throw new ZxError('INVALID');
    if (t.role === 'owner' || t.id === user.id) { this.audit.append({ actor: user.id, action: 'admin.denied', target: t.id, ok: false, detail: 'owner-geschützt' }); throw new ZxError('FORBIDDEN', 'Das Owner-Konto ist geschützt und kann so nicht verändert werden.'); }
    return { owner: user, target: t };
  }

  setStatus(sid, { id, status }) {
    this.auth.requireOwner(sid, { stepUp: true }); // erst Berechtigung prüfen, dann Eingabe validieren
    if (status !== 'active' && status !== 'blocked') throw new ZxError('INVALID');
    const { owner, target } = this._target(sid, id);
    this.accounts.patch(target.id, (u) => { u.status = status; });
    if (status === 'blocked') this.auth.endSessionsOf(target.id, null, 'blocked');
    this.audit.append({ actor: owner.id, action: status === 'blocked' ? 'admin.block' : 'admin.unblock', target: target.id });
    return { ok: true };
  }

  deleteUser(sid, { id }) {
    const { owner, target } = this._target(sid, id);
    this.auth.endSessionsOf(target.id, null, 'deleted');
    this.accounts.remove(target.id);
    this.policy.removeUser(target.id);
    this.onUserRemoved(target.id);
    this.audit.append({ actor: owner.id, action: 'admin.delete', target: target.id });
    return { ok: true };
  }

  getPolicy(sid) {
    this.auth.requireOwner(sid);
    return { ok: true, policy: this.policy.get() };
  }

  setPolicy(sid, patch) {
    const { user } = this.auth.requireOwner(sid, { stepUp: true });
    if (!patch || typeof patch !== 'object') throw new ZxError('INVALID');
    const { secrets, ...safe } = patch; // Geheimnisse nie über diesen Weg
    const before = JSON.stringify(this.policy.get());
    const next = this.policy.set(safe);
    const changed = Object.keys(safe).filter((k) => JSON.stringify(safe[k]) !== JSON.stringify(JSON.parse(before)[k]));
    this.audit.append({ actor: user.id, action: 'admin.policy', detail: changed.join(',') });
    return { ok: true, policy: next };
  }

  setSearchKey(sid, { key }) {
    const { user } = this.auth.requireOwner(sid, { stepUp: true });
    const k = String(key || '').trim();
    if (k.length > 200) throw new ZxError('INVALID');
    this.policy.setSecret('braveKey', k ? this.vault.seal(k) : null); // verschlüsselt; die Oberfläche bekommt ihn nie zurück
    this.audit.append({ actor: user.id, action: 'admin.searchkey', detail: k ? 'gesetzt' : 'entfernt' });
    return { ok: true, policy: this.policy.get() };
  }

  audit_(sid) {
    this.auth.requireOwner(sid);
    return { ok: true, entries: this.audit.tail(200), integrity: this.audit.verify() };
  }
}
