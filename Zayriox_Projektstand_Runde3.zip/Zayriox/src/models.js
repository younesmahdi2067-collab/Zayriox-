// Modell-Katalog. Das "Gehirn" von Zayriox ist hier austauschbar:
// neuen Eintrag hinzufügen (beliebige GGUF-Datei) – der Rest der App bleibt gleich.
export const MODELS = [
  {
    id: 'mini',
    name: 'Zayriox Mini',
    base: 'Qwen2.5 0.5B Instruct (Q4_K_M, Apache-2.0)',
    file: 'qwen2.5-0.5b-instruct-q4_k_m.gguf',
    url: 'https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf',
    sizeMB: 400,
    ram: 'ca. 1 GB RAM',
    note: 'Sehr klein und schnell. Für einfache Fragen okay, bei schwierigen Aufgaben schwach.'
  },
  {
    id: 'standard',
    name: 'Zayriox Standard',
    base: 'Qwen2.5 1.5B Instruct (Q4_K_M, Apache-2.0)',
    file: 'qwen2.5-1.5b-instruct-q4_k_m.gguf',
    url: 'https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf',
    sizeMB: 990,
    ram: 'ca. 2 GB RAM',
    note: 'Deutlich klüger, besseres Deutsch, etwas langsamer.'
  }
];

export const DEFAULT_MODEL_ID = 'mini';
export const getModel = (id) => MODELS.find((m) => m.id === id) || null;
