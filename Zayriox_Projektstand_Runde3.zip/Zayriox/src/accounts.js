import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';
import { renameRetry } from './fsutil.js';

const scrypt = promisify(crypto.scrypt);

// ---------- Passwörter: scrypt mit Salt, nie Klartext ----------
export async function hashPassword(password, N = 32768) {
  const salt = crypto.randomBytes(16);
  const r = 8, p = 1;
  const key = await scrypt(password.normalize('NFKC'), salt, 64, { N, r, p, maxmem: 256 * N * r });
  return `scrypt$${N}$${r}$${p}$${salt.toString('base64')}$${key.toString('base64')}`;
}

export async function verifyPassword(password, stored) {
  try {
    const [alg, N, r, p, salt, hash] = String(stored).split('$');
    if (alg !== 'scrypt') return false;
    const expected = Buffer.from(hash, 'base64');
    const n = Number(N), rr = Number(r), pp = Number(p);
    if (n > 1 << 17 || rr > 16 || pp > 4) return false;
    const key = await scrypt(String(password).normalize('NFKC'), Buffer.from(salt, 'base64'), expected.length, { N: n, r: rr, p: pp, maxmem: 256 * n * rr });
    return crypto.timingSafeEqual(key, expected);
  } catch { return false; }
}

// ---------- Validierung ----------
const COMMON = new Set(['passwort123', 'password123', '1234567890', 'qwertzuiop', 'qwertyuiop', 'zayriox123', 'password1234', 'passwort1234', 'iloveyou123']);

export function validateUsername(name) {
  const n = String(name || '').trim();
  if (!/^[A-Za-z0-9_.-]{3,24}$/.test(n)) return 'Der Benutzername muss 3–24 Zeichen lang sein (Buchstaben, Zahlen, _ . -).';
  return null;
}
export function validateEmail(email) {
  const e = String(email || '').trim();
  if (e.length > 120 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e)) return 'Bitte gib eine gültige E-Mail-Adresse an.';
  return null;
}
export function validatePassword(pw, username = '') {
  const p = String(pw || '');
  if (p.length < 10) return 'Das Passwort muss mindestens 10 Zeichen lang sein.';
  if (p.length > 128) return 'Das Passwort ist zu lang (maximal 128 Zeichen).';
  if (!/[A-Za-z]/.test(p) || !/\d/.test(p)) return 'Das Passwort braucht mindestens einen Buchstaben und eine Zahl.';
  if (/^(.)\1+$/.test(p) || COMMON.has(p.toLowerCase())) return 'Dieses Passwort ist zu leicht zu erraten.';
  if (username && p.toLowerCase().includes(String(username).toLowerCase())) return 'Das Passwort darf den Benutzernamen nicht enthalten.';
  return null;
}

// ---------- Kontodatei, signiert gegen Manipulation ----------
export const publicUser = (u) => u && ({
  id: u.id, username: u.username, email: u.email, role: u.role, status: u.status,
  totpEnabled: !!(u.totp && u.totp.enabled), createdAt: u.createdAt, lastLogin: u.lastLogin || null
});

export class AccountStore {
  constructor({ dir, vault }) {
    this.file = path.join(dir, 'accounts.json');
    this.vault = vault;
    this.users = [];
    this.state = 'empty'; // empty | ok | tampered
    fs.mkdirSync(dir, { recursive: true });
    this.load();
  }

  _mac(users) { return crypto.createHmac('sha256', this.vault.macKey()).update(JSON.stringify(users)).digest('hex'); }

  load() {
    let raw;
    try { raw = fs.readFileSync(this.file, 'utf8'); } catch (e) {
      if (e.code === 'ENOENT') { this.users = []; this.state = 'empty'; return; }
      this.state = 'tampered'; return;
    }
    try {
      const data = JSON.parse(raw);
      const good = Buffer.from(this._mac(data.users));
      const given = Buffer.from(String(data.mac || ''));
      if (!Array.isArray(data.users) || good.length !== given.length || !crypto.timingSafeEqual(good, given)) throw new Error('mac');
      this.users = data.users;
      this.state = 'ok';
    } catch { this.users = []; this.state = 'tampered'; }
  }

  save() {
    if (this.state === 'tampered') throw new Error('Kontodatei gesperrt');
    const tmp = `${this.file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify({ v: 1, users: this.users, mac: this._mac(this.users) }));
    renameRetry(tmp, this.file);
    this.state = 'ok';
  }

  all() { return this.users.slice(); }
  byId(id) { return this.users.find((u) => u.id === id) || null; }
  byName(name) { const n = String(name || '').trim().toLowerCase(); return this.users.find((u) => u.usernameLower === n) || null; }
  emailTaken(email) { const e = String(email).trim().toLowerCase(); return this.users.some((u) => u.email.toLowerCase() === e); }
  hasOwner() { return this.users.some((u) => u.role === 'owner'); }

  add(user) { this.users.push(user); this.save(); return user; }
  patch(id, fn) { const u = this.byId(id); if (!u) return null; fn(u); this.save(); return u; }
  remove(id) { this.users = this.users.filter((u) => u.id !== id); this.save(); }
}
