import fs from 'node:fs';
import path from 'node:path';
import https from 'node:https';
import { renameRetry } from './fsutil.js';
import { MODELS, getModel } from './models.js';
import { ZxError } from './errors.js';

const CONTEXT_SIZE = 4096;

function downloadFile(url, dest, onProgress, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 6) return reject(new Error('Zu viele Weiterleitungen'));
    const req = https.get(url, { headers: { 'User-Agent': 'Zayriox/0.1' } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
        res.resume();
        const next = new URL(res.headers.location, url).toString();
        downloadFile(next, dest, onProgress, redirects + 1).then(resolve, reject);
        return;
      }
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error(`HTTP ${res.statusCode}`));
      }
      const total = Number(res.headers['content-length'] || 0);
      let got = 0;
      const out = fs.createWriteStream(dest);
      res.on('data', (chunk) => { got += chunk.length; onProgress(got, total); });
      res.on('error', reject);
      out.on('error', reject);
      out.on('finish', () => out.close(() => resolve({ got, total })));
      res.pipe(out);
    });
    req.on('error', reject);
    req.setTimeout(30000, () => req.destroy(new Error('Zeitüberschreitung')));
  });
}

const toItem = (m) =>
  m.role === 'user' ? { type: 'user', text: m.content } : { type: 'model', response: [m.content] };

export class Engine {
  constructor({ modelsDir, onStatus, log = () => {} }) {
    this.modelsDir = modelsDir;
    this.onStatus = onStatus;
    this.log = log;
    fs.mkdirSync(modelsDir, { recursive: true });
    this.llama = null;
    this.model = null;
    this.context = null;
    this.busy = false;
    this.status = { state: 'no-model', modelId: null, installed: [], downloading: false, progress: 0, message: '' };
    this.refreshInstalled();
  }

  modelPath(id) {
    const m = getModel(id);
    return m ? path.join(this.modelsDir, m.file) : null;
  }

  isInstalled(id) {
    const p = this.modelPath(id);
    return !!p && fs.existsSync(p);
  }

  refreshInstalled() {
    this.status.installed = MODELS.filter((m) => this.isInstalled(m.id)).map((m) => m.id);
  }

  setStatus(patch) {
    this.status = { ...this.status, ...patch };
    this.refreshInstalled();
    try { this.onStatus(this.status); } catch { /* UI evtl. schon geschlossen */ }
  }

  async download(id) {
    const m = getModel(id);
    if (!m) throw new ZxError('INVALID');
    if (this.status.downloading) throw new ZxError('BUSY');
    const dest = this.modelPath(id);
    const part = dest + '.part';
    let last = 0;
    this.setStatus({ downloading: true, downloadingId: id, progress: 0, downloadedMB: 0, totalMB: m.sizeMB, message: '' });
    try {
      const { got, total } = await downloadFile(m.url, part, (g, t) => {
        const now = Date.now();
        if (now - last < 150) return;
        last = now;
        this.setStatus({ progress: t ? g / t : 0, downloadedMB: Math.round(g / 1e6), totalMB: Math.round((t || m.sizeMB * 1e6) / 1e6) });
      });
      if (got < m.sizeMB * 1e6 * 0.8 || (total && got < total)) throw new Error('Download unvollständig');
      renameRetry(part, dest);
      this.setStatus({ downloading: false, downloadingId: null, progress: 1 });
    } catch (err) {
      try { fs.unlinkSync(part); } catch { /* egal */ }
      this.log('Download-Fehler', err);
      this.setStatus({ downloading: false, downloadingId: null, progress: 0, message: new ZxError('DOWNLOAD_FAILED').message });
      throw new ZxError('DOWNLOAD_FAILED');
    }
  }

  async load(id) {
    const p = this.modelPath(id);
    if (!p) throw new ZxError('INVALID');
    if (!this.isInstalled(id)) throw new ZxError('NO_MODEL');
    return this.loadFile(p, id);
  }

  /** Lädt eine beliebige GGUF-Datei (wird auch vom Selbsttest genutzt). */
  async loadFile(p, id = 'custom') {
    await this.unload();
    this.setStatus({ state: 'loading', modelId: id, message: '' });
    try {
      const { getLlama } = await import('node-llama-cpp');
      if (!this.llama) this.llama = await getLlama({ gpu: false });
      this.model = await this.llama.loadModel({ modelPath: p });
      this.context = await this.model.createContext({ contextSize: CONTEXT_SIZE });
      this.setStatus({ state: 'ready', modelId: id, message: '' });
    } catch (err) {
      this.log('Ladefehler', err);
      await this.unload();
      this.setStatus({ state: 'error', modelId: id, message: new ZxError('LOAD_FAILED').message });
      throw new ZxError('LOAD_FAILED');
    }
  }

  async unload() {
    try { if (this.context) await this.context.dispose(); } catch { /* egal */ }
    try { if (this.model) await this.model.dispose(); } catch { /* egal */ }
    this.context = null;
    this.model = null;
  }

  async dispose() {
    await this.unload();
    try { if (this.llama) await this.llama.dispose(); } catch { /* egal */ }
    this.llama = null;
  }

  /** Ein Generierungs-Durchgang. Liefert den kompletten Text (Streaming über onText). */
  async complete({ system, history = [], user, signal, temperature = 0.6, topP = 0.9, maxTokens = 800, onText = () => {} }) {
    if (this.status.state === 'loading') throw new ZxError('NOT_READY');
    if (!this.context) throw new ZxError(this.status.installed.length ? 'NOT_READY' : 'NO_MODEL');
    if (this.busy) throw new ZxError('BUSY');
    this.busy = true;
    let session;
    try {
      const { LlamaChatSession } = await import('node-llama-cpp');
      session = new LlamaChatSession({ contextSequence: this.context.getSequence() });
      session.setChatHistory([{ type: 'system', text: system }, ...history.map(toItem)]);
      return await session.prompt(user, {
        temperature, topP, maxTokens, signal,
        stopOnAbortSignal: true,
        onTextChunk: onText
      });
    } catch (err) {
      if (signal && signal.aborted) return '';
      this.log('Generierungsfehler', err);
      throw err;
    } finally {
      try { if (session) session.dispose(); } catch { /* egal */ }
      this.busy = false;
    }
  }
}
