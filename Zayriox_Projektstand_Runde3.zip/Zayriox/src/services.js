// Verdrahtet alle Dienste. Wird von der App UND von den Tests/dem Selbsttest genutzt (ohne Electron-Abhängigkeit).
import fs from 'node:fs';
import path from 'node:path';
import { Store } from './store.js';
import { Vault } from './vault.js';
import { AuditLog } from './audit.js';
import { AccountStore } from './accounts.js';
import { Policy } from './policy.js';
import { AuthService } from './auth.js';
import { AdminService } from './admin.js';

const ID = /^[a-f0-9]{24}$/;

export function createServices({ dir, cipher, engine, ml = null, log = () => {}, scryptN = 32768, now = Date.now, onSessionEnd = () => {} }) {
  fs.mkdirSync(dir, { recursive: true });
  const store = new Store(dir);
  const vault = new Vault(dir, cipher);
  const audit = new AuditLog(path.join(dir, 'audit.log'));
  const accounts = new AccountStore({ dir, vault });
  const policy = new Policy(store, () => new Date(now()));

  const userStore = (id) => {
    if (!ID.test(String(id))) throw new Error('ungültige Nutzer-ID');
    return new Store(path.join(dir, 'users', id));
  };
  const removeUserData = (id) => { if (ID.test(String(id))) fs.rmSync(path.join(dir, 'users', id), { recursive: true, force: true }); };

  const auth = new AuthService({ accounts, audit, vault, policy, now, scryptN, onSessionEnd, onUserRemoved: (id) => { removeUserData(id); policy.removeUser(id); } });
  const admin = new AdminService({ auth, accounts, audit, policy, vault, engine, onUserRemoved: removeUserData });
  return { dir, store, vault, audit, accounts, policy, auth, admin, engine, ml, userStore, removeUserData, log };
}
