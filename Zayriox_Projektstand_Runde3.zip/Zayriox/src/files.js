import path from 'node:path';
import { ZxError } from './errors.js';

export const MAX_FILE_BYTES = 5 * 1024 * 1024;
export const MAX_STORED_CHARS = 20000;

const TEXT_EXT = new Set([
  'txt', 'md', 'markdown', 'csv', 'tsv', 'json', 'xml', 'html', 'htm', 'css', 'scss', 'js', 'mjs', 'cjs', 'ts', 'tsx', 'jsx',
  'py', 'java', 'kt', 'c', 'h', 'cpp', 'hpp', 'cs', 'go', 'rs', 'rb', 'php', 'swift', 'sh', 'bat', 'ps1', 'sql',
  'yml', 'yaml', 'toml', 'ini', 'cfg', 'conf', 'log', 'tex', 'vue', 'svelte', 'lua', 'r', 'dart'
]);
const IMAGE_EXT = new Set(['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'svg', 'ico', 'heic']);

export async function extractText(name, data) {
  const ext = path.extname(String(name)).toLowerCase().slice(1);
  if (IMAGE_EXT.has(ext)) throw new ZxError('IMAGE_UNSUPPORTED');
  const buf = Buffer.from(data);
  if (buf.length > MAX_FILE_BYTES) throw new ZxError('FILE_TOO_BIG');

  let text;
  if (ext === 'pdf') {
    try {
      const mod = await import('pdf-parse/lib/pdf-parse.js');
      const parse = mod.default || mod;
      text = (await parse(buf)).text || '';
    } catch {
      throw new ZxError('FILE_UNSUPPORTED');
    }
  } else if (TEXT_EXT.has(ext) || ext === '') {
    if (buf.subarray(0, 4000).includes(0)) throw new ZxError('FILE_UNSUPPORTED');
    text = buf.toString('utf8');
  } else {
    throw new ZxError('FILE_UNSUPPORTED');
  }

  text = text.replace(/\r\n/g, '\n').trim();
  if (!text) throw new ZxError('FILE_EMPTY');
  return { text: text.slice(0, MAX_STORED_CHARS), chars: text.length };
}
