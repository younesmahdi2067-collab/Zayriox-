// Websuche. Läuft ausschließlich im Hauptprozess; API-Schlüssel (Brave) sind verschlüsselt gespeichert und erreichen nie die Oberfläche.
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Zayriox/0.2';

const strip = (s) => String(s)
  .replace(/<[^>]+>/g, '')
  .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#x27;|&#39;/g, "'").replace(/&nbsp;/g, ' ')
  .replace(/\s+/g, ' ').trim();

function realUrl(href) {
  try {
    const u = new URL(href.startsWith('//') ? `https:${href}` : href, 'https://duckduckgo.com');
    if (u.hostname.endsWith('duckduckgo.com')) {
      if (u.pathname !== '/l/' || !u.searchParams.get('uddg')) return null; // Werbung/Intern überspringen
      return realUrl(u.searchParams.get('uddg'));
    }
    return u.protocol === 'https:' || u.protocol === 'http:' ? u.toString() : null;
  } catch { return null; }
}

export function parseDuckDuckGo(html, max = 5) {
  const items = [];
  const re = /<a\b([^>]*)>([\s\S]*?)<\/a>/g;
  let m;
  while ((m = re.exec(html))) {
    if (/class="[^"]*\bresult__a\b/.test(m[1])) {
      const href = (/href="([^"]*)"/.exec(m[1]) || [])[1];
      items.push({ kind: 'title', href: href ? href.replace(/&amp;/g, '&') : '', text: m[2] });
    } else if (/class="[^"]*\bresult__snippet\b/.test(m[1])) items.push({ kind: 'snip', text: m[2] });
  }
  const out = [];
  for (let i = 0; i < items.length && out.length < max; i++) {
    if (items[i].kind !== 'title') continue;
    const url = realUrl(items[i].href);
    if (!url) continue;
    const snip = items[i + 1] && items[i + 1].kind === 'snip' ? items[i + 1].text : '';
    out.push({ title: strip(items[i].text).slice(0, 160), url, snippet: strip(snip).slice(0, 300) });
  }
  return out;
}

/** Zuverlässige, schlüssellose Ausweichquelle (Wikipedia-Suche mit echten Artikel-Links). */
export async function wikipediaSearch(query, { max = 5, fetchImpl = globalThis.fetch, signal, lang = 'de' } = {}) {
  const q = String(query || '').replace(/\s+/g, ' ').trim().slice(0, 200);
  if (!q) return [];
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  if (signal) signal.addEventListener('abort', () => ctrl.abort(), { once: true });
  try {
    const r = await fetchImpl(`https://${lang}.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&srlimit=${max}&format=json&utf8=1`, {
      headers: { 'User-Agent': UA, Accept: 'application/json' }, signal: ctrl.signal
    });
    if (!r.ok) throw new Error(`Wikipedia HTTP ${r.status}`);
    const j = await r.json();
    return ((j.query && j.query.search) || []).slice(0, max).map((x) => ({
      title: strip(x.title).slice(0, 160),
      url: `https://${lang}.wikipedia.org/wiki/${encodeURIComponent(String(x.title).replace(/ /g, '_'))}`,
      snippet: strip(x.snippet || '').slice(0, 300)
    }));
  } finally { clearTimeout(timer); }
}

export async function primarySearch(query, { provider = 'duckduckgo', braveKey = null, max = 5, fetchImpl = globalThis.fetch, signal } = {}) {
  const q = String(query || '').replace(/\s+/g, ' ').trim().slice(0, 200);
  if (!q) return [];
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  if (signal) signal.addEventListener('abort', () => ctrl.abort(), { once: true });
  try {
    if (provider === 'brave' && braveKey) {
      const r = await fetchImpl(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(q)}&count=${max}`, {
        headers: { Accept: 'application/json', 'X-Subscription-Token': braveKey }, signal: ctrl.signal
      });
      if (!r.ok) throw new Error(`Brave HTTP ${r.status}`);
      const j = await r.json();
      return ((j.web && j.web.results) || []).slice(0, max).filter((x) => /^https?:\/\//.test(x.url))
        .map((x) => ({ title: strip(x.title).slice(0, 160), url: x.url, snippet: strip(x.description || '').slice(0, 300) }));
    }
    const r = await fetchImpl(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}`, {
      headers: { 'User-Agent': UA, 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.5' }, signal: ctrl.signal
    });
    if (!r.ok) throw new Error(`DDG HTTP ${r.status}`);
    return parseDuckDuckGo(await r.text(), max);
  } finally { clearTimeout(timer); }
}

export function sourcesPrompt(results) {
  if (!results.length) return '';
  return 'Aktuelle Websuchergebnisse. Nutze sie für aktuelle Fakten und verweise mit [1], [2] … auf die Quellen. ' +
    'Wenn sie nicht weiterhelfen, sage das ehrlich:\n' +
    results.map((r, i) => `[${i + 1}] ${r.title} – ${r.snippet} (${r.url})`).join('\n');
}

/** Suche mit Ausweichkette: gewählter Anbieter, bei Fehler oder 0 Treffern automatisch Wikipedia. */
export async function webSearchWithFallback(query, opts = {}) {
  let results = [];
  try { results = await primarySearch(query, opts); } catch { /* Ausweichquelle probieren */ }
  if (results.length) return results;
  return wikipediaSearch(query, opts); // wirft bei Netzfehler -> Chat meldet verständlich "Websuche nicht erreichbar"
}

export const webSearch = primarySearch;
