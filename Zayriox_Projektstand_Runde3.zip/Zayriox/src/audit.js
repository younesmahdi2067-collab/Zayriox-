// Manipulationssicheres Audit-Log: jede Zeile enthält den Hash der vorigen (Hash-Kette).
// Es werden nie Passwörter, Codes oder Chat-Inhalte protokolliert.
import crypto from 'node:crypto';
import fs from 'node:fs';

const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const body = (r) => JSON.stringify([r.ts, r.actor, r.action, r.target, r.ok, r.detail]);

export class AuditLog {
  constructor(file, now = () => new Date()) {
    this.file = file;
    this.now = now;
    this.last = 'GENESIS';
    try {
      const lines = fs.readFileSync(file, 'utf8').trim().split('\n').filter(Boolean);
      if (lines.length) this.last = JSON.parse(lines[lines.length - 1]).hash;
    } catch { /* neue Datei */ }
  }

  append({ actor = 'system', action, target = null, ok = true, detail = '' }) {
    try {
      const rec = { ts: this.now().toISOString(), actor: String(actor).slice(0, 60), action: String(action).slice(0, 60),
        target: target ? String(target).slice(0, 60) : null, ok: !!ok, detail: String(detail).slice(0, 200) };
      rec.prev = this.last;
      rec.hash = sha(rec.prev + body(rec));
      fs.appendFileSync(this.file, JSON.stringify(rec) + '\n');
      this.last = rec.hash;
      return true;
    } catch { return false; }
  }

  read() {
    try { return fs.readFileSync(this.file, 'utf8').trim().split('\n').filter(Boolean).map((l) => JSON.parse(l)); }
    catch { return []; }
  }

  tail(n = 200) { return this.read().slice(-n).reverse(); }

  verify() {
    let prev = 'GENESIS';
    const recs = this.read();
    for (let i = 0; i < recs.length; i++) {
      const r = recs[i];
      if (r.prev !== prev || r.hash !== sha(prev + body(r))) return { ok: false, count: recs.length, brokenAt: i + 1 };
      prev = r.hash;
    }
    return { ok: true, count: recs.length, brokenAt: null };
  }
}
