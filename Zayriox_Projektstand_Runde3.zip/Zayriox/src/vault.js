// Tresor für Geheimnisse (2FA-Schlüssel, API-Schlüssel, Integritätsschlüssel).
// Unter Windows schützt Electron safeStorage die Daten mit dem Windows-Benutzerkonto (DPAPI).
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

export function osCipher(safeStorage) {
  return { name: 'os', encrypt: (s) => safeStorage.encryptString(s), decrypt: (b) => safeStorage.decryptString(b) };
}

/** Notlösung, falls das Betriebssystem keinen Schlüsselbund bietet (schwächer: Schlüssel liegt als Datei daneben). */
export function fileCipher(dir) {
  fs.mkdirSync(dir, { recursive: true });
  const f = path.join(dir, 'fallback.key');
  let key;
  try { key = fs.readFileSync(f); } catch { key = crypto.randomBytes(32); fs.writeFileSync(f, key, { mode: 0o600 }); }
  return {
    name: 'file',
    encrypt(s) {
      const iv = crypto.randomBytes(12);
      const c = crypto.createCipheriv('aes-256-gcm', key, iv);
      const enc = Buffer.concat([c.update(s, 'utf8'), c.final()]);
      return Buffer.concat([iv, c.getAuthTag(), enc]);
    },
    decrypt(buf) {
      const d = crypto.createDecipheriv('aes-256-gcm', key, buf.subarray(0, 12));
      d.setAuthTag(buf.subarray(12, 28));
      return Buffer.concat([d.update(buf.subarray(28)), d.final()]).toString('utf8');
    }
  };
}

export class Vault {
  constructor(dir, cipher) {
    this.dir = dir;
    this.cipher = cipher;
    this._mac = null;
    fs.mkdirSync(dir, { recursive: true });
  }
  seal(text) { return this.cipher.encrypt(String(text)).toString('base64'); }
  open(sealed) { return this.cipher.decrypt(Buffer.from(sealed, 'base64')); }
  /** Schlüssel, mit dem die Kontodatei signiert wird (Manipulationsschutz). */
  macKey() {
    if (this._mac) return this._mac;
    const f = path.join(this.dir, 'vault.key');
    let hex;
    try { hex = this.open(fs.readFileSync(f, 'utf8')); }
    catch {
      hex = crypto.randomBytes(32).toString('hex');
      fs.writeFileSync(f, this.seal(hex));
    }
    this._mac = Buffer.from(hex, 'hex');
    return this._mac;
  }
}
