// Bildanalyse und Spracherkennung mit kleinen ONNX-Modellen (transformers.js), lokal im Hauptprozess.
// Die Modelle werden beim ersten Gebrauch einmalig geladen und danach offline genutzt.
import { ZxError } from './errors.js';

let tfPromise = null;
async function tf(cacheDir) {
  if (!tfPromise) {
    tfPromise = import('@huggingface/transformers').then((m) => {
      m.env.cacheDir = cacheDir;
      m.env.allowLocalModels = false;
      return m;
    });
  }
  return tfPromise;
}

const VISION_MODEL = 'HuggingFaceTB/SmolVLM-256M-Instruct';
const SPEECH_MODEL = 'Xenova/whisper-base';

export class MlService {
  constructor({ cacheDir, onStatus = () => {}, log = () => {} }) {
    this.cacheDir = cacheDir;
    this.onStatus = onStatus;
    this.log = log;
    this.vision = null;
    this.asr = null;
  }

  _progress(task, label) {
    let last = 0;
    return (p) => {
      if (p && p.status === 'progress' && Date.now() - last > 300) {
        last = Date.now();
        this.onStatus({ task, message: `${label} ${Math.round(p.progress || 0)} %` });
      }
    };
  }

  async describeImage(buffer) {
    try {
      const t = await tf(this.cacheDir);
      if (!this.vision) {
        this.onStatus({ task: 'vision', message: 'Bildmodell wird geladen (einmalig, ca. 250 MB)…' });
        const processor = await t.AutoProcessor.from_pretrained(VISION_MODEL);
        const model = await t.AutoModelForVision2Seq.from_pretrained(VISION_MODEL, {
          dtype: { embed_tokens: 'fp16', vision_encoder: 'q4', decoder_model_merged: 'q4' },
          device: 'cpu',
          progress_callback: this._progress('vision', 'Bildmodell wird geladen…')
        });
        this.vision = { processor, model };
      }
      const { processor, model } = this.vision;
      const image = await t.RawImage.fromBlob(new Blob([buffer]));
      const messages = [{ role: 'user', content: [{ type: 'image' }, { type: 'text', text: 'Describe this image in detail. Transcribe any visible text exactly.' }] }];
      const prompt = processor.apply_chat_template(messages, { add_generation_prompt: true });
      const inputs = await processor(prompt, [image], { do_image_splitting: false });
      const ids = await model.generate({ ...inputs, max_new_tokens: 300 });
      const out = processor.batch_decode(ids.slice(null, [inputs.input_ids.dims.at(-1), null]), { skip_special_tokens: true });
      const text = String(out[0] || '').trim();
      if (!text) throw new Error('leere Bildbeschreibung');
      return text;
    } catch (err) {
      this.log('Bildanalyse-Fehler', err);
      throw new ZxError('VISION_FAILED');
    }
  }

  async transcribe(float32, { language = 'german' } = {}) {
    try {
      const t = await tf(this.cacheDir);
      if (!this.asr) {
        this.onStatus({ task: 'voice', message: 'Sprachmodell wird geladen (einmalig, ca. 80 MB)…' });
        this.asr = await t.pipeline('automatic-speech-recognition', SPEECH_MODEL, { dtype: 'q8', progress_callback: this._progress('voice', 'Sprachmodell wird geladen…') });
      }
      const out = await this.asr(float32, { language, task: 'transcribe', chunk_length_s: 30 });
      return String(out.text || '').trim();
    } catch (err) {
      this.log('Spracherkennungs-Fehler', err);
      throw new ZxError('VOICE_FAILED');
    }
  }
}
