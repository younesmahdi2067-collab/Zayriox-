// Verständliche Fehlermeldungen – der Nutzer sieht nie "404" oder Stacktraces.
export const MESSAGES = {
  NO_MODEL: 'Zayriox hat noch kein KI-Modell. Lade es zuerst herunter (Einstellungen → KI-Modell).',
  NOT_READY: 'Zayriox ist noch nicht bereit. Das KI-Modell wird gerade geladen.',
  BUSY: 'Zayriox beantwortet gerade noch eine andere Anfrage.',
  RATE_LIMIT: 'Zu viele Anfragen in kurzer Zeit. Bitte warte einen Moment.',
  LOAD_FAILED: 'Das KI-Modell konnte nicht geladen werden. Möglicherweise ist die Datei beschädigt oder es fehlt Arbeitsspeicher.',
  GEN_FAILED: 'Zayriox konnte keine Antwort erzeugen. Bitte versuche es erneut.',
  EMPTY_ANSWER: 'Zayriox hat keine Antwort erzeugt. Formuliere die Frage anders oder wähle einen höheren Modus.',
  DOWNLOAD_FAILED: 'Das Modell konnte nicht heruntergeladen werden. Prüfe deine Internetverbindung und versuche es erneut.',
  FILE_TOO_BIG: 'Diese Datei ist zu groß (maximal 5 MB).',
  FILE_UNSUPPORTED: 'Dieses Dateiformat wird noch nicht unterstützt. Möglich sind Text-, Code- und PDF-Dateien.',
  FILE_EMPTY: 'In dieser Datei wurde kein lesbarer Text gefunden (eingescannte PDF-Seiten werden nicht erkannt).',
  IMAGE_UNSUPPORTED: 'Dieses Bildformat wird nicht unterstützt (möglich: PNG, JPG, WEBP, GIF).',
  INVALID: 'Die Anfrage war ungültig.',
  UNAUTH: 'Bitte melde dich an.',
  FORBIDDEN: 'Dafür fehlt dir die Berechtigung.',
  STEPUP: 'Bitte bestätige diese Aktion mit Passwort und 2FA-Code.',
  MAINTENANCE: 'Zayriox befindet sich gerade im Wartungsmodus.',
  LIMIT: 'Du hast dein Nachrichten-Limit für heute erreicht.',
  FEATURE_OFF: 'Diese Funktion wurde vom Owner deaktiviert.',
  MODE_OFF: 'Diese Denkstufe wurde vom Owner deaktiviert.',
  SEARCH_FAILED: 'Die Websuche ist gerade nicht erreichbar. Zayriox antwortet ohne aktuelle Quellen.',
  VISION_FAILED: 'Das Bild konnte nicht analysiert werden. Prüfe deine Internetverbindung (Bildmodell wird einmalig geladen) und versuche es erneut.',
  VOICE_FAILED: 'Die Spracherkennung ist fehlgeschlagen. Prüfe Mikrofon und Internetverbindung (Sprachmodell wird einmalig geladen).',
  TAMPERED: 'Die Kontodaten wurden verändert oder sind beschädigt. Aus Sicherheitsgründen sind Anmeldungen gesperrt.',
  UNKNOWN: 'Es ist ein unerwarteter Fehler aufgetreten. Bitte versuche es erneut.'
};

export class ZxError extends Error {
  constructor(code, message) {
    super(message || MESSAGES[code] || MESSAGES.UNKNOWN);
    this.code = code;
  }
}

export function friendly(err) {
  if (err instanceof ZxError) return err.message;
  const text = String(err && err.message ? err.message : err);
  if (/memory|alloc|OOM/i.test(text)) {
    return 'Nicht genug Arbeitsspeicher für dieses Modell. Wähle in den Einstellungen das kleinere Modell „Zayriox Mini“.';
  }
  return MESSAGES.GEN_FAILED;
}
