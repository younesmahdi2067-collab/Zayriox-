// Einzige Brücke zwischen Oberfläche und Hauptprozess (contextIsolation aktiv, kein Node in der Oberfläche).
// Die Oberfläche hält KEINE Tokens und KEINE Schlüssel – die Sitzung lebt im Hauptprozess.
const { contextBridge, ipcRenderer } = require('electron');

const call = (channel) => (payload) => ipcRenderer.invoke(channel, payload);
const on = (channel, cb) => {
  const handler = (_e, data) => cb(data);
  ipcRenderer.on(channel, handler);
  return () => ipcRenderer.removeListener(channel, handler);
};

contextBridge.exposeInMainWorld('zayriox', {
  authStatus: call('auth:status'), authSetup: call('auth:setup'), authRegister: call('auth:register'),
  authLogin: call('auth:login'), authVerify2fa: call('auth:verify2fa'), authEnroll: call('auth:enroll'), authQr: call('auth:qr'),
  authLogout: call('auth:logout'), authPing: call('auth:ping'),
  load: call('app:load'), saveChats: call('chats:save'), saveSettings: call('settings:save'),
  send: call('chat:send'), stop: call('chat:stop'), extractFile: call('file:extract'), transcribe: call('voice:transcribe'),
  changePassword: call('account:changePassword'), totpBegin: call('account:totpBegin'), totpConfirm: call('account:totpConfirm'),
  totpDisable: call('account:totpDisable'), deleteAccount: call('account:delete'), openExternal: call('shell:open'),
  adminStepUp: call('admin:stepUp'), adminUsers: call('admin:users'), adminSetStatus: call('admin:setStatus'),
  adminDeleteUser: call('admin:deleteUser'), adminPolicyGet: call('admin:policyGet'), adminPolicySet: call('admin:policySet'),
  adminSetSearchKey: call('admin:setSearchKey'), adminAudit: call('admin:audit'),
  adminModelDownload: call('admin:modelDownload'), adminModelUse: call('admin:modelUse'),
  onChatEvent: (cb) => on('chat:event', cb), onEngine: (cb) => on('engine:status', cb), onMl: (cb) => on('ml:status', cb),
  onSplash: (cb) => on('splash:status', cb), onUpdate: (cb) => on('update:status', cb), onSessionEnded: (cb) => on('session:ended', cb)
});
