// Windows: Virenscanner/Indexer halten Dateien manchmal kurz fest -> rename kann sporadisch mit EPERM/EBUSY scheitern.
import fs from 'node:fs';

const sleepSync = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);

export function renameRetry(from, to, tries = 6) {
  for (let i = 0; ; i++) {
    try { return fs.renameSync(from, to); }
    catch (e) {
      if (i >= tries - 1 || !['EPERM', 'EBUSY', 'EACCES'].includes(e.code)) throw e;
      sleepSync(30 * (i + 1));
    }
  }
}
