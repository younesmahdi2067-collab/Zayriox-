// Denkstufen. "level" = Anzahl zusätzlicher Denk-Durchgänge vor der Antwort.
export const MODES = {
  schnell: {
    id: 'schnell', label: 'Schnell', desc: 'Kurze, flotte Antworten', level: 0,
    temperature: 0.5, topP: 0.9, maxTokens: 320,
    style: 'Antworte kurz und direkt (höchstens 3–4 Sätze), außer der Nutzer verlangt ausdrücklich mehr.'
  },
  mittel: {
    id: 'mittel', label: 'Mittel', desc: 'Ausgewogen für den Alltag', level: 0,
    temperature: 0.6, topP: 0.9, maxTokens: 900,
    style: 'Antworte klar, freundlich und gut strukturiert.'
  },
  hoch: {
    id: 'hoch', label: 'Hoch', desc: 'Denkt erst nach, dann Antwort', level: 1,
    temperature: 0.6, topP: 0.9, maxTokens: 1400, thinkTokens: 320,
    style: 'Antworte gründlich und sorgfältig, mit klarer Struktur.'
  },
  promax: {
    id: 'promax', label: 'Pro Max', desc: 'Nachdenken, Entwurf, Selbstkorrektur', level: 2,
    temperature: 0.55, topP: 0.9, maxTokens: 1600, thinkTokens: 450,
    style: 'Antworte ausführlich, präzise und überprüfe deine Aussagen.'
  }
};

export const AUTO = { id: 'auto', label: 'Auto', desc: 'Zayriox wählt den passenden Modus selbst' };

export function listModes() {
  return [AUTO, ...Object.values(MODES)].map(({ id, label, desc }) => ({ id, label, desc }));
}

const HARD = /(beweis|herleit|berechne|optimier|algorithmus|komplex|ausführlich|schritt für schritt|debug|refactor|architektur|vergleiche|gleichung|integral|wahrscheinlichkeit|analysiere)/;
const MEDIUM = /(erkläre|erklär|warum|wieso|weshalb|schreibe|schreib|code|funktion|programm|zusammenfass|übersetze|plan|vorschlag|unterschied|tipps?)/;

export function resolveAuto(text = '', { hasFiles = false } = {}) {
  const t = String(text).toLowerCase();
  const len = t.length;
  if (len > 700 || (HARD.test(t) && len > 120)) return 'promax';
  if (hasFiles) return len > 200 ? 'hoch' : 'mittel';
  if (HARD.test(t) || len > 300) return 'hoch';
  if (MEDIUM.test(t) || len > 80) return 'mittel';
  return 'schnell';
}
