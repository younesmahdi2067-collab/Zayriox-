export const APP_NAME = 'Zayriox';
