import fs from 'node:fs';
import path from 'node:path';
import { renameRetry } from './fsutil.js';

export const DEFAULT_SETTINGS = { theme: 'dark', name: '', custom: '', mode: 'auto', webSearch: false, autoRead: false };
const MODES = new Set(['auto', 'schnell', 'mittel', 'hoch', 'promax']);
const str = (v, max) => (typeof v === 'string' ? v.slice(0, max) : '');

export function sanitizeSettings(s = {}) {
  return {
    theme: s.theme === 'light' ? 'light' : 'dark',
    name: str(s.name, 40).trim(),
    custom: str(s.custom, 1500),
    mode: MODES.has(s.mode) ? s.mode : 'auto',
    webSearch: s.webSearch === true,
    autoRead: s.autoRead === true
  };
}

export function sanitizeChats(chats) {
  if (!Array.isArray(chats)) return [];
  return chats.slice(0, 500).map((c) => ({
    id: str(c && c.id, 64),
    title: str(c && c.title, 200) || 'Neuer Chat',
    createdAt: Number(c && c.createdAt) || Date.now(),
    updatedAt: Number(c && c.updatedAt) || Date.now(),
    messages: (Array.isArray(c && c.messages) ? c.messages : []).slice(0, 1000)
      .filter((m) => m && (m.role === 'user' || m.role === 'assistant'))
      .map((m) => ({
        id: str(m.id, 64),
        role: m.role,
        content: str(m.content, 100000),
        thinking: str(m.thinking, 20000),
        ts: Number(m.ts) || Date.now(),
        modeUsed: MODES.has(m.modeUsed) ? m.modeUsed : undefined,
        auto: !!m.auto,
        stopped: !!m.stopped,
        error: str(m.error, 500) || undefined,
        sources: Array.isArray(m.sources)
          ? m.sources.slice(0, 8).filter((x) => x && /^https?:\/\//.test(String(x.url))).map((x) => ({ title: str(x.title, 160), url: str(x.url, 500) }))
          : undefined,
        files: Array.isArray(m.files) ? m.files.slice(0, 10).map((f) => str(f, 200)) : undefined,
        attach: Array.isArray(m.attach)
          ? m.attach.slice(0, 5).map((a) => ({ name: str(a && a.name, 200), text: str(a && a.text, 20000) }))
          : undefined
      }))
  })).filter((c) => c.id);
}

export class Store {
  constructor(dir) {
    this.dir = dir;
    fs.mkdirSync(dir, { recursive: true });
  }

  read(name, fallback) {
    const file = path.join(this.dir, name);
    try {
      return JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch (err) {
      if (err.code !== 'ENOENT') {
        try { fs.renameSync(file, `${file}.defekt-${Date.now()}`); } catch { /* egal */ }
      }
      return fallback;
    }
  }

  write(name, data) {
    const file = path.join(this.dir, name);
    const tmp = `${file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(data));
    renameRetry(tmp, file);
  }

  loadChats() { return sanitizeChats(this.read('chats.json', [])); }
  saveChats(chats) { this.write('chats.json', sanitizeChats(chats)); }
  loadSettings() { return sanitizeSettings(this.read('settings.json', DEFAULT_SETTINGS)); }
  saveSettings(s) { const clean = sanitizeSettings(s); this.write('settings.json', clean); return clean; }
}
