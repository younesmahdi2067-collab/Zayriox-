import { MODES, resolveAuto } from './modes.js';
import { ZxError } from './errors.js';
import { sourcesPrompt } from './search.js';

export const LIMITS = { historyChars: 6000, attachChars: 7000, maxMessages: 12, notesChars: 1500 };

const BASE =
  'Du bist Zayriox, ein freundlicher und ehrlicher KI-Assistent, der lokal auf dem Gerät des Nutzers läuft. ' +
  'Antworte in der Sprache des Nutzers (meistens Deutsch). Wenn du etwas nicht sicher weißt, sage es offen und erfinde nichts. ' +
  'Du kennst keine aktuellen Ereignisse, außer sie stehen in mitgelieferten Websuchergebnissen. Nutze Markdown; Code gehört in Codeblöcke.';

const THINK_SYSTEM =
  'Du bist der innere Denkprozess eines Assistenten. Analysiere die letzte Nachricht des Nutzers Schritt für Schritt: ' +
  'Was wird gefragt? Welche Fakten oder Schritte sind nötig? Wo liegen typische Fehler? ' +
  'Schreibe knappe Stichpunkte auf Deutsch. Gib NICHT die endgültige Antwort.';

const REVIEW_SYSTEM =
  'Du bist ein kritischer Lektor. Du bekommst eine Frage und einen Entwurf. Korrigiere Fehler, ergänze Fehlendes und ' +
  'streiche Überflüssiges. Gib NUR die endgültige, verbesserte Antwort aus – in der Sprache der Frage, ohne Kommentare über den Entwurf.';

/** Verlauf kürzen, leere Nachrichten entfernen, Rollen abwechseln lassen. */
export function trimHistory(messages) {
  const cleaned = messages.filter((m) => m && typeof m.content === 'string' && m.content.trim());
  const picked = [];
  let total = 0;
  for (let i = cleaned.length - 1; i >= 0 && picked.length < LIMITS.maxMessages; i--) {
    const m = cleaned[i];
    if (total + m.content.length > LIMITS.historyChars && picked.length > 0) break;
    picked.unshift({ role: m.role, content: m.content.slice(0, LIMITS.historyChars) });
    total += m.content.length;
  }
  while (picked.length && picked[0].role !== 'user') picked.shift();
  const merged = [];
  for (const m of picked) {
    const prev = merged[merged.length - 1];
    if (prev && prev.role === m.role) prev.content += '\n\n' + m.content;
    else merged.push({ ...m });
  }
  // Verlauf muss mit einer Modell-Antwort enden, weil danach die neue Nutzerfrage kommt.
  while (merged.length && merged[merged.length - 1].role === 'user') merged.pop();
  return merged;
}

export function buildUserPrompt(text, attach = []) {
  if (!attach || !attach.length) return text;
  let budget = LIMITS.attachChars;
  const blocks = [];
  for (const a of attach) {
    if (budget <= 0) break;
    let t = String(a.text || '');
    let cut = false;
    if (t.length > budget) { t = t.slice(0, budget); cut = true; }
    budget -= t.length;
    blocks.push(`Datei „${a.name}“${cut ? ' (gekürzt)' : ''}:\n\`\`\`\n${t}\n\`\`\``);
  }
  return `${blocks.join('\n\n')}\n\n${text && text.trim() ? text : 'Fasse den Inhalt der Datei zusammen.'}`;
}

/**
 * Führt eine Anfrage in der gewählten Denkstufe aus.
 * engine.complete({system, history, user, signal, temperature, topP, maxTokens, onText}) -> Text
 */
export async function runChat({ engine, mode = 'auto', wasAuto = null, messages, custom = '', signal, emit, search = null, images = [], describeImage = null }) {
  const last = messages[messages.length - 1];
  if (!last || last.role !== 'user') throw new ZxError('INVALID');

  // Bilder: lokales Bildmodell erzeugt eine Beschreibung, die dem Textmodell als Kontext dient.
  if (images.length && describeImage) {
    last.attach = [...(last.attach || [])];
    for (const img of images) {
      emit({ type: 'status', text: `Bild „${img.name}“ wird analysiert…` });
      const text = `Bildbeschreibung (automatisch erzeugt, kann Fehler enthalten): ${await describeImage(img.data)}`;
      last.attach.push({ name: img.name, text });
      emit({ type: 'image-desc', name: img.name, text });
      if (signal.aborted) return { stopped: true };
    }
  }

  const hasFiles = Array.isArray(last.attach) && last.attach.length > 0;
  const used = mode === 'auto' ? resolveAuto(last.content, { hasFiles }) : MODES[mode] ? mode : 'mittel';
  const cfg = MODES[used];
  emit({ type: 'mode', mode: used, auto: wasAuto === null ? mode === 'auto' : wasAuto });

  // Websuche (optional): Quellen werden als Kontext genutzt und unter der Antwort angezeigt.
  let searchBlock = '';
  if (search) {
    emit({ type: 'status', text: 'Websuche läuft…' });
    try {
      const results = await search(last.content);
      if (results.length) {
        searchBlock = sourcesPrompt(results);
        emit({ type: 'sources', sources: results.map(({ title, url }) => ({ title, url })) });
      } else emit({ type: 'notice', text: 'Die Websuche hat nichts Passendes gefunden.' });
    } catch {
      emit({ type: 'notice', text: new ZxError('SEARCH_FAILED').message });
    }
    if (signal.aborted) return { stopped: true };
  }

  const history = trimHistory(messages.slice(0, -1));
  const user = buildUserPrompt(last.content, last.attach);
  const system = [BASE, cfg.style, searchBlock, custom ? `Zusätzliche Anweisungen des Nutzers:\n${custom}` : '']
    .filter(Boolean)
    .join('\n\n');

  let notes = '';
  if (cfg.level >= 1) {
    emit({ type: 'think-start' });
    notes = await engine.complete({
      system: THINK_SYSTEM, history, user, signal,
      temperature: 0.4, topP: 0.9, maxTokens: cfg.thinkTokens,
      onText: (t) => emit({ type: 'think', text: t })
    });
    notes = notes.trim().slice(0, LIMITS.notesChars);
    if (signal.aborted) return { stopped: true };
  }

  const answerSystem = notes
    ? `${system}\n\nInterne Vorüberlegung (nutze sie, erwähne sie nicht wörtlich):\n${notes}`
    : system;

  let finalText;
  if (cfg.level >= 2) {
    emit({ type: 'think', text: '\n\n— Entwurf —\n' });
    const draft = await engine.complete({
      system: answerSystem, history, user, signal,
      temperature: cfg.temperature, topP: cfg.topP, maxTokens: cfg.maxTokens,
      onText: (t) => emit({ type: 'think', text: t })
    });
    if (signal.aborted) return { stopped: true };
    emit({ type: 'think-end' });
    finalText = await engine.complete({
      system: REVIEW_SYSTEM, history: [],
      user: `Frage:\n${user}\n\nEntwurf:\n${draft.trim()}`, signal,
      temperature: 0.4, topP: 0.9, maxTokens: cfg.maxTokens,
      onText: (t) => emit({ type: 'token', text: t })
    });
  } else {
    if (cfg.level === 1) emit({ type: 'think-end' });
    finalText = await engine.complete({
      system: answerSystem, history, user, signal,
      temperature: cfg.temperature, topP: cfg.topP, maxTokens: cfg.maxTokens,
      onText: (t) => emit({ type: 'token', text: t })
    });
  }

  if (signal.aborted) return { stopped: true };
  if (!finalText || !finalText.trim()) throw new ZxError('EMPTY_ANSWER');
  return { stopped: false };
}
