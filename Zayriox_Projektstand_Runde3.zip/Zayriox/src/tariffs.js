// Tarifkatalog – Preise sind Konfiguration/Produktmetadaten, keine echte Zahlungsabwicklung.
export const TARIFFS = [
  { id: 'auto', name: 'Auto', priceEUR: 0, period: 'monat', mode: 'auto', description: 'Automatische Auswahl des passenden Denkmodus.' },
  { id: 'mittel', name: 'Mittel', priceEUR: 0.89, period: 'monat', mode: 'mittel', description: 'Ausgewogener Alltagsmodus.' },
  { id: 'hoch', name: 'Hoch', priceEUR: 1.29, period: 'monat', mode: 'hoch', description: 'Mehr Denkzeit für anspruchsvollere Aufgaben.' },
  { id: 'schnell', name: 'Schnell', priceEUR: 3.40, period: 'monat', mode: 'schnell', description: 'Schnelle Antworten.' },
  { id: 'promax', name: 'Pro Max', priceEUR: 12.30, period: 'monat', mode: 'promax', description: 'Längeres Nachdenken und Selbstkorrektur.' },
  { id: 'owner', name: 'Owner', priceEUR: 0, period: 'intern', mode: null, description: 'Interner Verwaltungszugang.' }
];
