// Läuft mit:  Zayriox.exe --selftest --selftest-out=ergebnis.json [--selftest-model=modell.gguf] [--selftest-full] [--selftest-wav=sprache.wav] [--selftest-dir=ordner]
// Prüft in der ECHTEN Electron-App: Fenster lädt lokal (kein Browser/localhost), echte IPC-Brücke, Bedienung der echten Oberfläche,
// Konten/2FA/Rechte, keine Secrets im Frontend, keine offenen Netzwerk-Ports und (mit Modell) die echte lokale KI.
// Mit --selftest-full zusätzlich: PDF/TXT/Code-Uploads, Bildanalyse, Websuche und Spracherkennung mit echten Dateien/Modellen/Netz.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFileSync } from 'node:child_process';
import { totpAt } from './totp.js';
import { makePdf, makePng } from './fixtures.js';
import { wavToFloat32, validateAudio } from './media.js';
import { primarySearch, webSearchWithFallback } from './search.js';
import { MODELS } from './models.js';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const J = JSON.stringify;

export async function runSelfTest({ app, argVal, createMain, buildServices, createApi, registerIpc, hardenSession, setWin, root, log }) {
  const out = argVal('--selftest-out') || path.join(os.tmpdir(), 'zayriox-selftest.json');
  const modelPath = argVal('--selftest-model');
  const wavPath = argVal('--selftest-wav');
  const full = process.argv.includes('--selftest-full');
  const dir = argVal('--selftest-dir') || fs.mkdtempSync(path.join(os.tmpdir(), 'zayriox-st-'));
  const res = { modus: full ? 'voll' : 'kern', checks: {}, failed: [], info: {} };
  const check = (name, cond, info) => { res.checks[name] = !!cond; if (!cond) res.failed.push(info !== undefined ? `${name}: ${String(info).slice(0, 300)}` : name); };
  const section = async (name, fn) => {
    try { await fn(); } catch (e) { res.checks[`${name}_ausnahme`] = false; res.failed.push(`${name}: Ausnahme ${e && e.message ? e.message : e}`); log(`Selbsttest ${name}`, e); }
  };

  let win, svc, api;
  const ev = (code) => win.webContents.executeJavaScript(code, true);
  const until = async (code, ms = 20000, label = '') => {
    const t0 = Date.now();
    for (;;) {
      let v = false;
      try { v = await ev(code); } catch { /* Seite lädt noch */ }
      if (v) return v;
      if (Date.now() - t0 > ms) throw new Error(`Zeitüberschreitung: ${label || code}`);
      await sleep(150);
    }
  };
  const setv = (sel, val) => ev(`(()=>{const e=document.querySelector(${J(sel)});e.value=${J(val)};e.dispatchEvent(new Event('input',{bubbles:true}));return true})()`);
  const click = (sel) => ev(`document.querySelector(${J(sel)}).click()`);
  const events = [];
  const ctx = (sid) => ({ sid, notify: (c, p) => events.push({ sid, c, p }), openExternal: () => {}, setTheme: () => {} });
  const call = (sid, ch, p) => api.invoke(ch, ctx(sid), p);
  const waitEvents = async (pred, ms) => { const t0 = Date.now(); while (!events.some(pred)) { if (Date.now() - t0 > ms) throw new Error('Zeitüberschreitung beim Warten auf Chat-Ereignis'); await sleep(200); } };
  const chatApi = async (sid, payload, ms = 240000) => {
    if (sid === 1001) await ensureOwner(sid);
    events.length = 0;
    const r = await call(sid, 'chat:send', { requestId: `st-${Date.now()}`, ...payload });
    if (!r.ok) return { start: r, events: [] };
    await waitEvents((e) => e.p.type === 'done' || e.p.type === 'error', ms);
    return { start: r, events: events.map((e) => e.p) };
  };
  // Owner-Sitzungen laufen nach 10 Minuten Leerlauf ab (gewollt) – lange KI-Tests melden sich dann mit einem Recovery-Code neu an.
  let nextCode = 1;
  const ensureOwner = async (sid) => {
    if ((await call(sid, 'auth:ping')).ok) return;
    await call(sid, 'auth:login', { username: 'owner', password: PW });
    const v = await call(sid, 'auth:verify2fa', { code: codes[nextCode++] });
    if (!v.ok) throw new Error(`Owner-Anmeldung im Selbsttest fehlgeschlagen: ${v.error}`);
  };
  const B64 = (buf) => Buffer.from(buf).toString('base64');

  const PW = 'Selbsttest-Passwort-42';
  let secret = '', codes = [];

  // ---------------------------------------------------------------- 1) Fenster, echte IPC, Sender-Prüfung
  await section('fenster', async () => {
    svc = buildServices({ dir });
    res.info.cipher = svc.cipherName;
    check('tresor_os_verschluesselung', svc.cipherName === 'os', svc.cipherName);
    api = createApi(svc, { version: app.getVersion() });
    hardenSession();
    registerIpc(api);

    win = createMain({ show: true, noThrottle: true }); // sichtbar + ohne Drosselung: requestAnimationFrame (Streaming-Anzeige) läuft wie beim Nutzer
    setWin(win);
    await new Promise((r) => win.webContents.once('did-finish-load', r));
    const probe = await ev(`({
      protocol: location.protocol,
      hasApi: typeof window.zayriox === 'object' && typeof window.zayriox.authLogin === 'function',
      noNode: typeof require === 'undefined' && typeof process === 'undefined',
      hasUi: !!document.getElementById('app') && !!document.getElementById('auth'),
      title: document.title,
      mic: !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia),
      tts: 'speechSynthesis' in window
    })`);
    check('fenster_lokal_file', probe.protocol === 'file:', probe.protocol);
    check('oberflaeche_ohne_node', probe.noNode);
    check('preload_api', probe.hasApi);
    check('oberflaeche_geladen', probe.hasUi);
    check('titel_zayriox', probe.title === 'Zayriox', probe.title);
    check('mikrofon_api_vorhanden', probe.mic);
    check('vorlesen_api_vorhanden', probe.tts);
    res.info.userDataPath = app.getPath('userData');

    // echte IPC-Kette: Oberfläche -> Preload -> ipcMain -> Backend
    const st = await ev('window.zayriox.authStatus()');
    check('ipc_status_setup_phase', st && st.ok && st.phase === 'setup', J(st));
    const un = await ev('window.zayriox.adminUsers()');
    check('ipc_ohne_sitzung_abgewiesen', un && un.code === 'UNAUTH', J(un));

    // fremde Seite mit gleicher Preload-Brücke darf NICHTS aufrufen
    const foreign = createMain({ show: false, noThrottle: true, url: 'data:text/html,<p>fremd</p>' });
    await new Promise((r) => foreign.webContents.once('did-finish-load', r));
    const fr = await foreign.webContents.executeJavaScript('window.zayriox ? window.zayriox.authStatus() : "keine-bruecke"', true);
    check('ipc_fremde_seite_abgewiesen', fr === 'keine-bruecke' || (fr && fr.code === 'FORBIDDEN'), J(fr));
    foreign.destroy();
  });

  // ---------------------------------------------------------------- 2) Owner-Einrichtung über die ECHTE Oberfläche
  await section('ui_setup', async () => {
    await until("!!document.querySelector('#authForm')", 20000, 'Setup-Formular');
    check('ui_setup_willkommen', (await ev("document.querySelector('#auth').innerText")).includes('Willkommen bei Zayriox'));
    check('ui_app_vor_login_verborgen', await ev("document.getElementById('app').hidden"));
    await setv('input[name=username]', 'owner'); await setv('input[name=email]', 'owner@example.com'); await setv('input[name=password]', 'kurz');
    await click('button[type=submit]');
    await until("document.querySelector('.auth-msg').textContent.length>0", 10000, 'Fehlermeldung schwaches Passwort');
    check('ui_schwaches_passwort_abgelehnt', (await ev("document.querySelector('.auth-msg').textContent")).includes('10 Zeichen'));
    await setv('input[name=password]', PW); await click('button[type=submit]');
    await until("!!document.querySelector('#secretBox')", 20000, '2FA-Schlüssel');
    secret = (await ev("document.querySelector('#secretBox').textContent")).replace(/\s/g, '');
    check('ui_2fa_pflicht_schluessel_sichtbar', secret.length >= 16);
    await setv('input[name=code]', '000000'); await click('button[type=submit]');
    await until("document.querySelector('.auth-msg').textContent.includes('falsch')", 10000, 'falscher 2FA-Code');
    await setv('input[name=code]', totpAt(secret, Date.now())); await click('button[type=submit]');
    await until("document.querySelectorAll('.codes code').length===8", 20000, 'Wiederherstellungscodes');
    codes = await ev("Array.from(document.querySelectorAll('.codes code')).map(c=>c.textContent)");
    check('ui_8_recovery_codes', codes.length === 8);
    check('ui_weiter_erst_nach_bestaetigung', await ev("document.querySelector('#goApp').disabled"));
    await ev("(()=>{const c=document.querySelector('#savedCodes');c.checked=true;c.dispatchEvent(new Event('change'));document.querySelector('#goApp').click();return true})()");
    await until("!document.getElementById('app').hidden", 20000, 'Haupt-App sichtbar');
    check('ui_owner_bereich_sichtbar', await ev("!document.getElementById('btnOwner').hidden"));
    check('ui_onboarding_modell_download', await ev("!!document.querySelector('[data-act=download]')"));
  });

  // ---------------------------------------------------------------- 3) Konten, Rechte, Sicherheit (Backend über echte Dienste, echtes scrypt)
  await section('sicherheit', async () => {
    const O = 1001, U = 1002, X = 1003;
    const l = await call(O, 'auth:login', { username: 'owner', password: PW });
    check('login_verlangt_2fa', l.ok && l.step === '2fa', J(l));
    check('login_ohne_2fa_keine_sitzung', (await call(O, 'app:load')).code === 'UNAUTH');
    const v = await call(O, 'auth:verify2fa', { code: codes[0] });
    check('login_mit_recovery_code', v.ok && v.step === 'done', J(v));
    await call(X, 'auth:login', { username: 'owner', password: PW });
    check('recovery_code_nur_einmal', (await call(X, 'auth:verify2fa', { code: codes[0] })).ok === false);

    const reg = await call(U, 'auth:register', { username: 'nutzer1', email: 'n1@example.com', password: 'Nutzer-Passwort-77' });
    check('registrierung', reg.ok && reg.user.role === 'user', J(reg));
    check('doppelter_name_abgelehnt', (await call(1010, 'auth:register', { username: 'NUTZER1', email: 'zz@example.com', password: 'Nutzer-Passwort-77' })).ok === false);
    check('nutzer_kein_owner_bereich', (await call(U, 'admin:users')).code === 'FORBIDDEN');
    check('nutzer_keine_policy', (await call(U, 'admin:policySet', { features: { voice: false } })).code === 'FORBIDDEN');
    check('nutzer_kein_modellwechsel', (await call(U, 'admin:modelUse', 'mini')).code === 'FORBIDDEN');
    check('kein_zweiter_owner', (await call(1011, 'auth:setup', { username: 'hacker', email: 'h@example.com', password: 'Hacker-Passwort-1' })).code === 'FORBIDDEN');
    await call(U, 'settings:save', { role: 'owner' });
    check('rolle_nicht_ueber_einstellungen_aenderbar', (await call(U, 'app:load')).user.role === 'user');

    check('owner_braucht_stepup', (await call(O, 'admin:policySet', { limits: { messagesPerDay: 5 } })).code === 'STEPUP');
    const su = await call(O, 'admin:stepUp', { password: PW, code: totpAt(secret, Date.now() + 30000) });
    check('stepup_ok', su.ok, J(su));
    check('owner_aendert_policy', (await call(O, 'admin:policySet', { limits: { messagesPerDay: 500 } })).ok);

    // Sperren wirkt sofort, Owner ist geschützt
    const uid = svc.accounts.byName('nutzer1').id;
    check('owner_sperrt_nutzer', (await call(O, 'admin:setStatus', { id: uid, status: 'blocked' })).ok);
    check('gesperrter_nutzer_sofort_abgemeldet', (await call(U, 'app:load')).code === 'UNAUTH');
    check('gesperrter_nutzer_kann_sich_nicht_anmelden', (await call(1014, 'auth:login', { username: 'nutzer1', password: 'Nutzer-Passwort-77' })).code === 'BLOCKED');
    check('owner_nicht_sperrbar', (await call(O, 'admin:setStatus', { id: svc.accounts.byName('owner').id, status: 'blocked' })).code === 'FORBIDDEN');
    check('owner_entsperrt_nutzer', (await call(O, 'admin:setStatus', { id: uid, status: 'active' })).ok);
    await call(U, 'auth:login', { username: 'nutzer1', password: 'Nutzer-Passwort-77' });
    check('audit_kette_intakt', (await call(O, 'admin:audit')).integrity.ok);

    // Passwortwechsel
    const chg = await call(U, 'account:changePassword', { current: 'Nutzer-Passwort-77', next: 'Neues-Passwort-4711' });
    check('passwortwechsel', chg.ok, J(chg));
    check('altes_passwort_ungueltig', (await call(1012, 'auth:login', { username: 'nutzer1', password: 'Nutzer-Passwort-77' })).ok === false);
    check('neues_passwort_gueltig', (await call(1012, 'auth:login', { username: 'nutzer1', password: 'Neues-Passwort-4711' })).ok === true);
    await call(1012, 'auth:logout');

    // Login-Schutz
    for (let i = 0; i < 5; i++) await call(1013, 'auth:login', { username: 'nutzer1', password: 'falsch-falsch-1' });
    check('login_schutz_sperrt', (await call(1013, 'auth:login', { username: 'nutzer1', password: 'Neues-Passwort-4711' })).code === 'LOCKED');

    // Keine Secrets in Antworten an die Oberfläche
    const leak = J([await call(O, 'app:load'), await call(O, 'admin:users'), await call(O, 'admin:policyGet'), await call(O, 'auth:status')]);
    check('keine_hashes_oder_geheimnisse_in_antworten', !leak.includes('scrypt$') && !leak.includes(secret) && !/"pw"|"secret"|"recovery"|braveKey/.test(leak));

    check('audit_kette_weiterhin_intakt', (await call(O, 'admin:audit')).integrity.ok);
  });

  // ---------------------------------------------------------------- 4) Keine Secrets/Netzwerkzugriffe im Frontend, keine offenen Ports
  await section('frontend_secrets', async () => {
    const files = ['renderer', 'src'].flatMap((d) => fs.readdirSync(path.join(root, d)).filter((f) => /\.(js|cjs|html)$/.test(f)).map((f) => ({ d, f, text: fs.readFileSync(path.join(root, d, f), 'utf8') })));
    const SECRET = /(sk-[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|(api[_-]?key|token|secret|password)\s*[:=]\s*['"][A-Za-z0-9_\-+/=]{16,}['"]|Bearer\s+[A-Za-z0-9._-]{20,})/i;
    const hits = files.filter((x) => SECRET.test(x.text) && x.f !== 'selftest.js').map((x) => `${x.d}/${x.f}`);
    check('keine_secrets_im_code', hits.length === 0, hits.join(', '));
    const ui = files.filter((x) => x.d === 'renderer' && x.f.endsWith('.js'));
    check('oberflaeche_ohne_netzwerkaufrufe', ui.every((x) => !/\bfetch\s*\(|XMLHttpRequest|WebSocket|EventSource/.test(x.text)), ui.filter((x) => /\bfetch\s*\(|XMLHttpRequest|WebSocket|EventSource/.test(x.text)).map((x) => x.f).join(','));
    check('kein_localhost_im_code', files.every((x) => x.f === 'selftest.js' || !/(localhost|127\.0\.0\.1|0\.0\.0\.0)/.test(x.text)), files.filter((x) => x.f !== 'selftest.js' && /(localhost|127\.0\.0\.1)/.test(x.text)).map((x) => x.f).join(','));
  });

  // ---------------------------------------------------------------- 5) Echte lokale KI, Bedienung über die echte Oberfläche
  if (modelPath) {
    await section('ki', async () => {
      fs.mkdirSync(path.join(dir, 'models'), { recursive: true });
      fs.copyFileSync(modelPath, path.join(dir, 'models', MODELS[0].file));
      svc.engine.refreshInstalled();
      await svc.engine.load('mini');
      check('modell_geladen', svc.engine.status.state === 'ready', svc.engine.status.state);
      await until("document.querySelector('#statusPill').textContent.includes('Bereit')", 30000, 'Statusanzeige Bereit');
      check('ui_zeigt_modell_bereit', true);

      const pick = (mode) => ev(`(()=>{document.querySelector('#modeBtn').click();document.querySelector('[data-mode="${mode}"]').click();return true})()`);
      const send = async (text) => { await setv('#input', text); await click('#btnSend'); };
      const state = () => ev(`(()=>{const m=document.querySelectorAll('.msg.assistant .md');const l=m[m.length-1];return {len:l?l.textContent.length:0,text:l?l.textContent:'',idle:document.querySelector('#btnSend').getAttribute('aria-label')==='Senden',think:!!document.querySelector('.msg.assistant:last-child .think'),err:!!document.querySelector('.msg.assistant:last-child .err'),stopped:!!document.querySelector('.msg.assistant:last-child .stopped-note'),tag:(document.querySelector('.msg.assistant:last-child .tag')||{}).textContent||''}})()`);
      const waitIdle = async (ms = 240000, sample = null) => { const t0 = Date.now(); let s; await sleep(400); for (;;) { s = await state(); if (sample) sample.add(s.len); if (s.idle && (s.len > 0 || s.err)) return s; if (Date.now() - t0 > ms) throw new Error('Antwort kam nicht rechtzeitig'); await sleep(80); } };

      // Streaming + Schnell
      await pick('schnell');
      const lens = new Set();
      await send('Zähle auf Deutsch von 1 bis 15 auf.');
      const s1 = await waitIdle(240000, lens);
      check('ki_antwortet_schnell', s1.len > 0 && !s1.err, s1.text);
      check('streaming_in_der_oberflaeche', lens.size >= 3, `verschiedene Zwischenstände: ${lens.size}`);
      res.info.antwort_schnell = s1.text.slice(0, 200);

      // Denkstufe Hoch: sichtbares Nachdenken
      await pick('hoch');
      await send('Was ist 12 mal 12? Antworte kurz.');
      const s2 = await waitIdle();
      check('denkstufe_hoch_denkt_und_antwortet', s2.len > 0 && s2.think && !s2.err && /Hoch/.test(s2.tag), J({ think: s2.think, tag: s2.tag, err: s2.err }));
      res.info.antwort_hoch = s2.text.slice(0, 200);

      // Pro Max (Nachdenken + Entwurf + Überarbeitung)
      await pick('promax');
      await send('Nenne zwei Vorteile von lokaler KI.');
      const s3 = await waitIdle(480000);
      check('denkstufe_promax_antwortet', s3.len > 0 && !s3.err && /Pro Max/.test(s3.tag), J({ tag: s3.tag, err: s3.err }));

      // Stop-Button mitten in einer langen Antwort
      await pick('mittel');
      await send('Schreibe eine sehr lange Geschichte über einen Drachen mit mindestens 30 Absätzen.');
      await until("(()=>{const m=document.querySelectorAll('.msg.assistant .md');const l=m[m.length-1];return l&&l.textContent.length>15})()", 120000, 'erste Tokens');
      await click('#btnSend');
      await until("document.querySelector('#btnSend').getAttribute('aria-label')==='Senden'", 30000, 'Stop wirkt');
      const s4 = await state();
      check('stop_button_stoppt', s4.idle && s4.stopped, J({ idle: s4.idle, stopped: s4.stopped }));

      // stabil nach Stopp: nächste Frage funktioniert, Neu-Generieren funktioniert
      await pick('schnell');
      await send('Sage nur: Hallo.');
      const s5 = await waitIdle();
      check('stabil_nach_stopp', s5.len > 0 && !s5.err, s5.text);
      await click('[data-act=regen]');
      const s6 = await waitIdle();
      check('neu_generieren', s6.len > 0 && !s6.err);

      // Verlauf: gespeichert und in der Seitenleiste
      await sleep(600);
      const chats = svc.userStore(svc.accounts.byName('owner').id).loadChats();
      const msgs = chats.reduce((n, c) => n + c.messages.length, 0);
      check('verlauf_gespeichert', chats.length >= 1 && msgs >= 8 && chats[0].messages.some((m) => m.role === 'assistant' && m.content.length > 0), `Chats ${chats.length}, Nachrichten ${msgs}`);
      check('verlauf_in_seitenleiste', (await ev("document.querySelectorAll('.chat-item').length")) >= 1);
      res.info.hinweis_ki = 'Antwortqualität des 0,5B-Modells ist bewusst nicht Teil der Prüfung – geprüft wird, dass die echte KI stabil antwortet.';
    });
  } else res.info.hinweis = 'Kein Modell übergeben: KI-Test übersprungen.';

  // ---------------------------------------------------------------- 6) Erweitert: Dateien, Bild, Web, Voice (echte Dateien/Modelle/Netz)
  if (full) {
    await section('dateien', async () => {
      const files = [
        { name: 'notiz.txt', data: Buffer.from('Zayriox Notiz: Die Geheimzahl lautet 4711.\nZweite Zeile.') },
        { name: 'beispiel.py', data: Buffer.from('def gruss(name):\n    return f"Hallo {name}"\n\nprint(gruss("Welt"))\n') },
        { name: 'bericht.pdf', data: makePdf(['Zayriox PDF Test 12345', 'Die Hauptstadt von Deutschland ist Berlin.']) }
      ];
      const got = {};
      for (const f of files) {
        got[f.name] = await ev(`(async()=>{const b=Uint8Array.from(atob(${J(B64(f.data))}),c=>c.charCodeAt(0));return await window.zayriox.extractFile({name:${J(f.name)},data:b.buffer});})()`);
      }
      check('upload_txt', got['notiz.txt'].ok && got['notiz.txt'].text.includes('4711'), J(got['notiz.txt']));
      check('upload_code', got['beispiel.py'].ok && got['beispiel.py'].text.includes('def gruss'), J(got['beispiel.py']));
      check('upload_pdf', got['bericht.pdf'].ok && got['bericht.pdf'].text.includes('Zayriox PDF Test 12345'), J(got['bericht.pdf']));
      const bad = await ev(`window.zayriox.extractFile({name:'programm.exe',data:new Uint8Array([77,90,0,0]).buffer})`);
      check('upload_unbekanntes_format_verstaendliche_meldung', bad.ok === false && /nicht unterstützt/.test(bad.error) && !/Error|ECONN|at /.test(bad.error), J(bad));
      if (modelPath) {
        const r = await chatApi(1001, { mode: 'mittel', messages: [{ role: 'user', content: 'Welche Geheimzahl steht in der Datei? Antworte nur mit der Zahl.', attach: [{ name: 'notiz.txt', text: got['notiz.txt'].text }] }] });
        const txt = r.events.filter((e) => e.type === 'token').map((e) => e.text).join('');
        check('chat_mit_dateianhang_ohne_fehler', r.start.ok && !r.events.some((e) => e.type === 'error') && txt.length > 0, J(r.start));
        res.info.datei_frage_antwort = txt.slice(0, 120);
        res.info.datei_antwort_enthaelt_4711 = txt.includes('4711');
      }
    });

    await section('bild', async () => {
      if (!modelPath) return;
      const r = await chatApi(1001, { mode: 'mittel', messages: [{ role: 'user', content: 'Was ist auf dem Bild zu sehen?' }], images: [{ name: 'kreis.png', data: makePng() }] }, 900000);
      const desc = r.events.find((e) => e.type === 'image-desc');
      check('bildanalyse_beschreibung_erzeugt', !!desc && desc.text.length > 40 && !r.events.some((e) => e.type === 'error'), J(r.events.filter((e) => e.type === 'error')));
      check('bildanalyse_antwort_vom_textmodell', r.events.some((e) => e.type === 'token'));
      res.info.bildbeschreibung = desc ? desc.text.slice(0, 300) : null;
      res.info.bild_nennt_rot = desc ? /red|rot/i.test(desc.text) : false;
    });

    await section('websuche', async () => {
      let direct = [];
      try { direct = await primarySearch('Berlin Hauptstadt Deutschland'); } catch (e) { res.info.ddg_fehler = e.message; }
      res.info.ddg_treffer = direct.length;
      const results = await webSearchWithFallback('Berlin Hauptstadt Deutschland');
      check('websuche_echte_treffer', results.length >= 1 && results.every((x) => /^https:\/\//.test(x.url) && x.title), J(results.slice(0, 2)));
      res.info.websuche_quellen = results.map((x) => x.url).slice(0, 3);
      if (modelPath) {
        const r = await chatApi(1001, { mode: 'mittel', webSearch: true, messages: [{ role: 'user', content: 'Was ist die Hauptstadt von Deutschland?' }] });
        const src = r.events.find((e) => e.type === 'sources');
        check('chat_websuche_quellen_kommen_mit', !!src && src.sources.length >= 1 && !r.events.some((e) => e.type === 'error'), J(r.events.filter((e) => e.type === 'error' || e.type === 'notice')));
        res.info.web_antwort = r.events.filter((e) => e.type === 'token').map((e) => e.text).join('').slice(0, 200);
      }
    });

    await section('voice', async () => {
      if (!wavPath || !fs.existsSync(wavPath)) { check('voice_testdatei_vorhanden', false, 'kein --selftest-wav'); return; }
      const pcm = wavToFloat32(fs.readFileSync(wavPath));
      check('voice_wav_lesbar', !!pcm && !!validateAudio(pcm) && pcm.length > 8000, pcm ? pcm.length : 'null');
      const { MlService } = await import('./ml.js');
      const ml = svc.ml || new MlService({ cacheDir: path.join(dir, 'ml-cache'), log });
      const text = await ml.transcribe(pcm, { language: 'english' });
      res.info.voice_erkannt = text;
      check('voice_spracherkennung', /hello|world|test|zayriox|this|is/i.test(text), text);
      // über die echte API (Berechtigung, Prüfung, Sprache Deutsch)
      await ensureOwner(1001);
      const r = await call(1001, 'voice:transcribe', pcm);
      check('voice_api_antwortet', r.ok === true || r.code === 'VOICE_FAILED', J(r));
      check('voice_ungueltige_daten_abgelehnt', (await call(1001, 'voice:transcribe', new Float32Array(10))).ok === false);
    });
  }

  // ---------------------------------------------------------------- 7) Kein Server: keine lauschenden Ports der App
  await section('ports', async () => {
    const pids = new Set([process.pid, ...app.getAppMetrics().map((m) => m.pid)]);
    const outp = execFileSync('netstat', ['-ano', '-p', 'TCP'], { encoding: 'utf8' });
    const listening = outp.split('\n').filter((l) => /LISTENING/.test(l)).map((l) => l.trim().split(/\s+/)).filter((c) => pids.has(Number(c[c.length - 1])));
    check('keine_lauschenden_netzwerk_ports', listening.length === 0, J(listening));
    res.info.app_prozesse = [...pids].length;
  });

  try { await svc.engine.dispose(); } catch { /* egal */ }
  res.ok = res.failed.length === 0;
  fs.writeFileSync(out, JSON.stringify(res, null, 2));
  app.exit(res.ok ? 0 : 1);
}
