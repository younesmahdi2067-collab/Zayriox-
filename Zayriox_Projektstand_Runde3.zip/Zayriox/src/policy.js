// Globale Regeln, die NUR der Owner ändern kann (Funktionen, Limits, Wartungsmodus, Modell, Suchanbieter)
// + Nutzungszähler pro Konto (nur Zahlen, keine Inhalte).
import { MODES } from './modes.js';

export const DEFAULT_POLICY = {
  features: { webSearch: true, voice: true, imageAnalysis: true, uploads: true, registration: true },
  maintenance: { on: false, message: '' },
  limits: { messagesPerDay: 200, heavyPerDay: 40 },
  modes: { schnell: true, mittel: true, hoch: true, promax: true },
  modelId: 'mini',
  searchProvider: 'duckduckgo',
  secrets: {}
};

const bool = (v, d) => (typeof v === 'boolean' ? v : d);
const int = (v, d, max = 100000) => (Number.isFinite(Number(v)) ? Math.max(0, Math.min(max, Math.floor(Number(v)))) : d);

export function sanitizePolicy(p = {}, base = DEFAULT_POLICY) {
  const f = p.features || {}, m = p.maintenance || {}, l = p.limits || {}, md = p.modes || {};
  return {
    features: Object.fromEntries(Object.keys(DEFAULT_POLICY.features).map((k) => [k, bool(f[k], base.features[k])])),
    maintenance: { on: bool(m.on, base.maintenance.on), message: typeof m.message === 'string' ? m.message.slice(0, 200) : base.maintenance.message },
    limits: { messagesPerDay: int(l.messagesPerDay, base.limits.messagesPerDay), heavyPerDay: int(l.heavyPerDay, base.limits.heavyPerDay) },
    modes: Object.fromEntries(Object.keys(MODES).map((k) => [k, bool(md[k], base.modes[k])])),
    modelId: typeof p.modelId === 'string' && p.modelId ? p.modelId.slice(0, 40) : base.modelId,
    searchProvider: p.searchProvider === 'brave' ? 'brave' : p.searchProvider === 'duckduckgo' ? 'duckduckgo' : base.searchProvider,
    secrets: base.secrets
  };
}

export class Policy {
  constructor(store, now = () => new Date()) {
    this.store = store;
    this.now = now;
    this.data = sanitizePolicy(store.read('policy.json', DEFAULT_POLICY));
    const saved = store.read('policy.json', {});
    this.data.secrets = saved && typeof saved.secrets === 'object' && saved.secrets ? { braveKey: typeof saved.secrets.braveKey === 'string' ? saved.secrets.braveKey : undefined } : {};
    this.usage = store.read('usage.json', {});
  }

  /** Was die Oberfläche sehen darf (ohne Geheimnisse). */
  get() {
    const { secrets, ...rest } = this.data;
    return { ...JSON.parse(JSON.stringify(rest)), searchKeySet: !!secrets.braveKey };
  }

  set(patch) {
    const next = sanitizePolicy({ ...this.data, ...patch,
      features: { ...this.data.features, ...(patch.features || {}) },
      maintenance: { ...this.data.maintenance, ...(patch.maintenance || {}) },
      limits: { ...this.data.limits, ...(patch.limits || {}) },
      modes: { ...this.data.modes, ...(patch.modes || {}) } }, this.data);
    next.secrets = this.data.secrets;
    this.data = next;
    this.store.write('policy.json', this.data);
    return this.get();
  }

  getSecret(name) { return this.data.secrets[name] || null; }
  setSecret(name, sealed) {
    if (sealed) this.data.secrets[name] = sealed; else delete this.data.secrets[name];
    this.store.write('policy.json', this.data);
  }

  day() { const d = this.now(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }
  _u(id) {
    const u = this.usage[id] || (this.usage[id] = { day: this.day(), msgs: 0, heavy: 0, total: 0 });
    if (u.day !== this.day()) { u.day = this.day(); u.msgs = 0; u.heavy = 0; }
    return u;
  }
  usageOf(id) { return { ...this._u(id) }; }

  /** Prüft Tageslimits. Owner ist unbegrenzt. */
  check(user, modeUsed) {
    if (user.role === 'owner') return { ok: true };
    const u = this._u(user.id), l = this.data.limits;
    if (l.messagesPerDay > 0 && u.msgs >= l.messagesPerDay) return { ok: false, reason: `Tageslimit erreicht (${l.messagesPerDay} Nachrichten). Morgen geht es weiter.` };
    if (l.heavyPerDay > 0 && MODES[modeUsed] && MODES[modeUsed].level >= 1 && u.heavy >= l.heavyPerDay) return { ok: false, reason: `Tageslimit für „Hoch“ und „Pro Max“ erreicht (${l.heavyPerDay}). Wähle Schnell oder Mittel.` };
    return { ok: true };
  }
  record(id, modeUsed) {
    const u = this._u(id);
    u.msgs++; u.total++;
    if (MODES[modeUsed] && MODES[modeUsed].level >= 1) u.heavy++;
    this.store.write('usage.json', this.usage);
  }
  removeUser(id) { delete this.usage[id]; this.store.write('usage.json', this.usage); }
}
